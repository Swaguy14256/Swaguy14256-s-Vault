========================================================================

				   Sprite Test.smc
				   By: WMS95

========================================================================

Story: None; this hack tests 2 sprites; one downloaded from SMW Central,
one programmed by myself.

========================================================================

Credits: WMS95 - Level Design, Overworld Design, Testing, Sprite
Programming
mikeyk & RussianMan - Ground Pound Koopa Sprite
Nintendo - Original ROM and game engine

========================================================================

Stuff to Visit: My YouTube Channel - https://www.youtube.com/channel/UCi
Ft008F7LUdgE5Se0kN3Fg
Geometry Dash Shopkeeper's YouTube Channel - https://www.youtube.com/cha
nnel/UCHgTqfwxHHzgZtPj51r3r1w
The Merch Store - https://the-merch-store--wms.repl.co
WMS Central - https://wms-central.community.chat/
WMS Archive Page - https://wms-archived--wms.repl.co
My SMW Central Profile - https://www.smwcentral.net/?p=profile&id=41963

========================================================================

Also, Toon Zelda is a hot chick.