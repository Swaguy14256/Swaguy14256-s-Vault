======================================================================
                                                                      
                                Bob THE GAME                          
                        By: Geometry Dash Shopkeeper                  
                                                                      
======================================================================

	Mario was minding his own business one day when all of the sudden, a level appeared in front of one of Yoshi's many houses. Yoshi warns him not to enter, but Mario is too curious to listen. Upon completing the level, a portal appears. What lies beyond the portal?

======================================================================

                                  Credits:
Geometry Dash Shopkeeper: Level design, testing, Overworld design.
WMS95: Overworld Design.
Nintendo: Original game engine.

======================================================================

                              Stuff to visit:

My Youtube: https://www.youtube.com/channel/UCHgTqfwxHHzgZtPj51r3r1w
WMS95's Youtube: https://www.youtube.com/channel/UCiFt008F7LUdgE5Se0kN3Fg
The Merch Store: https://the-merch-store--wms.repl.co

======================================================================
Bye my merch
buy now, i mean, bye now.



















































































ps. Alfonzo's train is far superior to the spirit train!
