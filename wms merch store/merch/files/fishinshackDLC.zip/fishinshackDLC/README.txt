======================================================================
                                                                      
                                Bob THE GAME
			     + Fishin Shack DLC                          
                        By: Geometry Dash Shopkeeper                  
                                                                      
======================================================================

	Thanks for downloading this DLC. This features lots of extra features for you to enjoy. Works with your previous save of bob THE GAME, although it is recommended to start from a new save. 

Features:
- Added the 'Fishin Shack' Level (can be found after completing LAYERGM
- Expanded end game story
- Modified overworld
- Fixed minor oversights
- Included tips file for 'Fishin Shack'
- Sum secretz 

Requirements:
- Bob THE GAME rom file
- A BPS patching tool
- An SNES Emulator
- Included .BPS File

How to apply the DLC:
1. Open your BPS Patching tool
2. Select 'Apply Patch'
3. Find and select the included .BPS file, and hit OPEN
4. Find and select a copy of bob THE GAME (Not SMW), and hit OPEN
5. Save the output
6. Enjoy!

If you are struggling, refer to this tutorial for more support: https://www.youtube.com/watch?v=UrNVk6_Z0a0

======================================================================

	Mario was minding his own business one day when all of the sudden, a level appeared in front of one of Yoshi's many houses. Yoshi warns him not to enter, but Mario is too curious to listen. Upon completing the level, a portal appears. What lies beyond the portal?

======================================================================

                                  Credits:
	+ Fishin Shack DLC
Geometry Dash Shopkeeper: Level design, testing, Overworld design, graphics design.

	bob THE GAME:

Geometry Dash Shopkeeper: Level design, testing, Overworld design.
WMS95: Overworld Design.
Nintendo: Original game engine.

======================================================================

                              Stuff to visit:

My Youtube: https://www.youtube.com/channel/UCHgTqfwxHHzgZtPj51r3r1w

WMS95's Youtube: https://www.youtube.com/channel/UCiFt008F7LUdgE5Se0kN3Fg

The Merch Store: https://the-merch-store--wms.repl.co

WMS Central: https://groups.google.com/forum/?nomobile=true#!forum/wms-central

======================================================================
Bye my merch
buy now, i mean, bye now.



















































































ps. hey did you now a train exists can can make your dreams come true? well, now you know also it is alfonzo's train.
