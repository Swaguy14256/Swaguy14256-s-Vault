======================================================================
                                                                      
                            Epic Nothing the Game                          
                        By: Geometry Dash Shopkeeper                  
                                                                      
======================================================================

	Thanks for downloading this hack. In short, it is desert bus. You must travel through 510 levels, grab a P-Switch, go back, and activate it to complete the level. Completing it will grant you a star. Can you get two stars on all three files? (100% the game)

Requirements:
- Super Mario World rom file
- A BPS patching tool
- An SNES Emulator
- Included .BPS File

How to apply the Patch:
1. Open your BPS Patching tool
2. Select 'Apply Patch'
3. Find and select the included .BPS file, and hit OPEN
4. Find and select a copy of Super Mario World, and hit OPEN
5. Save the output
6. Enjoy!

If you are struggling, refer to this tutorial for more support: https://www.youtube.com/watch?v=UrNVk6_Z0a0

======================================================================

                                  Credits:
Geometry Dash Shopkeeper: Level design, testing, Overworld design.
WMS95: ASM Manager, testing.
Noobish Noobsicle: Rollover Patch
JP32 (KDeee): Level Idea
Nintendo: Original game engine.

======================================================================

                              Stuff to visit:

My Youtube: https://www.youtube.com/channel/UCHgTqfwxHHzgZtPj51r3r1w

WMS95's Youtube: https://www.youtube.com/channel/UCiFt008F7LUdgE5Se0kN3Fg

The Merch Store: https://the-merch-store--wms.repl.co

WMS Central: https://groups.google.com/forum/?nomobile=true#!forum/wms-central

======================================================================
Bye my merch
buy now, i mean, bye now.



















































































ps. if you could play desert bus with alfonzo's train instead, it would be much quicker.
