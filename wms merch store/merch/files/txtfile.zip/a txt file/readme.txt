Hello there. 

If you are reading this, thank a teacher.
If not, than your teacher did something wrong.


also do not trust this message!