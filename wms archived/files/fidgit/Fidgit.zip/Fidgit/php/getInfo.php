<rooms tools="" bg="bg/1.swf,bg/2.swf,bg/3.swf,bg/4.swf,bg/5.swf,bg/6.swf,bg/7.swf,bg/8.swf,bg/9.swf,bg/10.swf,bg/11.swf,bg/12.swf,bg/13.swf,bg/14.swf,bg/15.swf" fg="">
<list code="GRYR27u052">
	</list>
	<your>		<room roomID="286734" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="269841" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="269809" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="242311" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="212004" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="212003" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="212001" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="212000" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211998" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211996" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211520" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211515" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211514" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211510" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211507" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211503" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211502" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211493" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211423" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211420" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211417" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211413" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211412" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211410" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211408" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211405" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211331" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211327" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211326" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211323" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211245" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211241" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211239" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="211237" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210974" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210973" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210972" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210971" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210967" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210965" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210963" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210961" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210957" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210954" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210951" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210949" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210948" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210946" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210944" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210942" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210940" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210937" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210934" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210933" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="210930" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209666" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209665" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209661" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209299" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209293" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209281" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209260" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209171" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209168" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209165" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209164" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209060" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209055" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209054" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209046" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209043" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209036" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="209032" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208965" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208963" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208962" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208961" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208958" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208956" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208953" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208951" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208950" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208948" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208947" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208944" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208939" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208936" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208934" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208933" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208853" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208852" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208846" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="208836" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207389" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207312" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207307" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207305" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207303" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207302" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207300" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207299" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207297" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="207296" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="202386" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="201105" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="199356" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="196431" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="196429" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="196346" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="196345" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="195524" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="195523" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="195485" status="new" type="open" setting="main" title="the rig" fg="blank" bg="bg/2.swf">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="226.5" y="6" lock="no" other=""/>
<figitbox x="6" y="556" lock="no" other="par=l/2/20"/>
<figitbox x="521.5" y="556" lock="no" other="par=l/1/10"/>
<conveyorbelt x="406" y="162.5" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="168.5" y="335.5" lock="no" other="cv=rt_fast"/></room>
		<room roomID="194537" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="194533" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="194531" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="194529" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="194527" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="194526" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="194524" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="194522" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="194520" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="191150" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="191149" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="191062" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="190887" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="190885" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="190882" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="190879" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="190877" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="190876" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="190874" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="190872" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="190866" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="189542" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="189541" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="189536" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="189534" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="184739" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="184738" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="184736" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="184714" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="184712" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="183327" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="175408" status="new" type="open" setting="main" title="jallissau" fg="blank" bg="bg/1.swf">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="6" y="6" lock="no" other=""/>
<figitdropper x="269.5" y="6" lock="no" other=""/>
<figitbox x="6" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="274.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="113.5" y="88.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="176.5" y="87.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="232.5" y="86.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="367.5" y="82.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="424.5" y="81.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="484.5" y="80.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="227.5" y="168.5" lock="no" other="rotation=0"/>
<fixedblock x="232.5" y="259.5" lock="no" other="rotation=0"/>
<fixedblock x="114.5" y="259.5" lock="no" other="rotation=0"/>
<fixedblock x="378.5" y="259.5" lock="no" other="rotation=0"/>
<fixedblock x="110.5" y="173.5" lock="no" other="rotation=0"/>
<fixedblock x="375.5" y="176.5" lock="no" other="rotation=0"/>
<fixedblock x="478.5" y="259.5" lock="no" other="rotation=0"/>
<fixedblock x="479" y="171.5" lock="no" other="rotation=0"/></room>
		<room roomID="175020" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="175018" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="175017" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="174706" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="173395" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="173393" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="170545" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="170405" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="170296" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="170294" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="170292" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="170290" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169890" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169600" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169599" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169597" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169421" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169420" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169418" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169309" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169307" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169241" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169235" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169159" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169079" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169072" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169065" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169063" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="169006" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="168987" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="168985" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="168983" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="161176" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="161113" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="161112" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="154161" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="154125" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="151375" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="149264" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="142394" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="139463" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="139461" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="134646" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="134645" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="134466" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="132204" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="121767" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117498" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117495" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117493" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117490" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117488" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117486" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117484" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117478" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117476" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117473" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117469" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117465" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117460" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117459" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117458" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117456" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117446" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117444" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117442" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117382" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117374" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117372" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117370" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117366" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117365" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117362" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117360" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117358" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117181" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117177" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117175" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117170" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117168" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117164" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117163" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117157" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117154" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117026" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117021" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117018" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117013" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="117009" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="116990" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="116985" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="116838" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="116836" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="116778" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="116769" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="116765" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="116757" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="115692" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="115690" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="115493" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="115372" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="115156" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="115081" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="115078" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="114847" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="114844" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="114842" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="114830" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="114760" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="88853" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="79146" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="79145" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="78170" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="78169" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="77698" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="77697" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="77696" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="77695" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="77117" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/2.swf">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitbox x="21.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="479.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="268.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="294" y="226.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="360.5" y="295.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="471.5" y="326.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="406.5" y="260.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="394.5" y="155.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="472.5" y="254.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="484.5" y="146.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="498.5" y="194.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="332.5" y="92.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="342.5" y="182.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="76897" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="76891" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="76888" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="76886" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="76882" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="76881" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="76754" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="72259" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="72255" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="72254" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="72235" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="72234" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="72224" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="72223" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="56962" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="49383" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="49380" status="new" type="open" setting="wind" title="hard on hard" fg="blank" bg="bg/2.swf">
	<figitdropper x="102.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/999"/>
<figitbox x="136.5" y="556" lock="no" other="par=r/0/999"/>
<figitbox x="293.5" y="553.5" lock="no" other="par=r/0/999"/>
<rubberblock x="252.5" y="286.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="443.5" y="274.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="342.5" y="167.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="522.5" y="176.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="185.5" y="159.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="116.5" y="553.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46.5" y="550.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="258.5" y="549.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="413.5" y="554.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="493.5" y="557.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="505.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="415.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="389.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="260.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="234.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="126.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="99.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="70.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="21.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="43.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="278.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="436.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="460.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="483.5" y="579" lock="no" other="rotation=0"/></room>
		<room roomID="25581" status="" type="open" setting="" title="" fg="" bg="">
	<figitdropper x="7" y="6" lock="no" other=""/>
<figitbox x="460.5" y="556" lock="no" other="par=s/10/51"/>
<rubberblock x="53" y="176.75" lock="no" other="rotation=0.46 mat=rubber"/>
<rubberblock x="297.5" y="535.75" lock="no" other="rotation=1.049 mat=rubber"/>
<rubberblock x="529" y="136.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="300.5" y="128.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="451" y="131.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="254.5" y="292.75" lock="no" other="rotation=1.57 mat=rubber"/>
<rubberblock x="256.5" y="376.75" lock="no" other="rotation=1.56 mat=rubber"/>
<rubberblock x="266.5" y="458.75" lock="no" other="rotation=1.299 mat=rubber"/>
<rubberblock x="380" y="127.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="583.5" y="141.5" lock="no" other="rotation=0"/>
<fixedblock x="89.5" y="102.5" lock="no" other="rotation=0"/>
<fixedblock x="93.5" y="74.5" lock="no" other="rotation=0"/>
<fixedblock x="254.5" y="236.5" lock="no" other="rotation=0"/>
<pvcpipe x="112.5" y="155.5" lock="no" other="rotation=0.232"/>
<pvcpipe x="202.5" y="175.5" lock="no" other="rotation=0.209"/>
<figitdivider x="6" y="44.5" lock="no" other=""/>
<figitpainter x="272.5" y="219.5" lock="no" other="color=10"/>
<figitpainter x="332.5" y="218.5" lock="no" other="color=10"/>
<figitpainter x="391.5" y="217.5" lock="no" other="color=10"/>
<figitpainter x="450.5" y="219.5" lock="no" other="color=10"/>
<figitpainter x="493.5" y="219.5" lock="no" other="color=10"/>
<figitpainter x="533.5" y="218.5" lock="no" other="color=10"/>
<spring x="329.5" y="561.5" lock="no" other="dir=left"/>
<spring x="538" y="560.5" lock="no" other="dir=left"/>
<spring x="558" y="561.5" lock="no" other="dir=left"/>
<spring x="373.5" y="561.5" lock="no" other="dir=left"/>
<spring x=%2</room>
		<room roomID="14542" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="12969" status="" type="open" setting="" title="" fg="" bg="">
	</room>
		<room roomID="8254" status="" type="open" setting="" title="" fg="" bg="">
	</room>
	</your>
	<friend>		<room roomID="91825" status="new" type="open" setting="main" title="How to play" fg="blank" bg="bg/1.swf" author="Adadyy">
	<figitdropper x="296.5" y="6" lock="no" other=""/>
<figitbox x="297.5" y="556" lock="no" other="par=r/0/1"/></room>
		<room roomID="91781" status="new" type="open" setting="main" title="KHNGHKLKLYH" fg="blank" bg="bg/2.swf" author="wendy5654">
	<figitdropper x="399.5" y="6" lock="no" other=""/>
<figitdropper x="253.5" y="6" lock="no" other=""/>
<figitdropper x="125.5" y="6" lock="no" other=""/>
<figitbox x="251.5" y="556" lock="no" other="par=r/0/900"/>
<rubberblock x="560" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="499.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="442.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="365.5" y="575" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="220.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="168.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="108.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="47.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="479.5" y="521.75" lock="no" other="rotation=-0.229 mat=rubber"/>
<rubberblock x="140.5" y="525.75" lock="no" other="rotation=0.36 mat=rubber"/></room>
		<room roomID="90970" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/11.swf" author="carisgreat">
	<figitdropper x="307.5" y="6" lock="no" other=""/>
<figitbox x="495.1" y="556" lock="no" other="par=r/0/100"/>
<rubberblock x="343.3" y="150.75" lock="no" other="rotation=0.445 mat=rubber"/></room>
		<room roomID="90788" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/1.swf" author="jkjk825">
	<figitdropper x="297.5" y="6" lock="no" other=""/>
<figitbox x="522" y="555" lock="no" other="par=r/7/91"/>
<rubberblock x="46" y="298.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="47" y="334.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="322.5" y="342.75" lock="no" other="rotation=0 mat=wood"/></room>
		<room roomID="89223" status="new" type="open" setting="main" title="Austin" fg="blank" bg="bg/1.swf" author="tigger07">
	<figitdropper x="365.5" y="6" lock="no" other=""/>
<figitdropper x="427.5" y="6" lock="no" other=""/>
<figitdropper x="489.5" y="6" lock="no" other=""/>
<figitbox x="356.5" y="556" lock="no" other="par=l/0/1"/>
<figitbox x="432.5" y="556" lock="no" other="par=l/0/1"/>
<figitbox x="509.5" y="556" lock="no" other="par=l/0/3"/>
<fidgitcannon x="340.5" y="66.5" lock="no" other="chute=90"/>
<fidgitcannon x="416.5" y="65.5" lock="no" other="chute=90"/>
<fidgitcannon x="494" y="75.5" lock="no" other="chute=90"/></room>
		<room roomID="88518" status="new" type="open" setting="main" title="WIERD ROOM!!!" fg="blank" bg="bg/6.swf" author="ggrr">
	<figitdropper x="333.5" y="6" lock="no" other=""/>
<figitbox x="123.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="401.5" y="349.75" lock="no" other="rotation=-0.411 mat=rubber"/></room>
		<room roomID="87735" status="new" type="open" setting="moon" title="900 A's on moon" fg="blank" bg="bg/11.swf" author="ilovepizza789">
	<figitdropper x="78.5" y="6" lock="no" other=""/>
<figitdropper x="492.5" y="6" lock="no" other=""/>
<figitbox x="83.5" y="500.5" lock="no" other="par=s/0/900"/>
<figitbox x="507.5" y="511.5" lock="no" other="par=s/0/900"/>
<rubberblock x="332.5" y="66.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="332.5" y="190.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="333.5" y="314.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="334.5" y="434.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="336.5" y="523.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="343.5" y="130.75" lock="no" other="rotation=0 mat=wood"/>
<rubberblock x="343.5" y="252.75" lock="no" other="rotation=0 mat=wood"/>
<rubberblock x="348.5" y="375.75" lock="no" other="rotation=0 mat=wood"/>
<rubberblock x="357.5" y="476.75" lock="no" other="rotation=0 mat=wood"/></room>
		<room roomID="87433" status="new" type="open" setting="moon" title="starry" fg="blank" bg="bg/5.swf" author="jenn942">
	<figitdropper x="397.5" y="6" lock="no" other=""/>
<figitbox x="22.5" y="80.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="87408" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="derpface50">
	<figitdropper x="75.5" y="6" lock="no" other=""/>
<figitdropper x="286.5" y="6" lock="no" other=""/>
<figitdropper x="445.5" y="6" lock="no" other=""/>
<figitbox x="152" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="77.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="8.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="72.5" y="495.75" lock="no" other="rotation=0.669 mat=rubber"/></room>
		<room roomID="87206" status="new" type="open" setting="main" title="test" fg="blank" bg="bg/3.swf" author="isrutkoski22">
	<figitdropper x="492.5" y="6" lock="no" other=""/>
<figitbox x="413.5" y="556" lock="no" other="par=l/0/1"/>
<rubberblock x="364.5" y="431.75" lock="no" other="rotation=2.269 mat=rubber"/>
<figitcombiner x="473" y="289.5" lock="no" other=""/>
<figitcombiner x="479" y="360.5" lock="no" other=""/>
<pendulum x="257.5" y="273.5" lock="no" other="swing_x=-156 swing_y=18"/>
<fidgitcannon x="481" y="420.5" lock="no" other="chute=-165"/></room>
		<room roomID="87097" status="new" type="open" setting="main" title="boss2" fg="blank" bg="bg/1.swf" author="santo213">
	<figitdropper x="470.5" y="6" lock="no" other=""/>
<rubberblock x="512.5" y="184.75" lock="no" other="rotation=-0.548 mat=rubber"/>
<rubberblock x="432.5" y="231.75" lock="no" other="rotation=-0.438 mat=rubber"/>
<rubberblock x="335.5" y="264.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="219.5" y="264.75" lock="no" other="rotation=0.044 mat=rubber"/>
<fixedblock x="278.5" y="266.5" lock="no" other="rotation=0"/></room>
		<room roomID="86077" status="new" type="open" setting="main" title="big fat fidgits" fg="blank" bg="bg/3.swf" author="baeym">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="152.3" y="335.85" lock="no" other="par=l/1/10"/>
<rubberblock x="137.7" y="300.35" lock="no" other="rotation=-1.526 mat=rubber"/>
<rubberblock x="142.4" y="228.75" lock="no" other="rotation=1.551 mat=rubber"/>
<rubberblock x="159.9" y="175.1" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="225.65" y="173.8" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="299.4" y="171.55" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="376.85" y="173.85" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="456.6" y="178.5" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="489.3" y="126.8" lock="no" other="rotation=0 mat=rubber"/>
<figitcombiner x="499" y="141.9" lock="no" other=""/>
<figitcombiner x="500" y="201.5" lock="no" other=""/>
<figitpainter x="535" y="74.5" lock="no" other="color=1"/>
<conveyorbelt x="397.45" y="330.75" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="226.35" y="333.15" lock="no" other="cv=lt_fast"/></room>
		<room roomID="85911" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="dnag">
	<figitdropper x="447.6" y="6" lock="no" other=""/>
<figitbox x="383.7" y="307.6" lock="no" other="par=r/0/1"/>
<figitbox x="289.45" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="6" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="496.35" y="301.4" lock="no" other="rotation=-1.68 mat=wood"/>
<rubberblock x="560" y="555.8" lock="no" other="rotation=-0.387 mat=rubber"/></room>
		<room roomID="85871" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="dnag">
	<figitdropper x="447.6" y="6" lock="no" other=""/>
<figitbox x="383.7" y="307.6" lock="no" other="par=r/0/1"/>
<rubberblock x="509.25" y="181.85" lock="no" other="rotation=-1.109 mat=conc"/></room>
		<room roomID="85865" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="gghssa111111">
	<figitdropper x="159.1" y="6" lock="no" other=""/>
<figitdropper x="427.65" y="6" lock="no" other=""/>
<figitdropper x="322.25" y="6" lock="no" other=""/>
<figitbox x="181.7" y="549.05" lock="no" other="par=r/0/1"/>
<figitbox x="285.85" y="509.25" lock="no" other="par=r/0/1"/>
<figitbox x="427.8" y="395.6" lock="no" other="par=r/0/3"/>
<rubberblock x="169.65" y="121.5" lock="no" other="rotation=0.859 mat=wood"/>
<rubberblock x="231.5" y="375.75" lock="no" other="rotation=0 mat=conc"/>
<fixedblock x="180.85" y="473.45" lock="no" other="rotation=0"/>
<pvcpipe x="506.4" y="258.05" lock="no" other="rotation=0"/>
<fidgitcannon x="199.35" y="174.2" lock="no" other="chute=-15"/>
<fidgitcannon x="500" y="306.8" lock="no" other="chute=179.139"/></room>
		<room roomID="85749" status="new" type="open" setting="main" title="you need paint" fg="blank" bg="bg/1.swf" author="leahanne99">
	<figitdropper x="194.5" y="6" lock="no" other=""/>
<figitdropper x="367.5" y="6" lock="no" other=""/>
<figitbox x="286.5" y="556" lock="no" other="par=r/1/80"/>
<rubberblock x="401.5" y="199.75" lock="no" other="rotation=-0.635 mat=rubber"/>
<rubberblock x="223.5" y="187.75" lock="no" other="rotation=0.786 mat=rubber"/>
<rubberblock x="448.5" y="465.75" lock="no" other="rotation=-1.041 mat=rubber"/>
<rubberblock x="261.5" y="546.75" lock="no" other="rotation=-1.892 mat=rubber"/>
<rubberblock x="407.5" y="548" lock="no" other="rotation=-1.278 mat=rubber"/>
<rubberblock x="225.5" y="449.75" lock="no" other="rotation=1.181 mat=rubber"/>
<rubberblock x="500.5" y="377.75" lock="no" other="rotation=-0.869 mat=rubber"/>
<rubberblock x="191.5" y="352.75" lock="no" other="rotation=-1.922 mat=rubber"/></room>
		<room roomID="85624" status="" type="open" setting="" title="" fg="" bg="" author="michael13579">
	</room>
		<room roomID="85500" status="new" type="open" setting="wind" title="greenwind" fg="blank" bg="bg/1.swf" author="ZACHruss1414">
	<figitdropper x="104.5" y="6" lock="no" other=""/>
<figitdropper x="296.5" y="6" lock="no" other=""/>
<figitdropper x="463.5" y="6" lock="no" other=""/>
<figitbox x="263.5" y="556" lock="no" other="par=r/3/1"/>
<fixedblock x="251.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="255.5" y="552.5" lock="no" other="rotation=0"/>
<fixedblock x="286.5" y="540.5" lock="no" other="rotation=0"/>
<fixedblock x="318.5" y="549.5" lock="no" other="rotation=0"/>
<fixedblock x="349.5" y="550.5" lock="no" other="rotation=0"/>
<fixedblock x="355.5" y="579" lock="no" other="rotation=0"/></room>
		<room roomID="85419" status="new" type="open" setting="main" title="My first room" fg="blank" bg="bg/3.swf" author="fiyt4444">
	<figitdropper x="302.5" y="6" lock="no" other=""/>
<figitbox x="299.5" y="237.5" lock="no" other="par=r/0/1"/>
<rubberblock x="336.5" y="296.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="85402" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/1.swf" author="2021wilson">
	</room>
		<room roomID="85399" status="new" type="open" setting="main" title="BOOMFIGILATA" fg="blank" bg="bg/12.swf" author="annakitten100">
	<figitdropper x="486.5" y="6" lock="no" other=""/>
<figitbox x="34.5" y="556" lock="no" other="par=s/9/10"/>
<figitdivider x="39.5" y="432.5" lock="no" other=""/>
<figitpainter x="489.5" y="70.5" lock="no" other="color=9"/>
<elbowpipe x="101.5" y="382" lock="no" other="rotation=-1.546"/>
<conveyorbelt x="406" y="158.5" lock="no" other="cv=lt_slow"/>
<conveyorbelt x="296.5" y="252.5" lock="no" other="cv=lt_med"/>
<conveyorbelt x="149.5" y="372.5" lock="no" other="cv=lt_fast"/></room>
		<room roomID="85318" status="new" type="open" setting="main" title="My New Roomfood" fg="blank" bg="bg/14.swf" author="ellisb850">
	<figitdropper x="82.5" y="6" lock="no" other=""/>
<figitdropper x="6" y="6" lock="no" other=""/>
<figitdropper x="150.5" y="6" lock="no" other=""/>
<figitbox x="60.5" y="556" lock="no" other="par=l/0/90"/>
<rubberblock x="197.5" y="285.75" lock="no" other="rotation=0.871 mat=rubber"/>
<rubberblock x="298.5" y="398.75" lock="no" other="rotation=-0.629 mat=rubber"/>
<rubberblock x="310.5" y="232.75" lock="no" other="rotation=-1.017 mat=rubber"/>
<rubberblock x="33" y="546.75" lock="no" other="rotation=1.495 mat=rubber"/>
<rubberblock x="48.5" y="481.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="341.5" y="312.75" lock="no" other="rotation=1.518 mat=rubber"/>
<rubberblock x="179.5" y="189.75" lock="no" other="rotation=1.792 mat=rubber"/>
<rubberblock x="341.5" y="443.75" lock="no" other="rotation=1.874 mat=rubber"/>
<rubberblock x="316.5" y="144.75" lock="no" other="rotation=-1.562 mat=rubber"/>
<rubberblock x="315.5" y="59" lock="no" other="rotation=-1.655 mat=rubber"/>
<pvcpipe x="186" y="527.5" lock="no" other="rotation=0"/>
<pvcpipe x="287.5" y="528.5" lock="no" other="rotation=0"/>
<figitcombiner x="189.5" y="129.5" lock="no" other=""/>
<conveyorbelt x="11" y="105.5" lock="no" other="cv=rt_fast"/></room>
		<room roomID="85237" status="new" type="open" setting="moon" title="hhhooowww??????" fg="blank" bg="bg/7.swf" author="miles141">
	<figitdropper x="320.5" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="10.5" y="6" lock="no" other=""/>
<figitbox x="312.5" y="555" lock="no" other="par=r/0/1"/>
<figitbox x="522" y="551.5" lock="no" other="par=r/0/1"/>
<figitbox x="6.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="426.5" y="24.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="508.5" y="24.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="302.5" y="24.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="243.5" y="24.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="174.5" y="24.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="104.5" y="24.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="391.5" y="95.5" lock="no" other="rotation=0"/>
<fixedblock x="527.5" y="90.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="93.5" lock="no" other="rotation=0"/>
<fixedblock x="321.5" y="96.5" lock="no" other="rotation=0"/>
<fixedblock x="80.5" y="95.5" lock="no" other="rotation=0"/>
<fixedblock x="21.5" y="92.5" lock="no" other="rotation=0"/></room>
		<room roomID="85223" status="" type="open" setting="" title="" fg="" bg="" author="2021wilson">
	</room>
		<room roomID="85219" status="" type="open" setting="" title="" fg="" bg="" author="2021wilson">
	</room>
		<room roomID="85058" status="new" type="open" setting="main" title="The Crystal" fg="blank" bg="bg/6.swf" author="cows934">
	<figitdropper x="339.5" y="6" lock="no" other=""/>
<figitbox x="354.5" y="437.5" lock="no" other="par=r/0/1"/>
<rubberblock x="336.5" y="177.75" lock="no" other="rotation=1.509 mat=rubber"/>
<rubberblock x="461.5" y="287.75" lock="no" other="rotation=-0.586 mat=conc"/>
<rubberblock x="331.5" y="279.75" lock="no" other="rotation=1.395 mat=rubber"/>
<rubberblock x="462.5" y="353.75" lock="no" other="rotation=1.269 mat=wood"/>
<rubberblock x="321.5" y="355.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="516.5" y="142.75" lock="no" other="rotation=-1.566 mat=rubber"/>
<rubberblock x="517.5" y="237.75" lock="no" other="rotation=-0.624 mat=rubber"/>
<fixedblock x="329.5" y="91.5" lock="no" other="rotation=0"/>
<fixedblock x="423.5" y="89.5" lock="no" other="rotation=0"/>
<fixedblock x="328.5" y="125.5" lock="no" other="rotation=0"/>
<fixedblock x="422.5" y="189.5" lock="no" other="rotation=0"/>
<fixedblock x="359.5" y="166.5" lock="no" other="rotation=0"/></room>
		<room roomID="84074" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/6.swf" author="jade122">
	<figitdropper x="391.5" y="6" lock="no" other=""/>
<figitbox x="397.5" y="77.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="84053" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="braydenkent653">
	<figitdropper x="290.7" y="6" lock="no" other=""/>
<figitbox x="511.15" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="292.95" y="498.35" lock="no" other="rotation=0.452 mat=rubber"/>
<pvcpipe x="322.2" y="122" lock="no" other="rotation=1.578"/>
<pvcpipe x="322.85" y="221.2" lock="no" other="rotation=1.59"/>
<pvcpipe x="321.35" y="322.2" lock="no" other="rotation=-1.547"/>
<pvcpipe x="451.2" y="427.6" lock="no" other="rotation=0"/></room>
		<room roomID="83621" status="new" type="open" setting="main" title="My New Roomweee" fg="blank" bg="bg/11.swf" author="acoolcat">
	<figitdropper x="517.5" y="6" lock="no" other=""/>
<figitdropper x="332.5" y="6" lock="no" other=""/>
<figitdropper x="139.5" y="6" lock="no" other=""/>
<figitbox x="292.5" y="556" lock="no" other="par=l/10/100"/>
<pvcpipe x="498.5" y="424.5" lock="no" other="rotation=-0.971"/>
<pvcpipe x="246.5" y="499.5" lock="no" other="rotation=0.401"/>
<pvcpipe x="419.5" y="490.5" lock="no" other="rotation=-0.442"/>
<pvcpipe x="188.5" y="450.5" lock="no" other="rotation=0.92"/>
<figitcombiner x="473.5" y="285.5" lock="no" other=""/>
<figitcombiner x="287.5" y="315.5" lock="no" other=""/>
<figitcombiner x="111.5" y="325.5" lock="no" other=""/>
<figitpainter x="519.5" y="78.5" lock="no" other="color=10"/>
<figitpainter x="344.5" y="78.5" lock="no" other="color=10"/>
<figitpainter x="155.5" y="84.5" lock="no" other="color=10"/></room>
		<room roomID="82820" status="new" type="open" setting="main" title="isaacs" fg="blank" bg="bg/8.swf" author="isaac3406">
	<figitdropper x="269.5" y="6" lock="no" other=""/>
<figitdropper x="338.5" y="6" lock="no" other=""/>
<figitdropper x="203.5" y="6" lock="no" other=""/>
<rubberblock x="496.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="418" y="575" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="347.5" y="575" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="231.5" y="575" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="114.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="172.5" y="575" lock="no" other="rotation=0 mat=rubber"/>
<figitcombiner x="338.5" y="136.5" lock="no" other=""/>
<figitdivider x="269.5" y="137.5" lock="no" other=""/>
<figitpainter x="276.5" y="73.5" lock="no" other="color=3"/>
<figitpainter x="339.5" y="69.5" lock="no" other="color=2"/>
<figitpainter x="206.5" y="73.5" lock="no" other="color=5"/>
<spring x="6.5" y="563.5" lock="no" other="dir=up"/>
<spring x="48.5" y="563.5" lock="no" other="dir=up"/>
<spring x="558" y="563.5" lock="no" other="dir=up"/>
<spring x="517.5" y="563.5" lock="no" other="dir=up"/>
<spring x="267.5" y="563.5" lock="no" other="dir=up"/>
<fidgitcannon x="218.5" y="231.5" lock="no" other="chute=178.463"/>
<fidgitcannon x="317.5" y="231.5" lock="no" other="chute=-2.773"/></room>
		<room roomID="82811" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="isaac3406">
	<figitdropper x="259.5" y="6" lock="no" other=""/>
<figitdropper x="419.5" y="6" lock="no" other=""/>
<figitdropper x="526.5" y="6" lock="no" other=""/>
<rubberblock x="488.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="134.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="212.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="414.5" y="575" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="286.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="356.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<figitcombiner x="401.5" y="130.5" lock="no" other=""/>
<figitdivider x="409" y="289.5" lock="no" other=""/>
<figitpainter x="264.5" y="72.5" lock="no" other="color=3"/>
<figitpainter x="421.5" y="71.5" lock="no" other="color=3"/>
<figitpainter x="529.5" y="68.5" lock="no" other="color=3"/>
<spring x="7.5" y="560.5" lock="no" other="dir=up"/>
<spring x="558" y="563.5" lock="no" other="dir=up"/>
<spring x="512.5" y="563.5" lock="no" other="dir=up"/>
<spring x="50.5" y="561.5" lock="no" other="dir=up"/>
<elbowpipe x="544" y="236" lock="no" other="rotation=1.611"/>
<fidgitcannon x="244.5" y="182.5" lock="no" other="chute=0.674"/></room>
		<room roomID="82602" status="new" type="open" setting="main" title="The Confusion" fg="blank" bg="bg/1.swf" author="kilekamill">
	<figitdropper x="91.5" y="6" lock="no" other=""/>
<figitdropper x="530.5" y="6" lock="no" other=""/>
<figitdropper x="397.5" y="6" lock="no" other=""/>
<figitbox x="476.5" y="398.5" lock="no" other="par=r/0/15"/>
<figitbox x="285.5" y="379.5" lock="no" other="par=r/0/15"/>
<figitbox x="377.5" y="512.5" lock="no" other="par=r/0/15"/>
<rubberblock x="137.5" y="252.75" lock="no" other="rotation=0.444 mat=conc"/>
<pvcpipe x="230.5" y="222.5" lock="no" other="rotation=0"/>
<pvcpipe x="330.5" y="222.5" lock="no" other="rotation=0"/>
<pvcpipe x="519.5" y="128.5" lock="no" other="rotation=-0.776"/>
<pvcpipe x="427.5" y="96.5" lock="no" other="rotation=-1.564"/></room>
		<room roomID="82591" status="new" type="open" setting="moon" title="The moon" fg="blank" bg="bg/1.swf" author="helo892">
	<figitdropper x="120.5" y="6" lock="no" other=""/>
<figitdropper x="302.5" y="6" lock="no" other=""/>
<figitdropper x="434.5" y="6" lock="no" other=""/>
<figitbox x="113.5" y="92.5" lock="no" other="par=r/0/1"/>
<figitbox x="303.5" y="87.5" lock="no" other="par=r/0/1"/>
<figitbox x="426.5" y="79.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="82322" status="new" type="open" setting="main" title="the immposible" fg="blank" bg="bg/6.swf" author="troy26760">
	<figitdropper x="287.5" y="6" lock="no" other=""/>
<figitbox x="453.5" y="302.5" lock="no" other="par=r/0/8"/>
<rubberblock x="306.5" y="319.75" lock="no" other="rotation=0.444 mat=rubber"/></room>
		<room roomID="82231" status="new" type="open" setting="main" title="battlefield" fg="blank" bg="bg/11.swf" author="master10882">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitdropper x="490.5" y="6" lock="no" other=""/>
<figitbox x="13.5" y="545.5" lock="no" other="par=r/0/1"/>
<rubberblock x="129.5" y="175.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="187.5" y="175.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="244.5" y="175.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="313.5" y="174.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="389.5" y="174.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="446.5" y="48" lock="no" other="rotation=-0.653 mat=rubber"/>
<fixedblock x="585" y="104.5" lock="no" other="rotation=0"/>
<fixedblock x="565.5" y="121.5" lock="no" other="rotation=0"/>
<fixedblock x="30.5" y="435.5" lock="no" other="rotation=0"/>
<fixedblock x="31.5" y="410.5" lock="no" other="rotation=0"/>
<fixedblock x="31.5" y="399.5" lock="no" other="rotation=0"/>
<pvcpipe x="466.5" y="222.5" lock="no" other="rotation=-0.617"/>
<pvcpipe x="550" y="266.5" lock="no" other="rotation=1.588"/>
<pvcpipe x="456.5" y="554.5" lock="no" other="rotation=0"/>
<pvcpipe x="365.5" y="553.5" lock="no" other="rotation=0"/>
<pvcpipe x="272.5" y="553" lock="no" other="rotation=0"/>
<pvcpipe x="181.5" y="551.5" lock="no" other="rotation=0"/>
<pvcpipe x="143.5" y="551.5" lock="no" other="rotation=0"/>
<figitcombiner x="6" y="449.5" lock="no" other=""/>
<figitpainter x="6" y="30.5" lock="no" other="color=1"/>
<figitpainter x="494.5" y="23.5" lock="no" other="color=9"/>
<figitpainter x="515" y="241.5" lock="no" other="color=2"/>
<figitpainter x="28.5" y="269.5" lock="no" other="color=2"/>
<spring x="427.5" y="162.5" lock="no" other="dir=up"/>
<spring x="426.5" y="160.5" lock="no" other="dir=up"/>
<spring x="426.5" y="161.5" lock="no" other="dir=up"/>
<spring x="427.5" y="160.5" lock="no" other="dir=up"/>
<spring x="428.5" y="161.5" lock="no" other="dir=up"/>
<elbowpipe x="56" y="114" lock="no" other="rotation=-3.14"/>
<elbowpipe x="73" y="268" lock="no" other="rotation=-1.562"/>
<elbowpipe x="549" y="443" lock="no" other="rotation=0"/>
<elbowpipe x="550" y="533.5" lock="no" other="rotation=1.567"/>
<conveyorbelt x="251.5" y="270.5" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="84.5" y="271.5" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="316.5" y="443.5" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="93.5" y="443.5" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="146.5" y="443.5" lock="no" other="cv=lt_fast"/>
<fidgitcannon x="10.5" y="315.5" lock="no" other="chute=-7.427"/>
<fidgitcannon x="497" y="317.5" lock="no" other="chute=-170.106"/></room>
		<room roomID="81630" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="syndyla">
	<figitdropper x="25.5" y="6" lock="no" other=""/>
<figitbox x="28.9" y="217.6" lock="no" other="par=r/0/1"/>
<rubberblock x="70.6" y="153.6" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="240.2" y="156.35" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="317.85" y="155.45" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="396.55" y="157.35" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="217.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="482.8" y="236.05" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="408.05" y="263.7" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="229.8" y="273.35" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="148.4" y="274.3" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="71.9" y="274.5" lock="no" other="rotation=0 mat=rubber"/>
<pvcpipe x="153.7" y="111.5" lock="no" other="rotation=0"/>
<pvcpipe x="486.45" y="112.3" lock="no" other="rotation=0"/>
<pvcpipe x="320.6" y="232.15" lock="no" other="rotation=0"/></room>
		<room roomID="81628" status="new" type="open" setting="wind" title="Syndela's room" fg="blank" bg="bg/1.swf" author="syndyla">
	<figitdropper x="10.25" y="6" lock="no" other=""/>
<figitdropper x="265.25" y="6" lock="no" other=""/>
<figitdropper x="458.85" y="6" lock="no" other=""/>
<figitbox x="236.9" y="488.55" lock="no" other="par=r/0/1"/>
<figitbox x="500.35" y="361.3" lock="no" other="par=l/5/1"/>
<figitbox x="133.35" y="341.1" lock="no" other="par=r/0/1"/>
<rubberblock x="507.75" y="222.45" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="194.35" y="181.2" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="344.95" y="144.85" lock="no" other="rotation=-0.96 mat=wood"/>
<rubberblock x="173.25" y="398.9" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="537.45" y="421" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="275.75" y="543.65" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="125.7" lock="no" other="rotation=-0.703 mat=rubber"/>
<rubberblock x="444.5" y="303.95" lock="no" other="rotation=0.735 mat=rubber"/>
<rubberblock x="105" y="141.9" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="58" y="313.7" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="57.85" y="392.25" lock="no" other="rotation=0"/>
<fixedblock x="407.8" y="61.6" lock="no" other="rotation=0"/>
<fixedblock x="392.5" y="182.35" lock="no" other="rotation=0"/>
<fixedblock x="200.8" y="288.8" lock="no" other="rotation=0"/>
<fixedblock x="334" y="399.05" lock="no" other="rotation=0"/>
<fixedblock x="489.3" y="511.1" lock="no" other="rotation=0"/>
<fixedblock x="182.65" y="576.3" lock="no" other="rotation=0"/></room>
		<room roomID="81618" status="new" type="open" setting="main" title="boom room" fg="blank" bg="bg/5.swf" author="mimilana">
	<figitdropper x="279.5" y="6" lock="no" other=""/>
<figitdropper x="6" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="444.25" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="6.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="253.2" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="360.75" y="244.05" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="130.35" y="308.55" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46" y="265.85" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="240.9" y="247.25" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="268.15" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="483.95" y="333.8" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="469.75" y="395.05" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="179.45" y="366.65" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="159.9" y="454.2" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="407.3" y="472.9" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="257.9" y="348.05" lock="no" other="rotation=0"/>
<fixedblock x="263.2" y="308.65" lock="no" other="rotation=0"/>
<fixedblock x="353" y="355.7" lock="no" other="rotation=0"/>
<fixedblock x="355.3" y="314.25" lock="no" other="rotation=0"/>
<fixedblock x="263.25" y="379.85" lock="no" other="rotation=0"/>
<fixedblock x="255.6" y="421.55" lock="no" other="rotation=0"/>
<fixedblock x="239.25" y="471.8" lock="no" other="rotation=0"/>
<fixedblock x="355.3" y="400.75" lock="no" other="rotation=0"/>
<fixedblock x="352" y="438" lock="no" other="rotation=0"/>
<fixedblock x="355.4" y="482.75" lock="no" other="rotation=0"/>
<fixedblock x="357.45" y="534.3" lock="no" other="rotation=0"/>
<fixedblock x="380.45" y="579" lock="no" other="rotation=0"/>
<fixedblock x="217.4" y="525.6" lock="no" other="rotation=0"/>
<fixedblock x="208.6" y="579" lock="no" other="rotation=0"/>
<fixedblock x="361.8" y="197.05" lock="no" other="rotation=0"/>
<pvcpipe x="38" y="146.95" lock="no" other="rotation=-1.535"/>
<pvcpipe x="303.5" y="134.85" lock="no" other="rotation=1.545"/>
<pvcpipe x="550" y="165.4" lock="no" other="rotation=1.615"/>
<pvcpipe x="299.7" y="312.4" lock="no" other="rotation=1.6"/>
<pvcpipe x="242.55" y="184" lock="no" other="rotation=-1.599"/>
<pvcpipe x="366.35" y="179.45" lock="no" other="rotation=1.611"/></room>
		<room roomID="81316" status="new" type="open" setting="main" title="Zachary" fg="blank" bg="bg/1.swf" author="2180Rain">
	<figitdropper x="6.5" y="6" lock="no" other=""/>
<figitbox x="6.5" y="195.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="81220" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="jackster530">
	<figitdropper x="337.5" y="6" lock="no" other=""/>
<figitdropper x="287.5" y="6" lock="no" other=""/>
<figitbox x="426.5" y="555" lock="no" other="par=l/0/1"/>
<rubberblock x="390.5" y="161" lock="no" other="rotation=-0.862 mat=rubber"/>
<rubberblock x="112.5" y="335.75" lock="no" other="rotation=-2.343 mat=rubber"/>
<rubberblock x="28" y="231.75" lock="no" other="rotation=1.597 mat=rubber"/>
<rubberblock x="381.5" y="415.75" lock="no" other="rotation=-1.504 mat=rubber"/>
<rubberblock x="560" y="241.75" lock="no" other="rotation=2.155 mat=rubber"/>
<rubberblock x="207.5" y="418.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="291.5" y="426.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="363.5" y="434.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46.5" y="287.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="143" y="392.75" lock="no" other="rotation=0.661 mat=rubber"/>
<fixedblock x="26.5" y="173.5" lock="no" other="rotation=0"/>
<fixedblock x="21.5" y="135.5" lock="no" other="rotation=0"/>
<fixedblock x="21.5" y="112.5" lock="no" other="rotation=0"/>
<fixedblock x="21" y="82.5" lock="no" other="rotation=0"/>
<pvcpipe x="294.5" y="187.5" lock="no" other="rotation=-0.83"/>
<pvcpipe x="388.5" y="328.5" lock="no" other="rotation=1.75"/>
<pvcpipe x="413.5" y="229.5" lock="no" other="rotation=2.252"/>
<pvcpipe x="469.5" y="306.5" lock="no" other="rotation=0"/>
<pvcpipe x="550" y="305.5" lock="no" other="rotation=0"/>
<pvcpipe x="277.5" y="36.5" lock="no" other="rotation=0"/>
<pvcpipe x="175.5" y="36" lock="no" other="rotation=0"/>
<pvcpipe x="75.5" y="36" lock="no" other="rotation=0"/>
<figitcombiner x="413.5" y="439.5" lock="no" other=""/></room>
		<room roomID="80667" status="new" type="open" setting="main" title="purple fidgits" fg="blank" bg="bg/2.swf" author="istar58">
	<figitdropper x="363.5" y="6" lock="no" other=""/>
<figitbox x="440" y="556" lock="no" other="par=r/1/1"/>
<rubberblock x="379.5" y="323.75" lock="no" other="rotation=0 mat=rubber"/>
<figitpainter x="353.5" y="174.5" lock="no" other="color=1"/></room>
		<room roomID="79502" status="new" type="open" setting="main" title="yellow" fg="blank" bg="bg/1.swf" author="bugyp">
	<figitdropper x="149.9" y="6" lock="no" other=""/>
<figitbox x="239.1" y="556" lock="no" other="par=r/0/100"/>
<rubberblock x="155.3" y="105.95" lock="no" other="rotation=0.815 mat=rubber"/>
<rubberblock x="358.5" y="294.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="239.3" y="274.75" lock="no" other="rotation=0.616 mat=conc"/>
<rubberblock x="521.7" y="122.75" lock="no" other="rotation=0.866 mat=rubber"/>
<rubberblock x="431.3" y="233.95" lock="no" other="rotation=-0.94 mat=conc"/></room>
		<room roomID="79231" status="new" type="open" setting="main" title="Big and Small" fg="blank" bg="bg/5.swf" author="cyberchase9965">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="6" y="556" lock="no" other="par=s/3/4"/>
<figitbox x="254.5" y="556" lock="no" other="par=l/5/7"/>
<rubberblock x="358.5" y="553" lock="no" other="rotation=1.578 mat=rubber"/>
<rubberblock x="361.5" y="472.75" lock="no" other="rotation=1.598 mat=rubber"/>
<rubberblock x="363.5" y="391.75" lock="no" other="rotation=1.573 mat=rubber"/>
<rubberblock x="362.5" y="332.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="234.5" y="302.5" lock="no" other="rotation=0"/>
<fixedblock x="232.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="232.5" y="548.5" lock="no" other="rotation=0"/>
<fixedblock x="233.5" y="517.5" lock="no" other="rotation=0"/>
<fixedblock x="233.5" y="486.5" lock="no" other="rotation=0"/>
<fixedblock x="233.5" y="456.5" lock="no" other="rotation=0"/>
<fixedblock x="233.5" y="426.5" lock="no" other="rotation=0"/>
<fixedblock x="233.5" y="395.5" lock="no" other="rotation=0"/>
<fixedblock x="233.5" y="364.5" lock="no" other="rotation=0"/>
<fixedblock x="233.5" y="333.5" lock="no" other="rotation=0"/>
<fixedblock x="363.5" y="298.5" lock="no" other="rotation=0"/>
<pvcpipe x="363.5" y="255.5" lock="no" other="rotation=0"/>
<pvcpipe x="237.5" y="258.5" lock="no" other="rotation=0"/>
<spring x="537.5" y="364.5" lock="no" other="dir=up"/>
<elbowpipe x="550" y="232" lock="no" other="rotation=1.551"/></room>
		<room roomID="79185" status="new" type="open" setting="wind" title="Awesome+Butter" fg="blank" bg="bg/4.swf" author="mine4gold">
	<figitdropper x="14.5" y="6" lock="no" other=""/>
<figitbox x="400.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="139.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="49.5" y="495.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="300.5" y="493.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="509.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="450.5" y="393.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="176.5" y="414.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="293.5" y="295.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="49.5" y="346.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="355.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46.5" y="172.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="155.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="79144" status="new" type="open" setting="main" title="compaintation" fg="blank" bg="bg/11.swf" author="ultamike2130">
	<figitdropper x="269.5" y="6" lock="no" other=""/>
<figitbox x="335.5" y="556" lock="no" other="par=l/3/45"/>
<pvcpipe x="327.5" y="296.5" lock="no" other="rotation=0.985"/>
<figitcombiner x="255.5" y="190.5" lock="no" other=""/>
<figitpainter x="339.5" y="351.5" lock="no" other="color=3"/></room>
		<room roomID="78782" status="new" type="open" setting="main" title="MY ROOM" fg="blank" bg="bg/5.swf" author="haylog24">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="560" y="178.05" lock="no" other="rotation=-0.399 mat=rubber"/>
<rubberblock x="451.5" y="245.95" lock="no" other="rotation=-0.234 mat=rubber"/>
<rubberblock x="350.6" y="281.25" lock="no" other="rotation=0 mat=wood"/>
<rubberblock x="335.9" y="464.1" lock="no" other="rotation=0.402 mat=rubber"/>
<rubberblock x="452.75" y="529.9" lock="no" other="rotation=-0.002 mat=rubber"/>
<rubberblock x="215.4" y="251.55" lock="no" other="rotation=1.591 mat=conc"/>
<rubberblock x="236.85" y="401.2" lock="no" other="rotation=0.487 mat=rubber"/></room>
		<room roomID="77342" status="new" type="open" setting="main" title="My New Rooghym" fg="blank" bg="bg/2.swf" author="Ameliarr1234">
	<figitdropper x="457.5" y="6" lock="no" other=""/>
<figitdropper x="283.5" y="6" lock="no" other=""/>
<figitbox x="442.5" y="231.5" lock="no" other="par=l/0/0"/>
<figitcombiner x="431.5" y="81.5" lock="no" other=""/></room>
		<room roomID="76682" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/3.swf" author="seth14425">
	<figitdropper x="137.5" y="6" lock="no" other=""/>
<figitdropper x="31" y="6" lock="no" other=""/>
<figitbox x="168.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="225.5" y="147.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="337.5" y="239.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="456.5" y="368.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="388.5" y="416.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="296.5" y="487.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="299.5" y="539.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46" y="208.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="126.5" y="315.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="124.5" y="428.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="60.5" y="513.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="492.5" y="342.5" lock="no" other="rotation=0"/></room>
		<room roomID="76414" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/1.swf" author="lukah22">
	<figitdropper x="47.5" y="6" lock="no" other=""/>
<conveyorbelt x="6" y="178.5" lock="no" other="cv=rt_fast"/></room>
		<room roomID="75842" status="" type="open" setting="" title="" fg="" bg="" author="APETERSON88">
	</room>
		<room roomID="75782" status="new" type="open" setting="moon" title="nate's migye" fg="blank" bg="bg/1.swf" author="spookmanq127">
	<figitdropper x="272.5" y="6" lock="no" other=""/>
<figitdropper x="72.5" y="6" lock="no" other=""/>
<figitdropper x="483.5" y="6" lock="no" other=""/>
<figitbox x="251.5" y="462.5" lock="no" other="par=r/0/1"/>
<figitbox x="457.5" y="472.5" lock="no" other="par=r/0/1"/>
<figitbox x="87.5" y="456.5" lock="no" other="par=r/0/1"/>
<rubberblock x="292.5" y="518.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="114.5" y="519" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="494.5" y="515.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="74757" status="new" type="open" setting="wind" title="click it" fg="blank" bg="bg/2.swf" author="sandyrc">
	<figitdropper x="30" y="6" lock="no" other=""/>
<figitdropper x="311.5" y="6" lock="no" other=""/>
<figitbox x="108.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="245.5" y="177.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="432.5" y="177.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="512.5" y="181.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="170.5" y="179.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="564.5" y="180.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="184.5" lock="no" other="rotation=0"/>
<fidgitcannon x="287.5" y="189.5" lock="no" other="chute=88.025"/>
<fidgitcannon x="20.5" y="164.5" lock="no" other="chute=92.031"/></room>
		<room roomID="73378" status="new" type="open" setting="wind" title="thespeeder" fg="blank" bg="bg/6.swf" author="michael6565">
	<figitdropper x="6" y="6" lock="no" other=""/>
<rubberblock x="46.5" y="251.95" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="124.75" y="254.3" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="197.35" y="260.25" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="273.3" y="268.3" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="351.8" y="274.3" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="431.4" y="280.1" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="509.65" y="285.8" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="405.65" y="531.2" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="481.75" y="531.5" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="556.6" y="531.45" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="585" y="524.1" lock="no" other="rotation=0"/>
<fixedblock x="585" y="553.25" lock="no" other="rotation=0"/>
<fixedblock x="585" y="493.25" lock="no" other="rotation=0"/>
<fixedblock x="585" y="466.35" lock="no" other="rotation=0"/>
<fixedblock x="582.95" y="436.1" lock="no" other="rotation=0"/>
<fixedblock x="585" y="406.6" lock="no" other="rotation=0"/>
<figitdivider x="6" y="88.5" lock="no" other=""/>
<figitdivider x="6" y="418.3" lock="no" other=""/>
<conveyorbelt x="406" y="387.6" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="239.9" y="387.9" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="70.65" y="388.15" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="6.5" y="506" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="175.65" y="508.7" lock="no" other="cv=rt_fast"/></room>
		<room roomID="73312" status="new" type="open" setting="main" title="tons of traffic" fg="blank" bg="bg/6.swf" author="ksharpay">
	<figitdropper x="204.5" y="6" lock="no" other=""/>
<figitbox x="494.5" y="158" lock="no" other="par=l/10/8"/>
<rubberblock x="352.5" y="336.75" lock="no" other="rotation=-1.538 mat=wood"/>
<figitcombiner x="90.5" y="164.5" lock="no" other=""/>
<figitpainter x="109.5" y="232.5" lock="no" other="color=10"/>
<spring x="282.5" y="384.5" lock="no" other="dir=right"/>
<elbowpipe x="225.5" y="126" lock="no" other="rotation=1.604"/>
<elbowpipe x="322.5" y="140" lock="no" other="rotation=-1.572"/>
<conveyorbelt x="82.5" y="374.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="327" y="148.5" lock="no" other="cv=rt_med"/></room>
		<room roomID="73266" status="new" type="open" setting="main" title="TORTURE" fg="blank" bg="bg/1.swf" author="minecraft856">
	<figitdropper x="7.6" y="6" lock="no" other=""/>
<figitdropper x="75.9" y="6" lock="no" other=""/>
<figitdropper x="142.85" y="6" lock="no" other=""/>
<figitbox x="156.55" y="327.15" lock="no" other="par=s/7/100"/>
<figitbox x="484.4" y="533.85" lock="no" other="par=l/1/10"/>
<figitbox x="76.4" y="170.5" lock="no" other="par=l/0/20"/>
<fixedblock x="580.7" y="540.5" lock="no" other="rotation=0"/>
<pvcpipe x="169.3" y="396.55" lock="no" other="rotation=0"/>
<pvcpipe x="271.4" y="396.6" lock="no" other="rotation=0"/>
<pvcpipe x="333.5" y="492.25" lock="no" other="rotation=1.599"/>
<pvcpipe x="191.55" y="290.15" lock="no" other="rotation=1.583"/>
<figitcombiner x="63.25" y="78.2" lock="no" other=""/>
<figitcombiner x="6" y="266.7" lock="no" other=""/>
<figitdivider x="141.5" y="76" lock="no" other=""/>
<figitdivider x="150.8" y="192.45" lock="no" other=""/>
<figitpainter x="15.35" y="201.8" lock="no" other="color=1"/>
<figitpainter x="151.65" y="130.25" lock="no" other="color=7"/>
<elbowpipe x="372.15" y="416.15" lock="no" other="rotation=0"/>
<conveyorbelt x="313.8" y="517.7" lock="no" other="cv=rt_med"/>
<fidgitcannon x="6" y="367.4" lock="no" other="chute=-15"/></room>
		<room roomID="72779" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/10.swf" author="stman33">
	<figitdropper x="297.5" y="6" lock="no" other=""/>
<figitdropper x="396.5" y="6" lock="no" other=""/>
<figitdropper x="207.5" y="6" lock="no" other=""/>
<figitbox x="206.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="410.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="322.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="508.5" y="350.75" lock="no" other="rotation=-0.777 mat=rubber"/>
<rubberblock x="194.5" y="353.75" lock="no" other="rotation=0.795 mat=rubber"/>
<rubberblock x="511.5" y="140.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="496.5" y="60.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="111.5" y="339.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="446.5" y="144.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="257.5" y="151.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="94.5" y="124.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="82.5" y="259.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="94.5" y="417.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="541.5" y="297.5" lock="no" other="rotation=0"/>
<fixedblock x="166.5" y="303.5" lock="no" other="rotation=0"/>
<fixedblock x="421.5" y="90.5" lock="no" other="rotation=0"/>
<fixedblock x="545.5" y="88.5" lock="no" other="rotation=0"/>
<fixedblock x="556.5" y="213.5" lock="no" other="rotation=0"/>
<fixedblock x="395.5" y="150.5" lock="no" other="rotation=0"/>
<fixedblock x="392.5" y="226.5" lock="no" other="rotation=0"/>
<fixedblock x="560.5" y="394.5" lock="no" other="rotation=0"/>
<fixedblock x="457.5" y="330.5" lock="no" other="rotation=0"/>
<fixedblock x="381.5" y="364.5" lock="no" other="rotation=0"/>
<fixedblock x="295.5" y="346.5" lock="no" other="rotation=0"/>
<fixedblock x="296.5" y="242.5" lock="no" other="rotation=0"/>
<fixedblock x="223.5" y="171.5" lock="no" other="rotation=0"/>
<fixedblock x="281.5" y="190.5" lock="no" other="rotation=0"/>
<fixedblock x="522.5" y="205.5" lock="no" other="rotation=0"/>
<pvcpipe x="218.5" y="264.5" lock="no" other="rotation=-0.523"/>
<pvcpipe x="490.5" y="246.5" lock="no" other="rotation=0.738"/>
<pvcpipe x="374.5" y="295.5" lock="no" other="rotation=0"/>
<pvcpipe x="514.5" y="483.5" lock="no" other="rotation=0"/>
<pvcpipe x="102.5" y="190.5" lock="no" other="rotation=0"/>
<pvcpipe x="194.5" y="93.5" lock="no" other="rotation=0"/>
<pvcpipe x="114" y="564" lock="no" other="rotation=0"/>
<pvcpipe x="79.5" y="46.5" lock="no" other="rotation=0"/>
<pvcpipe x="384.5" y="227.5" lock="no" other="rotation=0"/>
<pvcpipe x="332.5" y="302.5" lock="no" other="rotation=0"/>
<figitcombiner x="286.5" y="123.5" lock="no" other=""/>
<figitcombiner x="331.5" y="402.5" lock="no" other=""/>
<figitcombiner x="142.5" y="438.5" lock="no" other=""/></room>
		<room roomID="72708" status="new" type="open" setting="moon" title="nbhjj" fg="blank" bg="bg/1.swf" author="Hunter3257">
	<figitdropper x="265" y="6" lock="no" other=""/>
<figitbox x="392.5" y="556" lock="no" other="par=s/0/1"/>
<figitbox x="120.5" y="551" lock="no" other="par=s/0/1"/>
<rubberblock x="296.5" y="328.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="293.5" y="394.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="361.5" y="386.75" lock="no" other="rotation=0.834 mat=rubber"/>
<rubberblock x="493.5" y="381.75" lock="no" other="rotation=-0.865 mat=rubber"/>
<rubberblock x="223.5" y="387.75" lock="no" other="rotation=-0.965 mat=rubber"/>
<rubberblock x="90.5" y="381.75" lock="no" other="rotation=0.857 mat=rubber"/>
<fixedblock x="339.5" y="280.5" lock="no" other="rotation=0"/>
<fixedblock x="264.5" y="280.5" lock="no" other="rotation=0"/>
<pvcpipe x="427.5" y="447.5" lock="no" other="rotation=1.56"/>
<pvcpipe x="156.5" y="454.5" lock="no" other="rotation=-1.575"/>
<figitdivider x="259.5" y="48.5" lock="no" other=""/>
<figitdivider x="257.5" y="267.5" lock="no" other=""/>
<fidgitcannon x="247.5" y="178.5" lock="no" other="chute=90"/></room>
		<room roomID="72050" status="new" type="open" setting="main" title="purple vs orang" fg="blank" bg="bg/1.swf" author="adrian2099">
	<figitdropper x="6.5" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<rubberblock x="462.5" y="264.95" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="404.1" y="506.4" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="233.05" y="293" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="280.85" y="184.5" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="515.35" y="404.4" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46.5" y="300.1" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="408.5" y="101.15" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="219.85" y="81" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="233.3" y="504" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="362.95" y="370.55" lock="no" other="rotation=0 mat=rubber"/>
<figitpainter x="535.4" y="74.3" lock="no" other="color=4"/>
<figitpainter x="7.65" y="72.65" lock="no" other="color=1"/>
<conveyorbelt x="6.5" y="429.2" lock="no" other="cv=rt_med"/>
<conveyorbelt x="395.95" y="546.2" lock="no" other="cv=lt_med"/>
<conveyorbelt x="86.85" y="568" lock="no" other="cv=rt_med"/>
<conveyorbelt x="403.15" y="185.3" lock="no" other="cv=lt_med"/>
<conveyorbelt x="12.2" y="206.45" lock="no" other="cv=rt_med"/></room>
		<room roomID="71437" status="new" type="open" setting="wind" title="bounce land" fg="blank" bg="bg/6.swf" author="Richboy77">
	<figitdropper x="221.5" y="6" lock="no" other=""/>
<figitdropper x="400.5" y="6" lock="no" other=""/>
<figitdropper x="59.5" y="6" lock="no" other=""/>
<rubberblock x="240.5" y="538.75" lock="no" other="rotation=-1.02 mat=rubber"/>
<rubberblock x="391.5" y="228.75" lock="no" other="rotation=-0.528 mat=rubber"/>
<rubberblock x="108.5" y="236.75" lock="no" other="rotation=0.662 mat=rubber"/>
<rubberblock x="258.5" y="240.75" lock="no" other="rotation=0.582 mat=rubber"/>
<rubberblock x="209.5" y="386.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="329.5" y="180.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="480.5" y="191.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="177.5" y="221.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="370.5" y="560.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="500.5" y="547.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="69747" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/1.swf" author="ivan544">
	</room>
		<room roomID="69501" status="new" type="open" setting="main" title="super easy room" fg="blank" bg="bg/2.swf" author="nanda56">
	<figitdropper x="278.5" y="6" lock="no" other=""/>
<figitbox x="280" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="362.5" y="112.75" lock="no" other="rotation=-1.561 mat=rubber"/>
<rubberblock x="364.5" y="191.75" lock="no" other="rotation=-1.588 mat=rubber"/>
<rubberblock x="366" y="347.75" lock="no" other="rotation=1.54 mat=rubber"/>
<rubberblock x="266.5" y="269.75" lock="no" other="rotation=1.555 mat=rubber"/>
<rubberblock x="263.5" y="424.75" lock="no" other="rotation=1.571 mat=rubber"/>
<rubberblock x="266.5" y="113.75" lock="no" other="rotation=-1.524 mat=rubber"/>
<rubberblock x="365.5" y="415.75" lock="no" other="rotation=-1.577 mat=rubber"/>
<rubberblock x="263.5" y="348.75" lock="no" other="rotation=1.591 mat=rubber"/>
<rubberblock x="364.5" y="267.75" lock="no" other="rotation=-1.576 mat=rubber"/>
<rubberblock x="265.5" y="191.75" lock="no" other="rotation=-1.569 mat=rubber"/>
<fixedblock x="366.5" y="469.5" lock="no" other="rotation=0"/>
<fixedblock x="364.5" y="499.5" lock="no" other="rotation=0"/>
<fixedblock x="361.5" y="541" lock="no" other="rotation=0"/>
<fixedblock x="263.5" y="480.5" lock="no" other="rotation=0"/>
<fixedblock x="266.5" y="508.5" lock="no" other="rotation=0"/>
<fixedblock x="272.5" y="543.5" lock="no" other="rotation=0"/></room>
		<room roomID="69436" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69434" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69432" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69348" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69345" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69343" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69341" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69336" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69335" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69329" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69327" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69325" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69323" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69320" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69315" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69312" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69310" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69308" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69306" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69304" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69301" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69295" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69293" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69252" status="new" type="open" setting="wind" title="" fg="blank" bg="bg/3.swf" author="mohammad444">
	<figitdropper x="252.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="508.2" y="553" lock="no" other="rotation=1.563 mat=rubber"/>
<rubberblock x="521.25" y="532.8" lock="no" other="rotation=0.185 mat=rubber"/></room>
		<room roomID="69246" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69244" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69242" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69240" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69238" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69236" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69234" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69232" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69230" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69228" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69226" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69224" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69221" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69215" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69206" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69201" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69195" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69185" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="69177" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68798" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68796" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68719" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68717" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68715" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68713" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68711" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68709" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68707" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68705" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68697" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68689" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68670" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68663" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68641" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68632" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68629" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68622" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68614" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68592" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68586" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68581" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68579" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68569" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68564" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68550" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68545" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68539" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68533" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68521" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="68197" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/2.swf" author="stuffman">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=s/1/1"/>
<rubberblock x="524.5" y="87.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="521.5" y="72.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="516.5" y="48.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="520.5" y="24.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="185.5" y="518.5" lock="no" other="rotation=0"/>
<fixedblock x="190.5" y="496.5" lock="no" other="rotation=0"/>
<fixedblock x="178.5" y="489.5" lock="no" other="rotation=0"/>
<fixedblock x="171.5" y="504.5" lock="no" other="rotation=0"/>
<fixedblock x="169.5" y="493.5" lock="no" other="rotation=0"/>
<fixedblock x="177.5" y="515.5" lock="no" other="rotation=0"/>
<fixedblock x="183.5" y="487.5" lock="no" other="rotation=0"/>
<fixedblock x="56.5" y="217.5" lock="no" other="rotation=0"/>
<fixedblock x="79.5" y="215.5" lock="no" other="rotation=0"/>
<pvcpipe x="529.5" y="80.5" lock="no" other="rotation=0"/>
<pvcpipe x="526.5" y="36" lock="no" other="rotation=0"/>
<figitdivider x="517" y="420.5" lock="no" other=""/>
<figitdivider x="465.5" y="421.5" lock="no" other=""/>
<figitdivider x="409.5" y="420.5" lock="no" other=""/>
<figitpainter x="6.5" y="71.5" lock="no" other="color=1"/>
<figitpainter x="521.5" y="206.5" lock="no" other="color=1"/>
<figitpainter x="33.5" y="325.5" lock="no" other="color=1"/>
<figitpainter x="434.5" y="176.5" lock="no" other="color=1"/>
<figitpainter x="375.5" y="177.5" lock="no" other="color=1"/>
<elbowpipe x="530.5" y="160" lock="no" other="rotation=0"/>
<elbowpipe x="78" y="280" lock="no" other="rotation=-1.595"/>
<conveyorbelt x="187.5" y="428.5" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="331.5" y="546.5" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="153" y="531.5" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="80.5" y="434.5" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="230.5" y="422.5" lock="no" other="cv=rt_fast"/>
<fidgitcannon x="6" y="129.5" lock="no" other="chute=-12.406"/>
<fidgitcannon x="497" y="247.5" lock="no" other="chute=-169.423"/>
<fidgitcannon x="6" y="368.5" lock="no" other="chute=-15"/></room>
		<room roomID="68113" status="new" type="open" setting="wind" title="hljmaew Room" fg="blank" bg="bg/7.swf" author="popsoup">
	<figitdropper x="267.5" y="6" lock="no" other=""/>
<figitbox x="283.5" y="355.5" lock="no" other="par=r/0/1"/>
<rubberblock x="330" y="575" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="140.5" y="491.5" lock="no" other="rotation=0"/>
<fixedblock x="456.5" y="468.5" lock="no" other="rotation=0"/></room>
		<room roomID="68105" status="new" type="open" setting="wind" title="           Room" fg="blank" bg="bg/1.swf" author="JoannaOu17">
	<figitdropper x="6.5" y="6" lock="no" other=""/>
<figitdropper x="296.5" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/10"/></room>
		<room roomID="67843" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/6.swf" author="pinkie200">
	<figitdropper x="286.5" y="6" lock="no" other=""/>
<figitbox x="287.5" y="556" lock="no" other="par=l/0/11"/>
<figitcombiner x="269.5" y="87.5" lock="no" other=""/>
<figitcombiner x="273.5" y="196.5" lock="no" other=""/>
<figitcombiner x="276.5" y="299.5" lock="no" other=""/></room>
		<room roomID="67693" status="" type="open" setting="" title="" fg="" bg="" author="conrad">
	</room>
		<room roomID="66876" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/1.swf" author="giggle19">
	<figitdropper x="83.5" y="6" lock="no" other=""/>
<figitbox x="269.5" y="517.5" lock="no" other="par=r/0/1"/>
<figitbox x="448.5" y="523.5" lock="no" other="par=r/0/1"/>
<figitbox x="80.5" y="525.5" lock="no" other="par=r/0/1"/>
<rubberblock x="97.5" y="239.75" lock="no" other="rotation=0.894 mat=rubber"/>
<pvcpipe x="119.5" y="132.5" lock="no" other="rotation=1.598"/>
<pvcpipe x="202.5" y="223.5" lock="no" other="rotation=0"/>
<figitcombiner x="253.5" y="243.5" lock="no" other=""/></room>
		<room roomID="65767" status="new" type="open" setting="main" title="cool room" fg="blank" bg="bg/5.swf" author="samuel011">
	<figitdropper x="266.5" y="6" lock="no" other=""/>
<figitdropper x="198.5" y="6" lock="no" other=""/>
<figitdropper x="130.5" y="6" lock="no" other=""/>
<figitbox x="276.5" y="317" lock="no" other="par=r/0/1"/>
<figitbox x="132.5" y="316" lock="no" other="par=r/0/1"/>
<figitbox x="199.5" y="318" lock="no" other="par=r/0/1"/>
<rubberblock x="199.5" y="150.75" lock="no" other="rotation=-1.564 mat=wood"/>
<rubberblock x="129.5" y="149.75" lock="no" other="rotation=-1.564 mat=wood"/>
<rubberblock x="340.5" y="146.75" lock="no" other="rotation=-1.607 mat=wood"/>
<rubberblock x="267.5" y="147.75" lock="no" other="rotation=-1.581 mat=wood"/>
<rubberblock x="202.5" y="263.75" lock="no" other="rotation=1.559 mat=wood"/>
<rubberblock x="342.5" y="260.75" lock="no" other="rotation=-1.584 mat=wood"/>
<rubberblock x="268.5" y="262.75" lock="no" other="rotation=1.539 mat=wood"/>
<rubberblock x="305" y="377" lock="no" other="rotation=0 mat=wood"/>
<rubberblock x="130.5" y="268.75" lock="no" other="rotation=1.556 mat=wood"/>
<rubberblock x="173.5" y="377.75" lock="no" other="rotation=0 mat=wood"/>
<fixedblock x="131.5" y="92.5" lock="no" other="rotation=0"/>
<fixedblock x="200.5" y="94.5" lock="no" other="rotation=0"/>
<fixedblock x="268.5" y="93.5" lock="no" other="rotation=0"/>
<fixedblock x="338.5" y="92.5" lock="no" other="rotation=0"/>
<fixedblock x="341.5" y="202.5" lock="no" other="rotation=0"/>
<fixedblock x="266.5" y="203.5" lock="no" other="rotation=0"/>
<fixedblock x="503.5" y="303.5" lock="no" other="rotation=0"/>
<fixedblock x="129.5" y="204.5" lock="no" other="rotation=0"/>
<fixedblock x="556.5" y="294.5" lock="no" other="rotation=0"/>
<fixedblock x="199.5" y="205.5" lock="no" other="rotation=0"/></room>
		<room roomID="65384" status="new" type="open" setting="main" title="our new room" fg="blank" bg="bg/5.swf" author="bellam2000">
	<figitdropper x="333.5" y="6" lock="no" other=""/>
<figitbox x="391.5" y="414.5" lock="no" other="par=s/0/1"/>
<rubberblock x="361.5" y="205.75" lock="no" other="rotation=-2.445 mat=conc"/>
<rubberblock x="437.5" y="270.75" lock="no" other="rotation=-0.512 mat=conc"/>
<rubberblock x="371.5" y="339.75" lock="no" other="rotation=0.554 mat=wood"/>
<fixedblock x="440.5" y="214.5" lock="no" other="rotation=0"/>
<fixedblock x="469.5" y="319.5" lock="no" other="rotation=0"/>
<fixedblock x="330.5" y="291.5" lock="no" other="rotation=0"/>
<fixedblock x="480.5" y="395.5" lock="no" other="rotation=0"/>
<figitdivider x="326.5" y="87.5" lock="no" other=""/></room>
		<room roomID="64962" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64960" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64958" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64956" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64954" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64952" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64950" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64948" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64943" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64941" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64939" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64937" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64935" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64933" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64931" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64929" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64927" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64925" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64923" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64921" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64919" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64917" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64915" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64913" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64911" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64909" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64907" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="64770" status="" type="open" setting="" title="" fg="" bg="" author="willman12345">
	</room>
		<room roomID="64273" status="new" type="open" setting="main" title="diamond drop" fg="blank" bg="bg/6.swf" author="jules15">
	<figitdropper x="346.2" y="6" lock="no" other=""/>
<figitbox x="62.85" y="510.4" lock="no" other="par=r/0/1"/>
<rubberblock x="331.35" y="144.85" lock="no" other="rotation=-2.785 mat=rubber"/>
<rubberblock x="173" y="476.05" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="244.95" y="420.3" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="310.35" y="370.6" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="362.45" y="324.3" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="405.1" y="267" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="442.5" y="224" lock="no" other="rotation=-0.249 mat=rubber"/>
<rubberblock x="68.95" y="222.85" lock="no" other="rotation=-1.588 mat=rubber"/>
<rubberblock x="65.25" y="64.4" lock="no" other="rotation=-1.632 mat=rubber"/>
<rubberblock x="69.25" y="146.75" lock="no" other="rotation=-1.588 mat=rubber"/>
<fixedblock x="474.8" y="186.8" lock="no" other="rotation=0"/>
<fixedblock x="473.55" y="163.1" lock="no" other="rotation=0"/>
<fixedblock x="473.35" y="135.15" lock="no" other="rotation=0"/>
<fixedblock x="473.3" y="108.4" lock="no" other="rotation=0"/>
<fixedblock x="476.1" y="76.5" lock="no" other="rotation=0"/>
<fixedblock x="482.4" y="53.75" lock="no" other="rotation=0"/>
<fixedblock x="56.45" y="503.35" lock="no" other="rotation=0"/>
<fixedblock x="56.35" y="479.4" lock="no" other="rotation=0"/>
<fixedblock x="58.95" y="448.85" lock="no" other="rotation=0"/>
<fixedblock x="62.6" y="419.2" lock="no" other="rotation=0"/>
<fixedblock x="61.4" y="390" lock="no" other="rotation=0"/>
<fixedblock x="65.1" y="357.65" lock="no" other="rotation=0"/>
<fixedblock x="69.25" y="326.25" lock="no" other="rotation=0"/>
<fixedblock x="69.35" y="307.3" lock="no" other="rotation=0"/>
<fixedblock x="67.95" y="276.8" lock="no" other="rotation=0"/></room>
		<room roomID="64135" status="new" type="open" setting="main" title="Fidget Pushing " fg="blank" bg="bg/6.swf" author="bowler2004">
	<figitdropper x="6.5" y="6" lock="no" other=""/>
<figitdropper x="118.2" y="6" lock="no" other=""/>
<figitdropper x="205.8" y="6" lock="no" other=""/>
<figitbox x="6" y="556" lock="no" other="par=l/10/200"/>
<figitbox x="77.4" y="556" lock="no" other="par=l/6/200"/>
<figitcombiner x="6" y="78.95" lock="no" other=""/>
<figitcombiner x="104.45" y="80.1" lock="no" other=""/>
<figitcombiner x="206" y="80.8" lock="no" other=""/>
<figitpainter x="14.25" y="490.35" lock="no" other="color=10"/>
<figitpainter x="85.1" y="486.5" lock="no" other="color=6"/>
<spring x="163.05" y="486.5" lock="no" other="dir=left"/>
<spring x="188.7" y="458.9" lock="no" other="dir=left"/>
<conveyorbelt x="6.5" y="197.75" lock="no" other="cv=rt_med"/>
<conveyorbelt x="176.85" y="195.85" lock="no" other="cv=rt_med"/>
<conveyorbelt x="309.5" y="334.1" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="234.95" y="393.95" lock="no" other="cv=lt_slow"/>
<conveyorbelt x="405.25" y="393.8" lock="no" other="cv=lt_fast"/></room>
		<room roomID="63843" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63725" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63723" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63721" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63719" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63717" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63715" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63713" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63711" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63709" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63707" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63705" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63703" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63701" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63699" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63697" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63695" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63693" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63490" status="new" type="open" setting="main" title="swing room" fg="blank" bg="bg/9.swf" author="puffsen2468">
	<figitdropper x="320.5" y="6" lock="no" other=""/>
<figitdropper x="73.5" y="6" lock="no" other=""/>
<figitdropper x="522.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="447.5" y="377.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="227.5" y="382.75" lock="no" other="rotation=0 mat=rubber"/>
<pendulum x="301.5" y="202.5" lock="no" other="swing_x=80 swing_y=0"/>
<pendulum x="54.5" y="188.5" lock="no" other="swing_x=80 swing_y=0"/>
<pendulum x="500" y="207.5" lock="no" other="swing_x=80 swing_y=0"/></room>
		<room roomID="63263" status="new" type="open" setting="wind" title="zachary" fg="blank" bg="bg/5.swf" author="Zachary9051">
	<figitdropper x="157.5" y="6" lock="no" other=""/>
<figitbox x="152.5" y="556" lock="no" other="par=r/8/1"/></room>
		<room roomID="63254" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="63252" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="62681" status="new" type="open" setting="main" title="Multi-Product" fg="blank" bg="bg/9.swf" author="trogyssy">
	<figitdropper x="269.5" y="6" lock="no" other=""/>
<figitbox x="494.5" y="556" lock="no" other="par=s/5/10"/>
<figitbox x="6.5" y="556" lock="no" other="par=r/3/5"/>
<rubberblock x="450.5" y="274.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="155.5" y="265.75" lock="no" other="rotation=0 mat=rubber"/>
<figitcombiner x="6" y="245.5" lock="no" other=""/>
<figitdivider x="263.5" y="75.5" lock="no" other=""/>
<figitpainter x="513.5" y="247.5" lock="no" other="color=5"/>
<figitpainter x="21.5" y="317.5" lock="no" other="color=3"/>
<elbowpipe x="256.5" y="185" lock="no" other="rotation=1.571"/>
<elbowpipe x="347.5" y="196" lock="no" other="rotation=-3.118"/>
<conveyorbelt x="406" y="366" lock="no" other="cv=lt_med"/>
<conveyorbelt x="9" y="415.5" lock="no" other="cv=rt_med"/>
<fidgitcannon x="194.5" y="436.5" lock="no" other="chute=174.214"/>
<fidgitcannon x="329.5" y="390.5" lock="no" other="chute=31.371"/></room>
		<room roomID="62034" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="62032" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="62030" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="60604" status="new" type="open" setting="main" title="friends room" fg="blank" bg="bg/9.swf" author="heriberto">
	<figitdropper x="13.5" y="6" lock="no" other=""/>
<figitdropper x="328.5" y="6" lock="no" other=""/>
<figitdropper x="527.5" y="6" lock="no" other=""/>
<figitbox x="6.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="282.5" y="554" lock="no" other="par=r/0/1"/>
<figitbox x="519" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="123" y="574" lock="no" other="rotation=0.004 mat=wood"/>
<rubberblock x="181.5" y="280.75" lock="no" other="rotation=1.017 mat=rubber"/>
<rubberblock x="130.5" y="462.75" lock="no" other="rotation=-1.065 mat=rubber"/>
<rubberblock x="203.5" y="572.75" lock="no" other="rotation=0.016 mat=conc"/>
<rubberblock x="400.5" y="571" lock="no" other="rotation=0.014 mat=wood"/>
<rubberblock x="213.5" y="138.75" lock="no" other="rotation=1.132 mat=rubber"/>
<rubberblock x="433.5" y="115.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="243.5" y="455.75" lock="no" other="rotation=0.387 mat=rubber"/>
<rubberblock x="395" y="432.75" lock="no" other="rotation=2.226 mat=rubber"/>
<rubberblock x="414.5" y="246.75" lock="no" other="rotation=-1.084 mat=rubber"/>
<fixedblock x="427.5" y="163.5" lock="no" other="rotation=1.611"/>
<fixedblock x="284.5" y="273.5" lock="no" other="rotation=-0.762"/>
<fixedblock x="155.5" y="45.5" lock="no" other="rotation=0.984"/>
<fixedblock x="262.5" y="572.5" lock="no" other="rotation=0"/>
<fixedblock x="498.5" y="336.5" lock="no" other="rotation=-1.283"/>
<fixedblock x="21.5" y="334.5" lock="no" other="rotation=0"/>
<fixedblock x="483.5" y="569.5" lock="no" other="rotation=0"/>
<fixedblock x="512.5" y="570.5" lock="no" other="rotation=0"/>
<fixedblock x="447.5" y="455.5" lock="no" other="rotation=-0.495"/>
<fixedblock x="99.5" y="239.5" lock="no" other="rotation=0"/>
<fixedblock x="312.5" y="187.5" lock="no" other="rotation=0.317"/>
<fixedblock x="454.5" y="570.5" lock="no" other="rotation=0"/>
<fixedblock x="492.5" y="202.5" lock="no" other="rotation=-0.738"/>
<fixedblock x="529" y="463.5" lock="no" other="rotation=-0.788"/>
<fixedblock x="421.5" y="354.5" lock="no" other="rotation=2.998"/></room>
		<room roomID="60505" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/1.swf" author="ivan544">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitbox x="522" y="555.5" lock="no" other="par=r/0/98"/>
<pvcpipe x="549.5" y="463" lock="no" other="rotation=1.528"/>
<spring x="163.5" y="564" lock="no" other="dir=right"/></room>
		<room roomID="60359" status="new" type="open" setting="main" title="2x2x2" fg="blank" bg="bg/15.swf" author="msyver">
	<figitdropper x="199.5" y="6" lock="no" other=""/>
<figitbox x="194.5" y="511.5" lock="no" other="par=r/0/1"/>
<rubberblock x="195.5" y="152.75" lock="no" other="rotation=0.777 mat=rubber"/>
<rubberblock x="268.5" y="183.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="548.5" y="333.75" lock="no" other="rotation=-0.898 mat=rubber"/>
<rubberblock x="497.5" y="392.75" lock="no" other="rotation=-0.928 mat=rubber"/>
<rubberblock x="444.5" y="452.75" lock="no" other="rotation=-0.742 mat=rubber"/>
<rubberblock x="387.5" y="500.75" lock="no" other="rotation=-0.666 mat=rubber"/>
<rubberblock x="310.5" y="524.75" lock="no" other="rotation=0 mat=rubber"/>
<figitcombiner x="304" y="197.5" lock="no" other=""/>
<figitcombiner x="403.5" y="197.5" lock="no" other=""/>
<figitcombiner x="500" y="197.5" lock="no" other=""/></room>
		<room roomID="60219" status="new" type="open" setting="wind" title="my rockin room" fg="blank" bg="bg/6.swf" author="avarie9">
	</room>
		<room roomID="60200" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/1.swf" author="ivan544">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitbox x="522" y="555.5" lock="no" other="par=r/0/1"/>
<spring x="163.5" y="564" lock="no" other="dir=right"/></room>
		<room roomID="59991" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="59989" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="59897" status="new" type="open" setting="main" title="call of mw3" fg="blank" bg="bg/4.swf" author="caydenspider">
	</room>
		<room roomID="59808" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="core21">
	<figitdropper x="43.5" y="6" lock="no" other=""/>
<figitbox x="6" y="556" lock="no" other="par=r/0/50"/>
<rubberblock x="325.5" y="135.75" lock="no" other="rotation=-1.552 mat=conc"/>
<fidgitcannon x="36.5" y="75.5" lock="no" other="chute=-0.088"/>
<fidgitcannon x="290.5" y="239.5" lock="no" other="chute=0.411"/>
<fidgitcannon x="217.5" y="157.5" lock="no" other="chute=17.119"/>
<fidgitcannon x="499.5" y="326.5" lock="no" other="chute=90.475"/>
<fidgitcannon x="492.5" y="417.5" lock="no" other="chute=179.314"/></room>
		<room roomID="59514" status="new" type="open" setting="main" title="To vanessa" fg="blank" bg="bg/1.swf" author="isabellema">
	<figitdropper x="280.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=l/1/1"/>
<rubberblock x="361.5" y="501.75" lock="no" other="rotation=0.425 mat=rubber"/>
<figitcombiner x="306.5" y="128.5" lock="no" other=""/>
<figitpainter x="325.5" y="285.5" lock="no" other="color=1"/></room>
		<room roomID="59365" status="new" type="open" setting="wind" title="EZEY" fg="blank" bg="bg/5.swf" author="SWEETIEPIESJ">
	<figitdropper x="377.5" y="6" lock="no" other=""/>
<figitdropper x="248.5" y="6" lock="no" other=""/>
<figitdropper x="312.5" y="6" lock="no" other=""/>
<figitbox x="372.5" y="80.5" lock="no" other="par=r/0/1"/>
<figitbox x="245.5" y="82.5" lock="no" other="par=r/0/1"/>
<figitbox x="306.5" y="80.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="58808" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/14.swf" author="asz">
	<figitdropper x="447.5" y="6" lock="no" other=""/>
<figitdropper x="189.5" y="6" lock="no" other=""/>
<figitbox x="280.5" y="556" lock="no" other="par=s/1/1"/>
<figitdivider x="436.5" y="184.5" lock="no" other=""/>
<figitdivider x="173.5" y="183.5" lock="no" other=""/>
<figitpainter x="442.5" y="236.5" lock="no" other="color=1"/>
<figitpainter x="175.5" y="233.5" lock="no" other="color=1"/>
<fidgitcannon x="177.5" y="488.5" lock="no" other="chute=27.454"/></room>
		<room roomID="58754" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="58752" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="58750" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="58747" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="58746" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="58744" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="58742" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="58504" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="asz">
	<figitdropper x="528.5" y="6" lock="no" other=""/>
<pvcpipe x="513.5" y="564" lock="no" other="rotation=0"/></room>
		<room roomID="58366" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/2.swf" author="AsZ">
	<figitdropper x="267.5" y="6" lock="no" other=""/>
<figitbox x="277.5" y="556" lock="no" other="par=l/0/1"/>
<figitcombiner x="257.5" y="298.5" lock="no" other=""/></room>
		<room roomID="58257" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/9.swf" author="jumpinjj">
	<figitdropper x="307.5" y="6" lock="no" other=""/>
<figitbox x="133.5" y="272.5" lock="no" other="par=l/1/1"/>
<rubberblock x="156.5" y="369.75" lock="no" other="rotation=0.23 mat=conc"/>
<fixedblock x="384.5" y="241.5" lock="no" other="rotation=0"/>
<pvcpipe x="56" y="260.5" lock="no" other="rotation=0"/>
<figitcombiner x="267.5" y="70.5" lock="no" other=""/>
<figitdivider x="517.5" y="231.5" lock="no" other=""/>
<figitpainter x="109.5" y="7" lock="no" other="color=1"/>
<conveyorbelt x="180.5" y="248.5" lock="no" other="cv=lt_med"/>
<fidgitcannon x="259.5" y="129.5" lock="no" other="chute=90"/></room>
		<room roomID="58238" status="new" type="open" setting="main" title="fj300qwaso20619" fg="blank" bg="bg/1.swf" author="asz">
	<figitdropper x="267.5" y="6" lock="no" other=""/>
<figitbox x="268.5" y="556" lock="no" other="par=s/0/1"/>
<figitdivider x="135.5" y="232.5" lock="no" other=""/>
<figitdivider x="428.5" y="244.5" lock="no" other=""/>
<conveyorbelt x="204.5" y="138.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="369.5" y="417.5" lock="no" other="cv=lt_med"/>
<fidgitcannon x="412" y="159.5" lock="no" other="chute=101.455"/></room>
		<room roomID="58236" status="new" type="open" setting="main" title="fj300qwaso20619" fg="blank" bg="bg/1.swf" author="asz">
	<figitdropper x="267.5" y="6" lock="no" other=""/>
<figitbox x="268.5" y="556" lock="no" other="par=s/0/1"/>
<figitdivider x="135.5" y="232.5" lock="no" other=""/>
<figitdivider x="428.5" y="244.5" lock="no" other=""/>
<conveyorbelt x="204.5" y="138.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="373.5" y="409.5" lock="no" other="cv=lt_med"/>
<fidgitcannon x="412" y="159.5" lock="no" other="chute=90"/></room>
		<room roomID="58235" status="new" type="open" setting="main" title="fj300qwaso20619" fg="blank" bg="bg/1.swf" author="asz">
	<figitdropper x="267.5" y="6" lock="no" other=""/>
<figitbox x="268.5" y="556" lock="no" other="par=s/0/1"/>
<figitdivider x="135.5" y="232.5" lock="no" other=""/>
<figitdivider x="428.5" y="244.5" lock="no" other=""/>
<conveyorbelt x="204.5" y="138.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="373.5" y="409.5" lock="no" other="cv=lt_med"/>
<fidgitcannon x="412" y="159.5" lock="no" other="chute=90"/></room>
		<room roomID="58172" status="new" type="open" setting="main" title="redfidgit" fg="blank" bg="bg/2.swf" author="asz">
	<figitdropper x="291.5" y="6" lock="no" other=""/>
<figitbox x="344.5" y="383" lock="no" other="par=l/2/1"/>
<figitcombiner x="343" y="295" lock="no" other=""/>
<figitpainter x="296.5" y="71.5" lock="no" other="color=2"/>
<conveyorbelt x="183.5" y="276.5" lock="no" other="cv=rt_med"/></room>
		<room roomID="58058" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="wayluno149">
	<figitdropper x="375.5" y="6" lock="no" other=""/>
<figitdropper x="502.5" y="6" lock="no" other=""/>
<figitbox x="383.5" y="554.5" lock="no" other="par=r/0/1"/>
<rubberblock x="501.5" y="570.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="211.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="152.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="57590" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/6.swf" author="LouEdR">
	<figitdropper x="304.3" y="6" lock="no" other=""/>
<figitbox x="6" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="357.7" y="321.15" lock="no" other="rotation=-0.752 mat=rubber"/></room>
		<room roomID="57275" status="new" type="open" setting="wind" title=" sooo funny roo" fg="blank" bg="bg/9.swf" author="luvscience07">
	<figitdropper x="300.55" y="6" lock="no" other=""/>
<figitbox x="401.45" y="432.3" lock="no" other="par=r/0/1"/></room>
		<room roomID="57140" status="new" type="open" setting="main" title="boingo" fg="blank" bg="bg/1.swf" author="flipmix">
	<figitdropper x="67.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<fixedblock x="585" y="510.5" lock="no" other="rotation=0"/>
<fixedblock x="559.5" y="481.5" lock="no" other="rotation=0"/>
<fixedblock x="529.5" y="452.5" lock="no" other="rotation=0"/></room>
		<room roomID="56989" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/2.swf" author="JerryZRW">
	<figitdropper x="326.5" y="6" lock="no" other=""/>
<figitdropper x="175.5" y="6" lock="no" other=""/>
<figitbox x="310" y="323.5" lock="no" other="par=r/0/1"/>
<figitbox x="78.5" y="405.5" lock="no" other="par=r/0/1"/>
<figitcombiner x="293.5" y="227.5" lock="no" other=""/>
<figitcombiner x="310" y="524" lock="no" other=""/>
<figitcombiner x="308.5" y="389.5" lock="no" other=""/></room>
		<room roomID="56950" status="new" type="open" setting="main" title="brugder" fg="blank" bg="bg/7.swf" author="flame583">
	<figitdropper x="164.25" y="6" lock="no" other=""/>
<figitbox x="475.05" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="456.9" y="238.3" lock="no" other="rotation=1.564 mat=conc"/>
<rubberblock x="455.75" y="315.85" lock="no" other="rotation=-1.558 mat=conc"/>
<rubberblock x="455.95" y="394.45" lock="no" other="rotation=-1.578 mat=conc"/>
<rubberblock x="279.5" y="496.4" lock="no" other="rotation=0 mat=conc"/>
<figitcombiner x="55.2" y="309.7" lock="no" other=""/></room>
		<room roomID="56840" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="Mutt124">
	<figitdropper x="76.5" y="6" lock="no" other=""/>
<figitdropper x="238.5" y="6" lock="no" other=""/>
<figitdropper x="473.5" y="6" lock="no" other=""/>
<figitbox x="67.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="239.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="472.5" y="556" lock="no" other="par=r/0/1"/></room>
		<room roomID="56825" status="new" type="open" setting="moon" title="widget fidget" fg="blank" bg="bg/9.swf" author="supersaajan">
	<figitdropper x="192.5" y="6" lock="no" other=""/>
<figitdropper x="340.5" y="6" lock="no" other=""/>
<figitdropper x="266.5" y="6" lock="no" other=""/>
<figitbox x="268.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="346.5" y="555" lock="no" other="par=r/0/1"/>
<figitbox x="194.5" y="556" lock="no" other="par=r/0/1"/></room>
		<room roomID="56726" status="new" type="open" setting="main" title="boingo" fg="blank" bg="bg/1.swf" author="flipmix">
	<figitdropper x="67.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<fixedblock x="585" y="510.5" lock="no" other="rotation=0"/>
<fixedblock x="559.5" y="481.5" lock="no" other="rotation=0"/>
<fixedblock x="529.5" y="452.5" lock="no" other="rotation=0"/></room>
		<room roomID="56661" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/4.swf" author="andrewix">
	<figitdropper x="291.5" y="6" lock="no" other=""/>
<figitdropper x="192.5" y="6" lock="no" other=""/>
<figitbox x="295.5" y="288.5" lock="no" other="par=r/0/1"/>
<fidgitcannon x="279.5" y="96.5" lock="no" other="chute=33.179"/>
<fidgitcannon x="408.5" y="227.5" lock="no" other="chute=161.069"/>
<fidgitcannon x="169.5" y="313.5" lock="no" other="chute=-15"/>
<fidgitcannon x="164.5" y="153.5" lock="no" other="chute=16.34"/></room>
		<room roomID="56187" status="new" type="open" setting="moon" title="Malaika" fg="blank" bg="bg/2.swf" author="flowermp345">
	<figitdropper x="356.5" y="6" lock="no" other=""/>
<figitdropper x="348.5" y="6" lock="no" other=""/>
<figitbox x="428.5" y="532.5" lock="no" other="par=r/0/1"/>
<figitbox x="355.5" y="550.5" lock="no" other="par=r/0/1"/>
<rubberblock x="368.5" y="170.75" lock="no" other="rotation=-1.552 mat=wood"/>
<rubberblock x="438.5" y="320.75" lock="no" other="rotation=-1.644 mat=rubber"/>
<rubberblock x="387.5" y="494.75" lock="no" other="rotation=1.606 mat=rubber"/>
<fixedblock x="430.5" y="125.5" lock="no" other="rotation=0"/>
<fixedblock x="381.5" y="360.5" lock="no" other="rotation=0"/>
<fixedblock x="431.5" y="175.5" lock="no" other="rotation=0"/>
<fixedblock x="434.5" y="214.5" lock="no" other="rotation=0"/>
<fixedblock x="374.5" y="271.5" lock="no" other="rotation=3.049"/>
<fixedblock x="391.5" y="434.5" lock="no" other="rotation=0"/>
<fixedblock x="449.5" y="411.5" lock="no" other="rotation=0"/>
<fixedblock x="459.5" y="504.5" lock="no" other="rotation=0"/></room>
		<room roomID="55687" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="55681" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="54786" status="new" type="open" setting="wind" title="floor room" fg="blank" bg="bg/1.swf" author="cityhunter">
	<figitdropper x="40.5" y="6" lock="no" other=""/>
<figitdropper x="226.5" y="6" lock="no" other=""/>
<figitdropper x="407.5" y="6" lock="no" other=""/>
<figitbox x="63.5" y="552.5" lock="no" other="par=r/0/1"/>
<figitbox x="223.5" y="553" lock="no" other="par=r/0/1"/>
<figitbox x="399.5" y="548.5" lock="no" other="par=r/0/1"/>
<rubberblock x="182.5" y="356.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="54740" status="new" type="open" setting="main" title="chutes help" fg="blank" bg="bg/12.swf" author="hepgirls">
	<figitdropper x="145.5" y="6" lock="no" other=""/>
<figitdropper x="281.5" y="6" lock="no" other=""/>
<figitdropper x="434.5" y="6" lock="no" other=""/>
<figitbox x="298.5" y="556" lock="no" other="par=s/0/40"/>
<rubberblock x="280.5" y="530.75" lock="no" other="rotation=1.02 mat=conc"/>
<rubberblock x="399.5" y="526.75" lock="no" other="rotation=-1.002 mat=conc"/>
<rubberblock x="242.5" y="467.75" lock="no" other="rotation=1.032 mat=conc"/>
<pvcpipe x="319.5" y="215.5" lock="no" other="rotation=1.596"/>
<pvcpipe x="441.5" y="267.5" lock="no" other="rotation=2.064"/>
<pvcpipe x="222.5" y="272.5" lock="no" other="rotation=1.123"/>
<figitdivider x="424.5" y="82.5" lock="no" other=""/>
<figitdivider x="276.5" y="84.5" lock="no" other=""/>
<figitdivider x="137" y="84.5" lock="no" other=""/>
<fidgitcannon x="427.5" y="132.5" lock="no" other="chute=110.26"/>
<fidgitcannon x="125.5" y="130.5" lock="no" other="chute=45.63"/>
<fidgitcannon x="373.5" y="333.5" lock="no" other="chute=102.089"/>
<fidgitcannon x="204.5" y="338.5" lock="no" other="chute=70.7"/></room>
		<room roomID="54570" status="new" type="open" setting="main" title="the hard hede" fg="blank" bg="bg/4.swf" author="hdine">
	<figitdropper x="289.5" y="6" lock="no" other=""/>
<figitbox x="284.5" y="556" lock="no" other="par=r/0/90"/>
<rubberblock x="357.5" y="540.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="277.5" y="542.5" lock="no" other="rotation=0"/></room>
		<room roomID="54569" status="new" type="open" setting="main" title="the bownsreroom" fg="blank" bg="bg/2.swf" author="hdine">
	<figitdropper x="302.5" y="6" lock="no" other=""/>
<figitbox x="445.5" y="489.5" lock="no" other="par=r/0/111"/>
<rubberblock x="379.5" y="93.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="277.5" y="93.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="54390" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/5.swf" author="adriana213">
	<figitdropper x="75" y="6" lock="no" other=""/>
<figitdropper x="278" y="6" lock="no" other=""/>
<figitdropper x="520.5" y="6" lock="no" other=""/>
<figitbox x="58.5" y="278" lock="no" other="par=r/0/1"/>
<figitbox x="279.5" y="284.5" lock="no" other="par=r/0/1"/>
<figitbox x="519" y="285.5" lock="no" other="par=r/0/1"/>
<rubberblock x="443" y="206.25" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46" y="207.25" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="193.5" y="167.25" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="53918" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/3.swf" author="znfd2006">
	<figitdropper x="6.5" y="6" lock="no" other=""/>
<figitbox x="202.5" y="555" lock="no" other="par=l/10/4"/>
<figitcombiner x="6" y="287.5" lock="no" other=""/>
<figitpainter x="20.5" y="191.5" lock="no" other="color=10"/>
<conveyorbelt x="6" y="532" lock="no" other="cv=rt_med"/>
<conveyorbelt x="272" y="534.5" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="406" y="535.5" lock="no" other="cv=lt_fast"/></room>
		<room roomID="53888" status="new" type="open" setting="main" title="smallbignormel" fg="blank" bg="bg/10.swf" author="TPG14">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="273.5" y="6" lock="no" other=""/>
<figitcombiner x="500" y="73.5" lock="no" other=""/>
<figitcombiner x="497" y="137.5" lock="no" other=""/>
<figitcombiner x="494" y="204.5" lock="no" other=""/>
<figitdivider x="6" y="72.5" lock="no" other=""/>
<figitdivider x="9.5" y="131.5" lock="no" other=""/>
<figitdivider x="14.5" y="187.5" lock="no" other=""/>
<figitpainter x="25" y="246.5" lock="no" other="color=1"/>
<figitpainter x="515.5" y="268.5" lock="no" other="color=8"/>
<figitpainter x="278.5" y="82.5" lock="no" other="color=10"/>
<figitpainter x="278.5" y="156.5" lock="no" other="color=3"/>
<figitpainter x="278.5" y="230.5" lock="no" other="color=4"/>
<figitpainter x="278.5" y="303.5" lock="no" other="color=6"/>
<figitpainter x="279.5" y="375.5" lock="no" other="color=2"/>
<spring x="558" y="563.5" lock="no" other="dir=left"/>
<spring x="6.5" y="563.5" lock="no" other="dir=right"/>
<conveyorbelt x="37" y="568" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="376" y="568" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="206.5" y="568" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="310.5" y="472.5" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="144.5" y="472.5" lock="no" other="cv=lt_fast"/></room>
		<room roomID="53819" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/2.swf" author="save201">
	<figitdropper x="45.1" y="6" lock="no" other=""/>
<figitbox x="44.1" y="456.8" lock="no" other="par=r/0/1"/>
<rubberblock x="81.65" y="575" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="80.1" y="540.35" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="81.7" y="503.55" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="52561" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/6.swf" author="Lucky55123">
	<figitdropper x="130.35" y="6" lock="no" other=""/>
<figitdropper x="311.05" y="6" lock="no" other=""/>
<figitdropper x="527.15" y="6" lock="no" other=""/>
<figitbox x="517.8" y="494.45" lock="no" other="par=r/0/1"/>
<figitbox x="325.4" y="549.55" lock="no" other="par=r/0/1"/>
<figitbox x="139.35" y="511.45" lock="no" other="par=r/0/1"/></room>
		<room roomID="52547" status="new" type="open" setting="main" title="the bounce" fg="blank" bg="bg/10.swf" author="samc432321">
	<figitdropper x="488.5" y="6" lock="no" other=""/>
<figitbox x="16.5" y="310.5" lock="no" other="par=r/0/1"/>
<rubberblock x="527.5" y="294.75" lock="no" other="rotation=-0.291 mat=rubber"/>
<rubberblock x="155.5" y="331.75" lock="no" other="rotation=-0.335 mat=rubber"/></room>
		<room roomID="52493" status="new" type="open" setting="wind" title="COOL111" fg="blank" bg="bg/5.swf" author="winner20">
	<figitdropper x="281.5" y="6" lock="no" other=""/>
<figitbox x="376.5" y="536.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="52307" status="new" type="open" setting="main" title="time it right" fg="blank" bg="bg/6.swf" author="feters">
	<figitdropper x="7" y="6" lock="no" other=""/>
<figitbox x="318.5" y="556" lock="no" other="par=r/4/20"/>
<fixedblock x="320.5" y="526.5" lock="no" other="rotation=0"/>
<fixedblock x="420.5" y="549.5" lock="no" other="rotation=0"/>
<pvcpipe x="550" y="373.5" lock="no" other="rotation=1.584"/>
<figitpainter x="16.5" y="110.5" lock="no" other="color=4"/>
<elbowpipe x="397.5" y="168" lock="no" other="rotation=-0.466"/>
<elbowpipe x="495.5" y="375" lock="no" other="rotation=1.102"/>
<elbowpipe x="76" y="453" lock="no" other="rotation=-2.811"/>
<conveyorbelt x="270.5" y="465.5" lock="no" other="cv=lt_slow"/>
<conveyorbelt x="180.5" y="286.5" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="247.5" y="285.5" lock="no" other="cv=rt_fast"/>
<fidgitcannon x="6" y="190.5" lock="no" other="chute=-15"/>
<fidgitcannon x="218.5" y="480.5" lock="no" other="chute=-165"/>
<fidgitcannon x="500" y="487.5" lock="no" other="chute=-174.911"/></room>
		<room roomID="52158" status="new" type="open" setting="main" title="fidgit" fg="blank" bg="bg/2.swf" author="HAMBURGER6">
	<figitdropper x="298.5" y="6" lock="no" other=""/>
<figitbox x="317.5" y="556" lock="no" other="par=l/8/6"/>
<figitcombiner x="282.5" y="94.5" lock="no" other=""/>
<figitpainter x="316.5" y="260.5" lock="no" other="color=8"/></room>
		<room roomID="52056" status="new" type="open" setting="main" title="come on ian" fg="blank" bg="bg/4.swf" author="nativeboy801">
	<figitdropper x="11.5" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="280.5" y="6" lock="no" other=""/>
<figitbox x="521.5" y="215.5" lock="no" other="par=r/0/1"/>
<figitbox x="9" y="225.5" lock="no" other="par=r/0/1"/>
<figitbox x="239.5" y="229.5" lock="no" other="par=r/0/1"/>
<rubberblock x="557.5" y="415.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46.5" y="410.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="52055" status="new" type="open" setting="main" title="Hi" fg="blank" bg="bg/12.swf" author="HappyLili">
	<figitdropper x="25.5" y="6" lock="no" other=""/>
<figitdropper x="97.5" y="6" lock="no" other=""/>
<figitbox x="407.5" y="393.5" lock="no" other="par=r/5/25"/>
<figitbox x="319.5" y="399.5" lock="no" other="par=r/0/26"/>
<figitbox x="239.5" y="396.5" lock="no" other="par=r/5/18"/>
<rubberblock x="39" y="338.75" lock="no" other="rotation=-1.482 mat=rubber"/>
<rubberblock x="54.5" y="257.75" lock="no" other="rotation=1.646 mat=rubber"/>
<rubberblock x="121.5" y="242.75" lock="no" other="rotation=0.134 mat=rubber"/>
<rubberblock x="222.5" y="347.75" lock="no" other="rotation=1.827 mat=rubber"/>
<rubberblock x="199.5" y="273.75" lock="no" other="rotation=0.874 mat=rubber"/>
<fixedblock x="442.5" y="59.5" lock="no" other="rotation=0"/>
<pvcpipe x="446.5" y="264.5" lock="no" other="rotation=1.553"/>
<figitpainter x="417.5" y="315.5" lock="no" other="color=5"/>
<figitpainter x="248.5" y="319.5" lock="no" other="color=5"/>
<elbowpipe x="426.5" y="160" lock="no" other="rotation=0"/>
<fidgitcannon x="6" y="117.5" lock="no" other="chute=-8.462"/></room>
		<room roomID="51551" status="new" type="open" setting="main" title="u9YSAGHI" fg="blank" bg="bg/2.swf" author="krang5">
	<figitdropper x="157.5" y="6" lock="no" other=""/>
<figitdropper x="290.5" y="6" lock="no" other=""/>
<figitdropper x="505.5" y="6" lock="no" other=""/>
<figitbox x="167.5" y="85.5" lock="no" other="par=r/0/1"/>
<figitbox x="182.5" y="131.5" lock="no" other="par=r/0/1"/>
<figitbox x="209.5" y="165.5" lock="no" other="par=r/0/1"/>
<rubberblock x="46" y="24" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="339.5" y="265.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="366.5" y="211.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="453.5" y="264.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="453.5" y="200.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="496.5" y="160.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="190.5" y="59.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="394.5" y="96.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="502.5" y="153.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="544.5" y="112.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="249.5" y="62.5" lock="no" other="rotation=0"/>
<fixedblock x="278.5" y="232.5" lock="no" other="rotation=0"/>
<fixedblock x="512.5" y="241.5" lock="no" other="rotation=0"/>
<fixedblock x="280.5" y="360.5" lock="no" other="rotation=1.5"/>
<fixedblock x="143.5" y="386.5" lock="no" other="rotation=0.926"/>
<fixedblock x="570.5" y="281.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="308.5" lock="no" other="rotation=0"/>
<fixedblock x="569.5" y="404.5" lock="no" other="rotation=2.057"/>
<fixedblock x="584.5" y="339.5" lock="no" other="rotation=0"/>
<fixedblock x="578.5" y="354.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="342.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="344.5" lock="no" other="rotation=0"/>
<fixedblock x="481" y="468.5" lock="no" other="rotation=0"/>
<fixedblock x="531.5" y="391.5" lock="no" other="rotation=-2.618"/>
<fixedblock x="40.5" y="395.5" lock="no" other="rotation=1.111"/></room>
		<room roomID="51473" status="new" type="open" setting="main" title="rocker99ful" fg="blank" bg="bg/4.swf" author="rockstar99fu">
	<figitdropper x="470.75" y="6" lock="no" other=""/>
<figitdropper x="190.25" y="6" lock="no" other=""/>
<figitdropper x="333.8" y="6" lock="no" other=""/>
<figitbox x="335.05" y="248.8" lock="no" other="par=r/0/1"/>
<rubberblock x="538.4" y="138.05" lock="no" other="rotation=-0.865 mat=rubber"/>
<rubberblock x="455.2" y="233.6" lock="no" other="rotation=-0.751 mat=rubber"/>
<rubberblock x="202.7" y="147.3" lock="no" other="rotation=0.679 mat=rubber"/>
<rubberblock x="285.65" y="228.6" lock="no" other="rotation=0.727 mat=rubber"/>
<fixedblock x="490.55" y="178.15" lock="no" other="rotation=-0.803"/>
<fixedblock x="244" y="186.5" lock="no" other="rotation=0.664"/></room>
		<room roomID="51386" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="tabycat">
	<figitdropper x="401.5" y="6" lock="no" other=""/>
<figitdropper x="218.5" y="6" lock="no" other=""/>
<figitbox x="213.5" y="400.5" lock="no" other="par=r/9/1"/>
<figitbox x="398.5" y="398.5" lock="no" other="par=r/2/1"/>
<figitpainter x="218.5" y="148.5" lock="no" other="color=9"/>
<figitpainter x="402.5" y="151.5" lock="no" other="color=2"/></room>
		<room roomID="51259" status="new" type="open" setting="main" title="the cool room" fg="blank" bg="bg/1.swf" author="kissyfaces28">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="290.5" y="6" lock="no" other=""/>
<figitdropper x="59.5" y="6" lock="no" other=""/>
<figitbox x="6" y="554" lock="no" other="par=r/0/1"/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="295.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="118.5" y="552.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="231.5" y="558.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="174.5" y="578.5" lock="no" other="rotation=0"/>
<fixedblock x="175.5" y="552.5" lock="no" other="rotation=0"/>
<fixedblock x="176.5" y="521.5" lock="no" other="rotation=0"/>
<fixedblock x="288.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="287.5" y="548.5" lock="no" other="rotation=0"/></room>
		<room roomID="51149" status="new" type="open" setting="main" title="lol lil mama" fg="blank" bg="bg/1.swf" author="rashawna21">
	<figitdropper x="285.5" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="29.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="11.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="272.5" y="519.5" lock="no" other="par=r/0/1"/>
<rubberblock x="312.5" y="294.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="553.5" y="298.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="62.5" y="299.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="195.5" y="513.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="434.5" y="496.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="309.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="576.5" y="199.5" lock="no" other="rotation=0"/>
<fixedblock x="37.5" y="147.5" lock="no" other="rotation=0"/>
<figitpainter x="176.5" y="159.5" lock="no" other="color=1"/>
<figitpainter x="423.5" y="175.5" lock="no" other="color=1"/>
<figitpainter x="531.5" y="387.5" lock="no" other="color=1"/>
<figitpainter x="45.5" y="419.5" lock="no" other="color=1"/>
<figitpainter x="316.5" y="392.5" lock="no" other="color=1"/></room>
		<room roomID="51083" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="swickard_ga">
	<figitdropper x="284.5" y="6" lock="no" other=""/>
<rubberblock x="319.5" y="256" lock="no" other="rotation=0.62 mat=rubber"/>
<rubberblock x="312" y="405" lock="no" other="rotation=-0.681 mat=rubber"/>
<rubberblock x="308.5" y="329" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="301.5" y="504.75" lock="no" other="rotation=0 mat=rubber"/>
<pvcpipe x="314" y="126.5" lock="no" other="rotation=-1.58"/>
<figitdivider x="272.5" y="71.5" lock="no" other=""/>
<figitdivider x="272.5" y="170.5" lock="no" other=""/>
<figitdivider x="270.5" y="124.5" lock="no" other=""/>
<spring x="293.5" y="228.5" lock="no" other="dir=up"/>
<spring x="311.5" y="228.5" lock="no" other="dir=up"/>
<spring x="271.5" y="228.5" lock="no" other="dir=up"/>
<spring x="292.5" y="198.5" lock="no" other="dir=up"/>
<spring x="286.5" y="111.5" lock="no" other="dir=up"/>
<elbowpipe x="282.5" y="543" lock="no" other="rotation=1.564"/>
<elbowpipe x="177" y="541" lock="no" other="rotation=-3.135"/>
<fidgitcannon x="261.5" y="224.5" lock="no" other="chute=91.553"/>
<fidgitcannon x="253.5" y="346.5" lock="no" other="chute=90.054"/>
<fidgitcannon x="253.5" y="413.5" lock="no" other="chute=91.686"/>
<fidgitcannon x="262.5" y="273.5" lock="no" other="chute=89.354"/></room>
		<room roomID="50767" status="" type="open" setting="" title="" fg="" bg="" author="mdetective">
	</room>
		<room roomID="50721" status="" type="open" setting="" title="" fg="" bg="" author="gman7194">
	</room>
		<room roomID="50388" status="new" type="open" setting="wind" title="DANGER!SHOCKS" fg="blank" bg="bg/1.swf" author="ssserpent">
	<figitdropper x="426.5" y="6" lock="no" other=""/>
<figitdropper x="308.5" y="6" lock="no" other=""/>
<figitdropper x="222.5" y="6" lock="no" other=""/>
<figitbox x="439.5" y="335.5" lock="no" other="par=r/0/1"/>
<figitbox x="325.5" y="396.5" lock="no" other="par=r/0/1"/>
<figitbox x="393.5" y="530.5" lock="no" other="par=r/0/1"/>
<rubberblock x="504.5" y="487.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="351.5" y="505.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="229.5" y="511.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="97.5" y="487.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="397.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="300.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="112.5" y="397.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="143.5" y="318.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="436.5" y="292.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="321.5" y="377.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="503.5" y="240.5" lock="no" other="rotation=0"/>
<fixedblock x="472.5" y="239.5" lock="no" other="rotation=0"/>
<fixedblock x="389.5" y="237.5" lock="no" other="rotation=0"/>
<fixedblock x="359.5" y="238.5" lock="no" other="rotation=0"/>
<fixedblock x="444.5" y="239.5" lock="no" other="rotation=0"/>
<fixedblock x="333.5" y="239.5" lock="no" other="rotation=0"/>
<fixedblock x="272.5" y="238.5" lock="no" other="rotation=0"/>
<fixedblock x="243.5" y="240.5" lock="no" other="rotation=0"/>
<fixedblock x="213.5" y="244.5" lock="no" other="rotation=0"/>
<fixedblock x="110.5" y="245.5" lock="no" other="rotation=0"/>
<fixedblock x="169.5" y="247.5" lock="no" other="rotation=0"/>
<fixedblock x="141.5" y="249.5" lock="no" other="rotation=0"/>
<fixedblock x="276.5" y="343.5" lock="no" other="rotation=0"/>
<fixedblock x="246.5" y="343.5" lock="no" other="rotation=0"/>
<fixedblock x="216.5" y="343.5" lock="no" other="rotation=0"/>
<pendulum x="237.5" y="335.5" lock="no" other="swing_x=80 swing_y=0"/>
<pendulum x="465.5" y="229.5" lock="no" other="swing_x=80 swing_y=0"/>
<pendulum x="356.5" y="229.5" lock="no" other="swing_x=80 swing_y=0"/>
<pendulum x="234.5" y="231.5" lock="no" other="swing_x=80 swing_y=0"/>
<pendulum x="131.5" y="240.5" lock="no" other="swing_x=80 swing_y=0"/></room>
		<room roomID="50312" status="new" type="open" setting="moon" title="bunch uv fidgit" fg="blank" bg="bg/2.swf" author="moleson2">
	<figitdropper x="396.5" y="6" lock="no" other=""/>
<figitdropper x="333.5" y="6" lock="no" other=""/>
<figitdropper x="270.5" y="6" lock="no" other=""/>
<figitbox x="318.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="242.5" y="555" lock="no" other="par=r/0/1"/>
<figitbox x="393.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="484.5" y="553" lock="no" other="rotation=-1.575 mat=rubber"/>
<rubberblock x="224.5" y="551" lock="no" other="rotation=1.519 mat=rubber"/></room>
		<room roomID="50120" status="new" type="open" setting="moon" title="pilot" fg="blank" bg="bg/1.swf" author="oeyj">
	<figitdropper x="332.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=l/0/10"/>
<pvcpipe x="438.5" y="222.5" lock="no" other="rotation=0.938"/>
<pvcpipe x="389.5" y="137.5" lock="no" other="rotation=1.095"/>
<pvcpipe x="494.5" y="303.5" lock="no" other="rotation=1"/>
<figitcombiner x="493" y="364.5" lock="no" other=""/></room>
		<room roomID="49393" status="new" type="open" setting="main" title="block time" fg="blank" bg="bg/13.swf" author="knicknack1">
	</room>
		<room roomID="49315" status="new" type="open" setting="main" title="anna'n crystal" fg="blank" bg="bg/6.swf" author="LOVE1401">
	<figitdropper x="198.5" y="6" lock="no" other=""/>
<figitbox x="138.5" y="530.5" lock="no" other="par=r/0/39"/>
<rubberblock x="96" y="535.75" lock="no" other="rotation=0.583 mat=rubber"/>
<rubberblock x="258.5" y="531" lock="no" other="rotation=-0.536 mat=rubber"/>
<rubberblock x="246.5" y="164.75" lock="no" other="rotation=-0.672 mat=rubber"/>
<rubberblock x="58" y="308.75" lock="no" other="rotation=0.773 mat=rubber"/>
<rubberblock x="339.5" y="503" lock="no" other="rotation=-0.364 mat=rubber"/>
<rubberblock x="419.5" y="477" lock="no" other="rotation=-0.444 mat=rubber"/>
<rubberblock x="46.5" y="510.75" lock="no" other="rotation=0.604 mat=rubber"/>
<rubberblock x="557.5" y="385.75" lock="no" other="rotation=-0.491 mat=rubber"/>
<fixedblock x="97.5" y="578.5" lock="no" other="rotation=0"/>
<fixedblock x="124.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="155.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="184.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="212.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="239.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="21" y="275.5" lock="no" other="rotation=0.368"/>
<fixedblock x="467.5" y="452.5" lock="no" other="rotation=-0.679"/>
<fixedblock x="487.5" y="433.5" lock="no" other="rotation=-0.895"/>
<fixedblock x="509" y="413.5" lock="no" other="rotation=-0.918"/></room>
		<room roomID="48783" status="new" type="open" setting="wind" title="easy wind" fg="blank" bg="bg/2.swf" author="sushiford">
	<figitdropper x="259.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="299.5" y="208.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="246.5" y="216.5" lock="no" other="rotation=0"/>
<fixedblock x="218.5" y="215.5" lock="no" other="rotation=0"/>
<fixedblock x="193.5" y="214.5" lock="no" other="rotation=0"/>
<fixedblock x="146.5" y="209.5" lock="no" other="rotation=0"/>
<fixedblock x="172.5" y="212.5" lock="no" other="rotation=0"/>
<fixedblock x="118.5" y="210.5" lock="no" other="rotation=0"/>
<fixedblock x="118.5" y="181.5" lock="no" other="rotation=0"/></room>
		<room roomID="48208" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/7.swf" author="matt881">
	<figitdropper x="232.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=l/4/5"/>
<rubberblock x="411.5" y="525.75" lock="no" other="rotation=0.168 mat=rubber"/>
<figitcombiner x="124" y="269.5" lock="no" other=""/></room>
		<room roomID="48201" status="new" type="open" setting="main" title="1 for 1" fg="blank" bg="bg/5.swf" author="Eman34166">
	<figitdropper x="31.4" y="6" lock="no" other=""/>
<figitbox x="90.6" y="556" lock="no" other="par=l/3/50"/>
<rubberblock x="52" y="348" lock="no" other="rotation=0.694 mat=rubber"/>
<rubberblock x="283.8" y="375.95" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="362.55" y="377.4" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="439.65" y="376.3" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="203.75" y="375.85" lock="no" other="rotation=0 mat=rubber"/>
<figitcombiner x="15.45" y="179" lock="no" other=""/>
<figitcombiner x="38.7" y="247.5" lock="no" other=""/>
<figitdivider x="22.6" y="74.45" lock="no" other=""/>
<figitdivider x="21.35" y="135.65" lock="no" other=""/>
<elbowpipe x="520.8" y="358.8" lock="no" other="rotation=0"/>
<conveyorbelt x="372.45" y="484.15" lock="no" other="cv=lt_fast"/></room>
		<room roomID="48171" status="" type="open" setting="" title="" fg="" bg="" author="mariosonic90">
	</room>
		<room roomID="47937" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="47935" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="47686" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/12.swf" author="jaimarie366">
	<figitdropper x="22.5" y="6" lock="no" other=""/>
<figitdropper x="257.9" y="6" lock="no" other=""/>
<figitdropper x="519.5" y="6" lock="no" other=""/>
<figitbox x="21.5" y="173.7" lock="no" other="par=r/0/1"/>
<figitbox x="259.9" y="116.1" lock="no" other="par=r/0/1"/>
<figitbox x="522" y="184.9" lock="no" other="par=r/0/1"/>
<rubberblock x="305.2" y="417.45" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="385.05" y="419" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="464.05" y="419.7" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="242.5" y="421" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="545" y="420.25" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="213.75" y="477.1" lock="no" other="rotation=1.599 mat=rubber"/>
<rubberblock x="211.95" y="550" lock="no" other="rotation=-1.431 mat=rubber"/>
<rubberblock x="454.5" y="208.35" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="184.1" y="211.55" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="585" y="220.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="423.8" lock="no" other="rotation=0"/>
<fixedblock x="310.3" y="191.7" lock="no" other="rotation=0"/>
<fixedblock x="292.7" y="217.3" lock="no" other="rotation=0"/>
<fixedblock x="318.3" y="244.5" lock="no" other="rotation=0"/>
<fixedblock x="340.7" y="220.5" lock="no" other="rotation=0"/></room>
		<room roomID="46932" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/2.swf" author="pmlyd">
	<figitdropper x="442.5" y="6" lock="no" other=""/>
<figitdropper x="327.5" y="6" lock="no" other=""/>
<figitdropper x="229.5" y="6" lock="no" other=""/>
<figitbox x="231.5" y="556" lock="no" other="par=r/0/100"/>
<figitbox x="338.5" y="555" lock="no" other="par=r/0/100"/>
<figitbox x="436" y="556" lock="no" other="par=r/0/100"/></room>
		<room roomID="46619" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46618" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46616" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46614" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46612" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46604" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46599" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46598" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46588" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46587" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46580" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46579" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46574" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46554" status="new" type="open" setting="moon" title="lots of numbers" fg="blank" bg="bg/9.swf" author="vi1234567">
	<figitdropper x="330.5" y="6" lock="no" other=""/>
<figitdropper x="328.5" y="6" lock="no" other=""/>
<figitdropper x="328.5" y="6" lock="no" other=""/>
<figitbox x="323.5" y="131.5" lock="no" other="par=r/0/100"/>
<figitbox x="322.5" y="128.5" lock="no" other="par=r/0/200"/>
<figitbox x="322.5" y="130.5" lock="no" other="par=r/0/300"/></room>
		<room roomID="46551" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46547" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46545" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46543" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46541" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46539" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46537" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46534" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46533" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46530" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46528" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46525" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46523" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46521" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46520" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46517" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46516" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46511" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46508" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46460" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46416" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46414" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46412" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46410" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46407" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46405" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46403" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46400" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46399" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46396" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46394" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46393" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46390" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46388" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46386" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46384" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46382" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46380" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46379" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46376" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46375" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46372" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46371" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46369" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46366" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46365" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46362" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46318" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46309" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46165" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46163" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46096" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46089" status="new" type="open" setting="main" title="Jaedon" fg="blank" bg="bg/8.swf" author="Jaedon">
	</room>
		<room roomID="46071" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46064" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46061" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="46038" status="" type="open" setting="" title="" fg="" bg="" author="">
	</room>
		<room roomID="45948" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/6.swf" author="coke120">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitdropper x="309.5" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="78.5" y="505.5" lock="no" other="par=r/0/1"/>
<figitbox x="305.5" y="504.5" lock="no" other="par=r/0/1"/>
<figitbox x="522" y="503.5" lock="no" other="par=r/0/1"/>
<rubberblock x="46" y="210.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46" y="525.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="503.5" y="519.5" lock="no" other="rotation=0"/>
<fixedblock x="283.5" y="521.5" lock="no" other="rotation=0"/>
<pvcpipe x="240.5" y="256.5" lock="no" other="rotation=0"/>
<pvcpipe x="456.5" y="263.5" lock="no" other="rotation=0"/>
<pvcpipe x="434.5" y="498.5" lock="no" other="rotation=0"/>
<pvcpipe x="211.5" y="486.5" lock="no" other="rotation=0"/></room>
		<room roomID="45653" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/7.swf" author="miikey969">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="259.5" y="6" lock="no" other=""/>
<figitdropper x="8.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="264.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="6.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="449.5" y="545.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="180.5" y="544.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="385.5" y="551.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="248.5" y="557.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="127.5" y="544.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="512.5" y="553.75" lock="no" other="rotation=0 mat=rubber"/>
<spring x="518.5" y="527.5" lock="no" other="dir=left"/>
<spring x="158.5" y="499.5" lock="no" other="dir=left"/>
<spring x="42.5" y="527.5" lock="no" other="dir=right"/>
<spring x="285.5" y="527.5" lock="no" other="dir=right"/>
<spring x="433.5" y="497.5" lock="no" other="dir=up"/></room>
		<room roomID="45542" status="" type="open" setting="" title="" fg="" bg="" author="juiceb0x2">
	</room>
		<room roomID="45482" status="new" type="open" setting="main" title="bb" fg="blank" bg="bg/1.swf" author="paiten">
	<figitdropper x="264.5" y="6" lock="no" other=""/>
<figitdropper x="267.5" y="6" lock="no" other=""/>
<figitdropper x="265.5" y="6" lock="no" other=""/>
<figitbox x="262.5" y="556" lock="no" other="par=r/0/18"/>
<rubberblock x="472.5" y="517.75" lock="no" other="rotation=0.037 mat=conc"/>
<rubberblock x="470.5" y="553" lock="no" other="rotation=-1.58 mat=wood"/>
<rubberblock x="305.5" y="541.75" lock="no" other="rotation=0 mat=rubber"/>
<fidgitcannon x="247.5" y="70.5" lock="no" other="chute=90"/></room>
		<room roomID="44886" status="new" type="open" setting="main" title="crazy room" fg="blank" bg="bg/9.swf" author="bloom484">
	<figitdropper x="482.5" y="6" lock="no" other=""/>
<figitdropper x="291.5" y="6" lock="no" other=""/>
<figitdropper x="97.5" y="6" lock="no" other=""/>
<figitbox x="489.5" y="519.5" lock="no" other="par=r/0/1"/>
<figitbox x="293.5" y="525.5" lock="no" other="par=r/0/1"/>
<figitbox x="103.5" y="539.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="44799" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/6.swf" author="jl011401">
	<figitdropper x="287.5" y="6" lock="no" other=""/>
<figitbox x="283.5" y="267.5" lock="no" other="par=r/6/1"/>
<figitpainter x="289.5" y="74.5" lock="no" other="color=6"/></room>
		<room roomID="44705" status="new" type="open" setting="main" title="1/2 time" fg="blank" bg="bg/1.swf" author="NRFCOOLLL">
	<figitdropper x="45.5" y="6" lock="no" other=""/>
<figitdropper x="219.5" y="6" lock="no" other=""/>
<figitdropper x="395.5" y="6" lock="no" other=""/>
<figitbox x="6.5" y="556" lock="no" other="par=r/2/55"/>
<rubberblock x="127.5" y="537.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="208.5" y="538.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="285.5" y="538.75" lock="no" other="rotation=0 mat=conc"/>
<figitpainter x="358.5" y="342.5" lock="no" other="color=2"/>
<pendulum x="422.5" y="388.5" lock="no" other="swing_x=-1 swing_y=-143"/>
<conveyorbelt x="173.5" y="321.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="406" y="321.5" lock="no" other="cv=lt_med"/>
<conveyorbelt x="6" y="322.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="318.5" y="524.5" lock="no" other="cv=lt_med"/></room>
		<room roomID="43890" status="new" type="open" setting="main" title="log cliff" fg="blank" bg="bg/9.swf" author="magaoay">
	<figitdropper x="457.5" y="6" lock="no" other=""/>
<figitbox x="159.5" y="386.5" lock="no" other="par=r/0/5"/>
<rubberblock x="488.5" y="255.75" lock="no" other="rotation=-0.549 mat=wood"/>
<rubberblock x="424.5" y="297.75" lock="no" other="rotation=-0.627 mat=wood"/></room>
		<room roomID="43693" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/14.swf" author="cwb1">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="522" y="263.5" lock="no" other="par=r/0/1"/>
<rubberblock x="481.5" y="279.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="407.5" y="276.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="333.5" y="273.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="254.5" y="272.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="193.5" y="270.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="120.5" y="269.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46" y="274.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="43040" status="new" type="open" setting="moon" title="moon" fg="blank" bg="bg/1.swf" author="jaswr">
	<figitdropper x="155" y="6" lock="no" other=""/>
<figitbox x="447.5" y="83.5" lock="no" other="par=r/2/1"/>
<rubberblock x="336.5" y="314.75" lock="no" other="rotation=0.222 mat=rubber"/>
<rubberblock x="471.5" y="330.75" lock="no" other="rotation=0.129 mat=rubber"/>
<rubberblock x="560" y="353.75" lock="no" other="rotation=1.566 mat=rubber"/>
<fixedblock x="420.5" y="21.5" lock="no" other="rotation=0"/>
<fixedblock x="493.5" y="146.5" lock="no" other="rotation=0"/>
<fixedblock x="423.5" y="53.5" lock="no" other="rotation=0"/>
<fixedblock x="426.5" y="86.5" lock="no" other="rotation=0"/>
<fixedblock x="430.5" y="121.5" lock="no" other="rotation=0"/>
<fixedblock x="459.5" y="149.5" lock="no" other="rotation=0"/>
<fixedblock x="520.5" y="148.5" lock="no" other="rotation=0"/>
<fidgitcannon x="156.5" y="188.5" lock="no" other="chute=10.269"/></room>
		<room roomID="42728" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="joshtutak">
	<figitdropper x="473.5" y="6" lock="no" other=""/>
<figitdropper x="415.5" y="6" lock="no" other=""/>
<figitdropper x="364.5" y="6" lock="no" other=""/>
<figitbox x="468.5" y="77.5" lock="no" other="par=r/0/1"/>
<figitbox x="405.5" y="77.5" lock="no" other="par=r/0/1"/>
<figitbox x="346.5" y="87.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="41820" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/11.swf" author="asxela">
	<figitdropper x="319.5" y="6" lock="no" other=""/>
<figitbox x="295.5" y="128.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="41019" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/3.swf" author="DS588274">
	<figitdropper x="512" y="6" lock="no" other=""/>
<figitbox x="6" y="556" lock="no" other="par=r/0/1"/>
<fixedblock x="379.5" y="579" lock="no" other="rotation=0"/>
<fixedblock x="381.5" y="551.5" lock="no" other="rotation=0"/>
<fixedblock x="380.5" y="522.5" lock="no" other="rotation=0"/>
<fixedblock x="289.5" y="565.5" lock="no" other="rotation=0"/>
<fixedblock x="320.5" y="564.5" lock="no" other="rotation=0"/>
<fixedblock x="349.5" y="564.5" lock="no" other="rotation=0"/>
<fixedblock x="321.5" y="540.5" lock="no" other="rotation=0"/>
<fixedblock x="320.5" y="511.5" lock="no" other="rotation=0"/>
<fixedblock x="225.5" y="84.5" lock="no" other="rotation=0"/>
<fixedblock x="165.5" y="83.5" lock="no" other="rotation=0"/>
<fixedblock x="196.5" y="84.5" lock="no" other="rotation=0"/>
<fixedblock x="196.5" y="114.5" lock="no" other="rotation=0"/>
<fixedblock x="197.5" y="145.5" lock="no" other="rotation=0"/>
<pvcpipe x="149.5" y="197.5" lock="no" other="rotation=1.573"/>
<figitdivider x="12" y="169.5" lock="no" other=""/>
<figitdivider x="10.5" y="225.5" lock="no" other=""/>
<figitdivider x="10" y="284.5" lock="no" other=""/>
<spring x="403.5" y="564" lock="no" other="dir=left"/>
<spring x="132.5" y="332.5" lock="no" other="dir=left"/>
<spring x="264.5" y="468.5" lock="no" other="dir=left"/>
<elbowpipe x="307.5" y="437" lock="no" other="rotation=3.135"/>
<elbowpipe x="267.5" y="336" lock="no" other="rotation=0"/>
<elbowpipe x="171" y="297" lock="no" other="rotation=3.128"/>
<elbowpipe x="401.5" y="477" lock="no" other="rotation=0"/>
<elbowpipe x="70" y="120" lock="no" other="rotation=-1.564"/>
<conveyorbelt x="406" y="568" lock="no" other="cv=lt_med"/>
<conveyorbelt x="6" y="394.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="61.5" y="443.5" lock="no" other="cv=lt_med"/>
<conveyorbelt x="7" y="501.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="77.5" y="549.5" lock="no" other="cv=lt_med"/>
<fidgitcannon x="491" y="76.5" lock="no" other="chute=121.883"/>
<fidgitcannon x="441" y="176.5" lock="no" other="chute=65.561"/>
<fidgitcannon x="477" y="276.5" lock="no" other="chute=112.888"/>
<fidgitcannon x="439.5" y="372.5" lock="no" other="chute=43.985"/>
<fidgitcannon x="496.5" y="469" lock="no" other="chute=149.319"/></room>
		<room roomID="40934" status="new" type="open" setting="moon" title="coolcat" fg="blank" bg="bg/3.swf" author="cherrell17">
	<figitdropper x="326.5" y="6" lock="no" other=""/>
<figitbox x="224.5" y="157.5" lock="no" other="par=r/0/1"/>
<figitbox x="453.5" y="134.5" lock="no" other="par=r/0/1"/>
<rubberblock x="334.5" y="133.75" lock="no" other="rotation=-0.243 mat=rubber"/>
<rubberblock x="408.5" y="140.75" lock="no" other="rotation=0.364 mat=rubber"/></room>
		<room roomID="40894" status="new" type="open" setting="main" title="hearts on duity" fg="blank" bg="bg/2.swf" author="vi1234567">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=l/8/400"/>
<rubberblock x="514.5" y="255.75" lock="no" other="rotation=-1.544 mat=rubber"/>
<rubberblock x="513.5" y="515.75" lock="no" other="rotation=1.617 mat=rubber"/>
<rubberblock x="514.5" y="436.75" lock="no" other="rotation=1.576 mat=rubber"/>
<figitcombiner x="6" y="148.5" lock="no" other=""/>
<figitpainter x="6" y="79.5" lock="no" other="color=8"/>
<elbowpipe x="550" y="345" lock="no" other="rotation=0"/>
<conveyorbelt x="169.5" y="347.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="338" y="347.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="6" y="346.5" lock="no" other="cv=rt_med"/></room>
		<room roomID="40151" status="new" type="open" setting="main" title="Rolly Poly" fg="blank" bg="bg/5.swf" author="kittyloo">
	<figitdropper x="296.5" y="6" lock="no" other=""/>
<figitdropper x="385.5" y="6" lock="no" other=""/>
<figitbox x="316.5" y="556" lock="no" other="par=r/0/20"/>
<rubberblock x="310.5" y="157.75" lock="no" other="rotation=0.295 mat=conc"/>
<rubberblock x="413.5" y="225.75" lock="no" other="rotation=-0.417 mat=conc"/>
<rubberblock x="314.5" y="308.75" lock="no" other="rotation=0.479 mat=conc"/>
<rubberblock x="401.5" y="386.75" lock="no" other="rotation=-0.403 mat=conc"/>
<rubberblock x="319.5" y="468.75" lock="no" other="rotation=0.471 mat=conc"/>
<rubberblock x="436.5" y="523.75" lock="no" other="rotation=-0.41 mat=conc"/></room>
		<room roomID="40135" status="new" type="open" setting="wind" title="the wind" fg="blank" bg="bg/6.swf" author="lew300">
	<figitdropper x="239.5" y="6" lock="no" other=""/>
<figitbox x="522" y="552" lock="no" other="par=r/0/1"/>
<rubberblock x="281.5" y="254.75" lock="no" other="rotation=0.66 mat=rubber"/>
<rubberblock x="402.5" y="306.75" lock="no" other="rotation=1.32 mat=rubber"/>
<rubberblock x="366.5" y="412.75" lock="no" other="rotation=-0.574 mat=rubber"/>
<rubberblock x="416.5" y="52" lock="no" other="rotation=1.207 mat=rubber"/>
<rubberblock x="427.5" y="198.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="40009" status="new" type="open" setting="wind" title="LOVE" fg="blank" bg="bg/1.swf" author="cierra">
	<figitdropper x="280.5" y="6" lock="no" other=""/>
<figitbox x="261.5" y="294" lock="no" other="par=r/0/1"/>
<figitbox x="343.5" y="293.5" lock="no" other="par=r/0/1"/>
<rubberblock x="224.5" y="310.75" lock="no" other="rotation=0.81 mat=rubber"/>
<rubberblock x="452.5" y="300.75" lock="no" other="rotation=-1.177 mat=rubber"/></room>
		<room roomID="39803" status="new" type="open" setting="moon" title="Lll" fg="blank" bg="bg/12.swf" author="lkj">
	<figitdropper x="17" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/2/1"/>
<figitcombiner x="500" y="421.5" lock="no" other=""/>
<figitpainter x="529" y="491.5" lock="no" other="color=1"/>
<fidgitcannon x="6" y="71.5" lock="no" other="chute=18.409"/></room>
		<room roomID="39760" status="new" type="open" setting="wind" title="mercedes" fg="blank" bg="bg/2.swf" author="1234nia">
	<figitdropper x="299.5" y="6" lock="no" other=""/>
<figitdropper x="226.5" y="6" lock="no" other=""/>
<figitdropper x="380.5" y="6" lock="no" other=""/>
<figitbox x="496.5" y="176.5" lock="no" other="par=r/0/1"/>
<figitbox x="426.5" y="181.5" lock="no" other="par=r/0/1"/>
<figitbox x="362.5" y="186.5" lock="no" other="par=r/0/1"/>
<rubberblock x="421.5" y="399.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="392.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="495.5" y="397.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="362.5" y="403.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="303.5" y="405.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="242.5" y="408.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="182.5" y="407.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="109.5" y="406.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46.5" y="405.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="401.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="45.5" y="45.5" lock="no" other="rotation=0"/>
<fixedblock x="580.5" y="38.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="578.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="552.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="520.5" lock="no" other="rotation=0"/>
<fixedblock x="584.5" y="68.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="95.5" lock="no" other="rotation=0"/>
<fixedblock x="48.5" y="76.5" lock="no" other="rotation=0"/>
<fixedblock x="52.5" y="109.5" lock="no" other="rotation=0"/>
<fixedblock x="30.5" y="566.5" lock="no" other="rotation=0"/>
<fixedblock x="29.5" y="537.5" lock="no" other="rotation=0"/>
<fixedblock x="39.5" y="493.5" lock="no" other="rotation=0"/>
<fixedblock x="581.5" y="135.5" lock="no" other="rotation=0"/>
<fixedblock x="577.5" y="473.5" lock="no" other="rotation=0"/>
<fixedblock x="28.5" y="452.5" lock="no" other="rotation=0"/></room>
		<room roomID="39529" status="new" type="open" setting="main" title="Fidgit Factory" fg="blank" bg="bg/12.swf" author="anniemachine">
	<figitdropper x="44" y="6" lock="no" other=""/>
<figitdropper x="302.5" y="6" lock="no" other=""/>
<figitdropper x="504.5" y="6" lock="no" other=""/>
<figitbox x="7" y="554.5" lock="no" other="par=r/0/20"/>
<figitbox x="107.5" y="556" lock="no" other="par=r/0/5"/>
<figitbox x="231" y="448" lock="no" other="par=r/0/0"/>
<rubberblock x="364.5" y="367.75" lock="no" other="rotation=-0.979 mat=rubber"/>
<rubberblock x="282.5" y="569.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="207.75" lock="no" other="rotation=2.055 mat=wood"/>
<rubberblock x="394" y="247.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="450.5" y="270" lock="no" other="rotation=1.543 mat=wood"/>
<rubberblock x="46" y="203.75" lock="no" other="rotation=1.171 mat=wood"/>
<rubberblock x="272.5" y="247" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="505.5" y="236.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="192.5" y="252.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="109.5" y="249" lock="no" other="rotation=0 mat=conc"/>
<fixedblock x="116.5" y="21" lock="no" other="rotation=0"/>
<fixedblock x="585" y="25.5" lock="no" other="rotation=0"/>
<fixedblock x="489.5" y="21" lock="no" other="rotation=0"/>
<fixedblock x="387.5" y="25.5" lock="no" other="rotation=0"/>
<fixedblock x="287.5" y="26.5" lock="no" other="rotation=0"/>
<fixedblock x="21" y="21" lock="no" other="rotation=0"/>
<fixedblock x="424.5" y="116.5" lock="no" other="rotation=0"/>
<fixedblock x="167.5" y="157.5" lock="no" other="rotation=0"/>
<fixedblock x="189.5" y="398.5" lock="no" other="rotation=0"/>
<fixedblock x="186.5" y="268.5" lock="no" other="rotation=0"/>
<fixedblock x="58.5" y="376.5" lock="no" other="rotation=0"/>
<fixedblock x="432.5" y="427.5" lock="no" other="rotation=0"/>
<fixedblock x="453.5" y="513.5" lock="no" other="rotation=0"/>
<fixedblock x="483.5" y="517.5" lock="no" other="rotation=0"/>
<fixedblock x="430.5" y="515.5" lock="no" other="rotation=0"/>
<pvcpipe x="537" y="123.5" lock="no" other="rotation=1.6"/>
<pvcpipe x="330.5" y="287.5" lock="no" other="rotation=1.609"/>
<pvcpipe x="79" y="123.5" lock="no" other="rotation=1.542"/>
<pvcpipe x="335.5" y="127.5" lock="no" other="rotation=1.574"/>
<pvcpipe x="414" y="201.5" lock="no" other="rotation=0"/>
<pvcpipe x="197.5" y="207.5" lock="no" other="rotation=0"/>
<pvcpipe x="280.5" y="385.5" lock="no" other="rotation=-0.62"/>
<pvcpipe x="550" y="342.5" lock="no" other="rotation=0"/>
<pvcpipe x="439.5" y="63.5" lock="no" other="rotation=0"/>
<pvcpipe x="206.5" y="54.5" lock="no" other="rotation=0"/>
<figitcombiner x="401.5" y="310.5" lock="no" other=""/>
<figitcombiner x="404.5" y="376.5" lock="no" other=""/>
<figitcombiner x="402.5" y="433.5" lock="no" other=""/></room>
		<room roomID="39442" status="new" type="open" setting="moon" title="" fg="blank" bg="bg/3.swf" author="ktkt">
	<figitdropper x="283.5" y="6" lock="no" other=""/>
<figitdropper x="357.5" y="6" lock="no" other=""/>
<figitdropper x="412.5" y="6" lock="no" other=""/>
<figitbox x="345.5" y="556" lock="no" other="par=r/0/999"/>
<pvcpipe x="387.5" y="125.5" lock="no" other="rotation=1.592"/>
<pvcpipe x="436.5" y="130.5" lock="no" other="rotation=-1.594"/>
<pvcpipe x="318.5" y="130.5" lock="no" other="rotation=-1.576"/>
<pendulum x="458.5" y="126.5" lock="no" other="swing_x=-23 swing_y=446"/>
<pendulum x="253.5" y="106.5" lock="no" other="swing_x=74 swing_y=466"/></room>
		<room roomID="39127" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/5.swf" author="MichaelLG">
	<figitdropper x="6.5" y="6" lock="no" other=""/>
<figitdropper x="336.5" y="6" lock="no" other=""/>
<figitdropper x="282.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/49"/>
<pendulum x="146.5" y="230.5" lock="no" other="swing_x=1 swing_y=79"/>
<pendulum x="441.5" y="365.5" lock="no" other="swing_x=0 swing_y=103"/>
<elbowpipe x="244.5" y="202" lock="no" other="rotation=0"/>
<conveyorbelt x="7.5" y="206.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="105.5" y="328.5" lock="no" other="cv=lt_med"/>
<conveyorbelt x="6" y="488.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="196.5" y="488.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="369" y="489" lock="no" other="cv=rt_med"/></room>
		<room roomID="39035" status="new" type="open" setting="main" title="GG'S ROOM" fg="blank" bg="bg/2.swf" author="gafftwina">
	<figitdropper x="275.5" y="6" lock="no" other=""/>
<figitbox x="520.7" y="555.2" lock="no" other="par=s/9/9"/>
<figitbox x="260.7" y="554.5" lock="no" other="par=r/10/14"/>
<figitbox x="6" y="556" lock="no" other="par=l/8/9"/>
<rubberblock x="255.3" y="402.75" lock="no" other="rotation=1.566 mat=conc"/>
<figitcombiner x="6" y="247.1" lock="no" other=""/>
<figitdivider x="518.9" y="228.5" lock="no" other=""/>
<figitpainter x="532" y="435.5" lock="no" other="color=9"/>
<figitpainter x="272.1" y="438.7" lock="no" other="color=10"/>
<figitpainter x="25.2" y="435.5" lock="no" other="color=8"/>
<conveyorbelt x="313.3" y="147.3" lock="no" other="cv=rt_med"/>
<conveyorbelt x="107.95" y="102.5" lock="no" other="cv=lt_med"/></room>
		<room roomID="38960" status="new" type="open" setting="wind" title="wind" fg="blank" bg="bg/1.swf" author="toahero339">
	<figitdropper x="300.75" y="6" lock="no" other=""/>
<figitbox x="444.05" y="551.25" lock="no" other="par=s/0/3"/>
<figitbox x="522" y="549.7" lock="no" other="par=s/0/3"/>
<rubberblock x="415.35" y="228.15" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="386.3" lock="no" other="rotation=-0.4 mat=conc"/>
<pvcpipe x="354.7" y="100.95" lock="no" other="rotation=1.03"/>
<figitdivider x="442.6" y="415.8" lock="no" other=""/></room>
		<room roomID="38493" status="new" type="open" setting="main" title="the contaner" fg="blank" bg="bg/2.swf" author="sodaob2">
	<figitdropper x="48.5" y="6" lock="no" other=""/>
<figitbox x="259.5" y="555" lock="no" other="par=s/3/30"/>
<rubberblock x="76.5" y="142.75" lock="no" other="rotation=0.292 mat=conc"/>
<rubberblock x="235.5" y="549" lock="no" other="rotation=-1.573 mat=conc"/>
<rubberblock x="111.5" y="549" lock="no" other="rotation=1.112 mat=rubber"/>
<rubberblock x="232.5" y="413" lock="no" other="rotation=-1.589 mat=conc"/>
<rubberblock x="112.5" y="469.75" lock="no" other="rotation=1.579 mat=conc"/>
<fixedblock x="350.5" y="541.5" lock="no" other="rotation=0"/>
<fixedblock x="352.5" y="510.5" lock="no" other="rotation=0"/>
<fixedblock x="350.5" y="481.5" lock="no" other="rotation=0"/>
<fixedblock x="351.5" y="452.5" lock="no" other="rotation=0"/>
<figitcombiner x="117.5" y="139.5" lock="no" other=""/>
<figitdivider x="125.5" y="226.5" lock="no" other=""/>
<figitdivider x="127.5" y="380.5" lock="no" other=""/>
<figitpainter x="136.5" y="302.5" lock="no" other="color=3"/>
<spring x="133.5" y="563.5" lock="no" other="dir=left"/>
<spring x="174.5" y="563.5" lock="no" other="dir=left"/></room>
		<room roomID="38247" status="" type="open" setting="" title="" fg="" bg="" author="wdstiff">
	</room>
		<room roomID="38092" status="new" type="open" setting="wind" title="Paddleball" fg="blank" bg="bg/4.swf" author="car1">
	<figitdropper x="316.5" y="6" lock="no" other=""/>
<figitbox x="318" y="556" lock="no" other="par=l/8/1"/>
<rubberblock x="227" y="429.75" lock="no" other="rotation=-2.416 mat=rubber"/>
<rubberblock x="422.5" y="470.75" lock="no" other="rotation=-0.748 mat=rubber"/>
<rubberblock x="528" y="352.75" lock="no" other="rotation=-0.584 mat=rubber"/>
<rubberblock x="477.5" y="414.75" lock="no" other="rotation=-0.926 mat=rubber"/>
<rubberblock x="287.5" y="482.75" lock="no" other="rotation=0.654 mat=rubber"/>
<fixedblock x="365.5" y="276.5" lock="no" other="rotation=0.854"/>
<fixedblock x="305.5" y="388.5" lock="no" other="rotation=0.68"/>
<fixedblock x="418.5" y="356.5" lock="no" other="rotation=-0.329"/>
<fixedblock x="258.5" y="294.5" lock="no" other="rotation=0"/>
<fixedblock x="340.5" y="336.5" lock="no" other="rotation=0"/>
<figitcombiner x="299.5" y="95.5" lock="no" other=""/>
<figitpainter x="328.5" y="489.5" lock="no" other="color=8"/></room>
		<room roomID="38003" status="" type="open" setting="" title="" fg="" bg="" author="PACHONCITO">
	</room>
		<room roomID="38002" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/3.swf" author="cmvs">
	<figitdropper x="466.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/></room>
		<room roomID="36900" status="new" type="open" setting="main" title="bounce" fg="blank" bg="bg/15.swf" author="kramdin">
	<figitdropper x="472.5" y="6" lock="no" other=""/>
<figitdropper x="347.5" y="6" lock="no" other=""/>
<figitdropper x="233.5" y="6" lock="no" other=""/>
<figitbox x="120.5" y="556" lock="no" other="par=r/5/1"/>
<figitpainter x="125.5" y="387.5" lock="no" other="color=5"/>
<elbowpipe x="156.5" y="141" lock="no" other="rotation=-1.595"/>
<conveyorbelt x="238.5" y="124.5" lock="no" other="cv=lt_med"/>
<conveyorbelt x="219.5" y="295.5" lock="no" other="cv=lt_med"/>
<conveyorbelt x="197" y="539.5" lock="no" other="cv=lt_med"/>
<fidgitcannon x="105.5" y="298.5" lock="no" other="chute=90"/>
<fidgitcannon x="106.5" y="449.5" lock="no" other="chute=90"/>
<fidgitcannon x="107.5" y="200.5" lock="no" other="chute=90.387"/></room>
		<room roomID="36899" status="new" type="open" setting="main" title="bounce 180 pain" fg="blank" bg="bg/1.swf" author="kramdin">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitbox x="506.5" y="549.5" lock="no" other="par=l/5/1"/>
<fixedblock x="585" y="96.5" lock="no" other="rotation=0"/>
<pvcpipe x="550" y="153.5" lock="no" other="rotation=1.565"/>
<pvcpipe x="549.5" y="254.5" lock="no" other="rotation=1.572"/>
<figitcombiner x="500" y="337.5" lock="no" other=""/>
<figitpainter x="522.5" y="419.5" lock="no" other="color=5"/>
<spring x="18.5" y="510.5" lock="no" other="dir=right"/>
<spring x="278.5" y="349.5" lock="no" other="dir=right"/>
<spring x="178.5" y="354.5" lock="no" other="dir=right"/>
<conveyorbelt x="350.5" y="81.5" lock="no" other="cv=rt_med"/></room>
		<room roomID="36890" status="new" type="open" setting="wind" title="sweet" fg="blank" bg="bg/1.swf" author="tithew">
	<figitdropper x="90.5" y="6" lock="no" other=""/>
<figitbox x="120.5" y="336.5" lock="no" other="par=r/1/1"/>
<rubberblock x="254.5" y="231.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="305.5" y="358.75" lock="no" other="rotation=-1.121 mat=rubber"/>
<fixedblock x="100.5" y="470.5" lock="no" other="rotation=0"/>
<fixedblock x="209.5" y="259.5" lock="no" other="rotation=0"/>
<pvcpipe x="159.5" y="117.5" lock="no" other="rotation=0.809"/>
<figitpainter x="472.5" y="251.5" lock="no" other="color=10"/>
<figitpainter x="152.5" y="425.5" lock="no" other="color=2"/>
<figitpainter x="128.5" y="268.5" lock="no" other="color=1"/>
<pendulum x="450.5" y="64.5" lock="no" other="swing_x=90 swing_y=40"/>
<spring x="248.5" y="564" lock="no" other="dir=left"/>
<spring x="23.5" y="564" lock="no" other="dir=right"/>
<elbowpipe x="485.5" y="369" lock="no" other="rotation=1.522"/>
<conveyorbelt x="278.5" y="449.5" lock="no" other="cv=rt_med"/>
<conveyorbelt x="397" y="510.5" lock="no" other="cv=lt_fast"/>
<fidgitcannon x="109.5" y="487" lock="no" other="chute=-165"/></room>
		<room roomID="36570" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="christocat">
	<figitdropper x="338.5" y="6" lock="no" other=""/>
<figitbox x="331.5" y="459.5" lock="no" other="par=r/0/0"/>
<pvcpipe x="286.5" y="284.5" lock="no" other="rotation=0"/>
<pvcpipe x="195.5" y="284.5" lock="no" other="rotation=0"/>
<pvcpipe x="170.5" y="398.5" lock="no" other="rotation=0"/>
<pvcpipe x="260.5" y="397.5" lock="no" other="rotation=0"/>
<figitdivider x="333.5" y="77.5" lock="no" other=""/>
<figitdivider x="331.5" y="131.5" lock="no" other=""/>
<figitdivider x="329.5" y="184.5" lock="no" other=""/>
<elbowpipe x="104" y="305" lock="no" other="rotation=-1.561"/>
<elbowpipe x="350.5" y="417" lock="no" other="rotation=0"/>
<fidgitcannon x="319.5" y="235.5" lock="no" other="chute=-179.782"/>
<fidgitcannon x="30.5" y="350.5" lock="no" other="chute=0.828"/></room>
		<room roomID="36476" status="new" type="open" setting="moon" title="0GS" fg="blank" bg="bg/1.swf" author="spongebob308">
	<figitdropper x="298.5" y="6" lock="no" other=""/>
<figitbox x="6.5" y="556" lock="no" other="par=s/10/300"/>
<figitbox x="522" y="556" lock="no" other="par=s/3/300"/>
<pvcpipe x="295.5" y="192.5" lock="no" other="rotation=1.587"/>
<pvcpipe x="357" y="191.5" lock="no" other="rotation=-1.558"/>
<figitdivider x="290.5" y="70.5" lock="no" other=""/>
<figitpainter x="540" y="396.5" lock="no" other="color=3"/>
<figitpainter x="6" y="369.5" lock="no" other="color=10"/>
<elbowpipe x="384.5" y="299" lock="no" other="rotation=-3.139"/>
<elbowpipe x="276.5" y="300" lock="no" other="rotation=1.61"/>
<conveyorbelt x="31.5" y="342.5" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="384" y="339.5" lock="no" other="cv=rt_fast"/></room>
		<room roomID="36120" status="new" type="open" setting="wind" title="jumpy painter" fg="blank" bg="bg/9.swf" author="rebeccaE1">
	<figitdropper x="318.5" y="6" lock="no" other=""/>
<figitdropper x="150.5" y="6" lock="no" other=""/>
<figitdropper x="483.5" y="6" lock="no" other=""/>
<figitbox x="168.5" y="310.5" lock="no" other="par=l/2/25"/>
<figitbox x="492.5" y="351.5" lock="no" other="par=l/1/25"/>
<figitbox x="361.5" y="464.5" lock="no" other="par=l/9/25"/>
<fixedblock x="347.5" y="154.5" lock="no" other="rotation=0"/>
<figitcombiner x="326.5" y="75.5" lock="no" other=""/>
<figitcombiner x="446.5" y="103.5" lock="no" other=""/>
<figitcombiner x="155.5" y="105.5" lock="no" other=""/>
<figitpainter x="416.5" y="184.5" lock="no" other="color=9"/>
<figitpainter x="539" y="181.5" lock="no" other="color=1"/>
<figitpainter x="476.5" y="246.5" lock="no" other="color=1"/>
<figitpainter x="355.5" y="248.5" lock="no" other="color=9"/>
<figitpainter x="297.5" y="187.5" lock="no" other="color=6"/>
<figitpainter x="236.5" y="250.5" lock="no" other="color=6"/>
<figitpainter x="179.5" y="186.5" lock="no" other="color=2"/>
<figitpainter x="121.5" y="247.5" lock="no" other="color=2"/>
<conveyorbelt x="406" y="461.5" lock="no" other="cv=lt_slow"/>
<fidgitcannon x="337.5" y="345.5" lock="no" other="chute=85.61"/></room>
		<room roomID="35908" status="new" type="open" setting="main" title="45My New Room" fg="blank" bg="bg/10.swf" author="mrclown123">
	<figitdropper x="359.5" y="6" lock="no" other=""/>
<figitbox x="62.7" y="207.45" lock="no" other="par=s/10/890"/>
<figitdivider x="358.9" y="76.8" lock="no" other=""/>
<figitpainter x="371.85" y="133.75" lock="no" other="color=10"/>
<spring x="390.55" y="366.45" lock="no" other="dir=left"/>
<conveyorbelt x="47.8" y="244.45" lock="no" other="cv=rt_med"/></room>
		<room roomID="35841" status="new" type="open" setting="wind" title="My New Room" fg="blank" bg="bg/6.swf" author="xiej">
	<figitdropper x="351.5" y="6" lock="no" other=""/>
<figitbox x="414.5" y="543" lock="no" other="par=r/0/1"/>
<rubberblock x="379.5" y="339.75" lock="no" other="rotation=0 mat=rubber"/>
<pendulum x="22.5" y="44.5" lock="no" other="swing_x=197 swing_y=1"/>
<elbowpipe x="497.5" y="141" lock="no" other="rotation=-0.044"/>
<conveyorbelt x="255.5" y="137.5" lock="no" other="cv=rt_fast"/>
<fidgitcannon x="463.5" y="197.5" lock="no" other="chute=145.221"/>
<fidgitcannon x="13.5" y="263.5" lock="no" other="chute=29.253"/></room>
		<room roomID="35794" status="new" type="open" setting="main" title="moma meya" fg="blank" bg="bg/12.swf" author="hoho53">
	<figitdropper x="302.5" y="6" lock="no" other=""/>
<figitdropper x="434.5" y="6" lock="no" other=""/>
<figitdropper x="179.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=l/9/9"/>
<figitbox x="291.5" y="556" lock="no" other="par=r/10/9"/>
<figitbox x="6.5" y="556" lock="no" other="par=l/9/9"/>
<pvcpipe x="499.5" y="399.5" lock="no" other="rotation=0.669"/>
<pvcpipe x="168.5" y="398.5" lock="no" other="rotation=-0.778"/>
<figitcombiner x="405.5" y="280.5" lock="no" other=""/>
<figitcombiner x="159.5" y="274.5" lock="no" other=""/>
<figitpainter x="296.5" y="281.5" lock="no" other="color=10"/>
<figitpainter x="424.5" y="216.5" lock="no" other="color=9"/>
<figitpainter x="181.5" y="210.5" lock="no" other="color=9"/></room>
		<room roomID="35676" status="new" type="open" setting="main" title="Concrete Pain" fg="blank" bg="bg/1.swf" author="Lillypod1234">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitbox x="475.5" y="556" lock="no" other="par=s/0/10"/>
<rubberblock x="52" y="236.75" lock="no" other="rotation=0.324 mat=rubber"/>
<rubberblock x="463.5" y="510.75" lock="no" other="rotation=1.591 mat=conc"/>
<rubberblock x="479.5" y="421.75" lock="no" other="rotation=1.65 mat=conc"/>
<fixedblock x="188.5" y="246.5" lock="no" other="rotation=0"/>
<fixedblock x="217.5" y="263.5" lock="no" other="rotation=0"/>
<fixedblock x="565.5" y="543.5" lock="no" other="rotation=0"/>
<fixedblock x="585" y="517.5" lock="no" other="rotation=0"/>
<pvcpipe x="122.5" y="203.5" lock="no" other="rotation=0"/>
<pvcpipe x="285.5" y="248.5" lock="no" other="rotation=0.49"/>
<pvcpipe x="470.5" y="337.5" lock="no" other="rotation=0.392"/>
<pvcpipe x="375.5" y="296.5" lock="no" other="rotation=0.482"/>
<pvcpipe x="388.5" y="127.5" lock="no" other="rotation=0"/>
<pvcpipe x="436.5" y="218.5" lock="no" other="rotation=0"/>
<figitdivider x="6" y="81.5" lock="no" other=""/></room>
		<room roomID="35144" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="kodeof">
	<figitdropper x="495.5" y="6" lock="no" other=""/>
<figitdropper x="430.5" y="6" lock="no" other=""/>
<figitbox x="331.5" y="556" lock="no" other="par=s/5/1"/>
<figitbox x="363.5" y="313.5" lock="no" other="par=l/0/1"/>
<rubberblock x="316.5" y="517" lock="no" other="rotation=-1.457 mat=rubber"/>
<rubberblock x="146.5" y="97.75" lock="no" other="rotation=-1.567 mat=rubber"/>
<rubberblock x="165.5" y="40.75" lock="no" other="rotation=-0.526 mat=rubber"/>
<rubberblock x="517.5" y="246.75" lock="no" other="rotation=-0.767 mat=rubber"/>
<fixedblock x="89.5" y="374.5" lock="no" other="rotation=0"/>
<fixedblock x="575.5" y="168.5" lock="no" other="rotation=-0.388"/>
<fixedblock x="91.5" y="345.5" lock="no" other="rotation=0"/>
<fixedblock x="582.5" y="137.5" lock="no" other="rotation=-0.238"/>
<fixedblock x="585" y="427.5" lock="no" other="rotation=-0.335"/>
<fixedblock x="88.5" y="320.5" lock="no" other="rotation=0"/>
<fixedblock x="480.5" y="427.5" lock="no" other="rotation=0.31"/>
<fixedblock x="227.5" y="310.5" lock="no" other="rotation=0.305"/>
<fixedblock x="457.5" y="301.5" lock="no" other="rotation=-0.452"/>
<fixedblock x="481.5" y="285.5" lock="no" other="rotation=-0.649"/>
<fixedblock x="348.5" y="319.5" lock="no" other="rotation=0.165"/>
<fixedblock x="317.5" y="318.5" lock="no" other="rotation=0.11"/>
<fixedblock x="196.5" y="305.5" lock="no" other="rotation=0.162"/>
<figitcombiner x="191.5" y="199.5" lock="no" other=""/>
<figitdivider x="97.5" y="252.5" lock="no" other=""/>
<figitpainter x="509.5" y="421.5" lock="no" other="color=5"/>
<spring x="255.5" y="302.5" lock="no" other="dir=right"/>
<elbowpipe x="153.5" y="199" lock="no" other="rotation=-1.71"/>
<conveyorbelt x="385.5" y="177.5" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="280.5" y="201.5" lock="no" other="cv=lt_fast"/>
<conveyorbelt x="107.5" y="380.5" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="297.5" y="382.5" lock="no" other="cv=rt_fast"/>
<conveyorbelt x="406" y="522.5" lock="no" other="cv=lt_med"/></room>
		<room roomID="35002" status="new" type="open" setting="moon" title="E4E" fg="blank" bg="bg/2.swf" author="redflower">
	<figitdropper x="237.5" y="6" lock="no" other=""/>
<figitbox x="235" y="94.5" lock="no" other="par=r/0/5"/></room>
		<room roomID="34871" status="new" type="open" setting="wind" title="daquan" fg="blank" bg="bg/2.swf" author="dan801">
	<figitdropper x="340.5" y="6" lock="no" other=""/>
<figitbox x="337.5" y="149.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="34598" status="new" type="open" setting="main" title="FIDGiT Land I" fg="blank" bg="bg/1.swf" author="Eeko125">
	<figitdropper x="252.5" y="6" lock="no" other=""/>
<figitbox x="253.5" y="556" lock="no" other="par=r/0/10"/>
<figitbox x="10.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="226.5" y="286.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="350.5" y="288.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="232.5" y="541.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="350.5" y="540.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="358.5" y="411.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="230.5" y="410.75" lock="no" other="rotation=0 mat=conc"/>
<fixedblock x="226.5" y="318.5" lock="no" other="rotation=0"/>
<fixedblock x="348.5" y="320.5" lock="no" other="rotation=0"/>
<fixedblock x="227.5" y="253.5" lock="no" other="rotation=0"/>
<fixedblock x="348.5" y="258.5" lock="no" other="rotation=0"/>
<fixedblock x="352.5" y="514.5" lock="no" other="rotation=0"/>
<fixedblock x="231.5" y="512.5" lock="no" other="rotation=0"/>
<fixedblock x="230.5" y="382.5" lock="no" other="rotation=0"/>
<fixedblock x="233.5" y="442.5" lock="no" other="rotation=0"/>
<fixedblock x="354.5" y="385.5" lock="no" other="rotation=0"/>
<fixedblock x="355.5" y="445.5" lock="no" other="rotation=0"/>
<fixedblock x="248.5" y="349.5" lock="no" other="rotation=0"/>
<fixedblock x="331.5" y="354.5" lock="no" other="rotation=0"/>
<fixedblock x="253.5" y="478.5" lock="no" other="rotation=0"/>
<fixedblock x="335.5" y="479.5" lock="no" other="rotation=0"/>
<fixedblock x="287.5" y="92.5" lock="no" other="rotation=0"/></room>
		<room roomID="34495" status="new" type="open" setting="main" title="we" fg="blank" bg="bg/2.swf" author="tsmon6">
	<figitdropper x="509.5" y="6" lock="no" other=""/>
<figitdropper x="309.5" y="6" lock="no" other=""/>
<figitdropper x="6" y="6" lock="no" other=""/>
<figitbox x="483.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="321.5" y="553" lock="no" other="par=r/0/1"/>
<figitbox x="6.5" y="556" lock="no" other="par=r/0/1"/></room>
		<room roomID="34059" status="new" type="open" setting="main" title="ATTACK!!!!!!!!!" fg="blank" bg="bg/5.swf" author="gamer5">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="6.5" y="6" lock="no" other=""/>
<figitdropper x="271.5" y="6" lock="no" other=""/>
<rubberblock x="560" y="480.75" lock="no" other="rotation=0 mat=conc"/>
<rubberblock x="503.5" y="487.75" lock="no" other="rotation=-1.569 mat=rubber"/>
<rubberblock x="46.5" y="492.75" lock="no" other="rotation=0 mat=wood"/>
<rubberblock x="45.5" y="470.75" lock="no" other="rotation=1.576 mat=conc"/>
<rubberblock x="46" y="420.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="544.5" y="452.5" lock="no" other="rotation=0"/>
<fixedblock x="565.5" y="426.5" lock="no" other="rotation=0"/>
<fixedblock x="526.5" y="425.5" lock="no" other="rotation=0"/>
<fixedblock x="103.5" y="492.5" lock="no" other="rotation=0"/>
<fixedblock x="103.5" y="521.5" lock="no" other="rotation=0"/>
<fixedblock x="104.5" y="463.5" lock="no" other="rotation=0"/>
<pvcpipe x="302.5" y="518.5" lock="no" other="rotation=1.577"/>
<pvcpipe x="303.5" y="425.5" lock="no" other="rotation=-1.583"/>
<spring x="280.5" y="563.5" lock="no" other="dir=up"/>
<conveyorbelt x="326.5" y="568" lock="no" other="cv=lt_med"/>
<conveyorbelt x="87.5" y="568" lock="no" other="cv=rt_med"/>
<fidgitcannon x="6" y="273.5" lock="no" other="chute=1.061"/>
<fidgitcannon x="500" y="276.5" lock="no" other="chute=-177.858"/></room>
		<room roomID="33805" status="new" type="open" setting="main" title="happy fijits" fg="blank" bg="bg/5.swf" author="jashanjot">
	<figitdropper x="66.5" y="6" lock="no" other=""/>
<figitdropper x="431.5" y="6" lock="no" other=""/>
<figitbox x="227.5" y="554" lock="no" other="par=l/8/10"/>
<rubberblock x="500.5" y="387.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="82.5" y="394.75" lock="no" other="rotation=0 mat=rubber"/>
<spring x="165.5" y="237.5" lock="no" other="dir=up"/>
<spring x="363.5" y="241.5" lock="no" other="dir=up"/></room>
		<room roomID="33749" status="new" type="open" setting="main" title="i ROCK" fg="blank" bg="bg/3.swf" author="RON214">
	<figitdropper x="182.2" y="6" lock="no" other=""/>
<figitbox x="290.85" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="418.6" y="259.1" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="181.3" y="273.45" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="307.95" y="386.7" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="513.05" y="412.05" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="142.25" y="456.35" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="33560" status="new" type="open" setting="main" title="test" fg="blank" bg="bg/5.swf" author="dgfgse">
	<figitdropper x="329.5" y="6" lock="no" other=""/>
<figitbox x="295.5" y="556" lock="no" other="par=s/2/56"/>
<rubberblock x="381.5" y="438.75" lock="no" other="rotation=1.503 mat=rubber"/>
<fixedblock x="293.5" y="484.5" lock="no" other="rotation=0"/>
<fixedblock x="271.5" y="455.5" lock="no" other="rotation=0"/>
<figitdivider x="323.5" y="75.5" lock="no" other=""/>
<figitpainter x="300.5" y="488.5" lock="no" other="color=2"/>
<elbowpipe x="334.5" y="255" lock="no" other="rotation=1.633"/>
<elbowpipe x="212.5" y="288" lock="no" other="rotation=-1.5"/>
<elbowpipe x="207.5" y="392" lock="no" other="rotation=-3.128"/></room>
		<room roomID="33312" status="new" type="open" setting="wind" title="the maze" fg="blank" bg="bg/13.swf" author="shark55r">
	<figitdropper x="106.5" y="6" lock="no" other=""/>
<figitdropper x="171.5" y="6" lock="no" other=""/>
<figitdropper x="223.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=l/5/50"/>
<figitbox x="124.5" y="407" lock="no" other="par=r/0/50"/>
<rubberblock x="136.5" y="268.75" lock="no" other="rotation=0 mat=wood"/>
<rubberblock x="311.5" y="384.75" lock="no" other="rotation=-0.891 mat=rubber"/>
<rubberblock x="211.5" y="266.75" lock="no" other="rotation=0 mat=wood"/>
<rubberblock x="305.5" y="188.75" lock="no" other="rotation=0 mat=conc"/>
<fixedblock x="172.5" y="90.5" lock="no" other="rotation=0"/>
<fixedblock x="576.5" y="198.5" lock="no" other="rotation=0"/>
<fixedblock x="331.5" y="206.5" lock="no" other="rotation=0"/>
<fixedblock x="257.5" y="262.5" lock="no" other="rotation=0"/>
<fixedblock x="80.5" y="127.5" lock="no" other="rotation=0"/>
<fixedblock x="30.5" y="128.5" lock="no" other="rotation=0"/>
<fixedblock x="92.5" y="172.5" lock="no" other="rotation=0"/>
<fixedblock x="21.5" y="173.5" lock="no" other="rotation=0"/>
<fixedblock x="42.5" y="187.5" lock="no" other="rotation=0"/>
<fixedblock x="70.5" y="188.5" lock="no" other="rotation=0"/>
<pvcpipe x="56" y="79.5" lock="no" other="rotation=0"/>
<pvcpipe x="56" y="229.5" lock="no" other="rotation=0"/>
<pvcpipe x="134" y="149.5" lock="no" other="rotation=1.547"/>
<pvcpipe x="56" y="377.5" lock="no" other="rotation=0"/>
<pvcpipe x="56.5" y="564" lock="no" other="rotation=0"/>
<pvcpipe x="294.5" y="298.5" lock="no" other="rotation=1.563"/>
<pvcpipe x="227.5" y="374.5" lock="no" other="rotation=0"/>
<pvcpipe x="96.5" y="375.5" lock="no" other="rotation=0"/>
<pvcpipe x="441.5" y="198.5" lock="no" other="rotation=-1.559"/>
<pvcpipe x="203.5" y="119.5" lock="no" other="rotation=-1.586"/>
<figitcombiner x="322.5" y="246.5" lock="no" other=""/>
<figitpainter x="344" y="309.5" lock="no" other="color=5"/>
<figitpainter x="230.5" y="72.5" lock="no" other="color=5"/>
<pendulum x="431.5" y="6.5" lock="no" other="swing_x=80 swing_y=0"/>
<spring x="440.5" y="564" lock="no" other="dir=right"/>
<spring x="480.5" y="563.5" lock="no" other="dir=left"/>
<spring x="401.5" y="563.5" lock="no" other="dir=right"/>
<spring x="363.5" y="563.5" lock="no" other="dir=right"/>
<spring x="325.5" y="563.5" lock="no" other="dir=right"/></room>
		<room roomID="33294" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/2.swf" author="rpdanes">
	<figitdropper x="264.5" y="6" lock="no" other=""/>
<figitdropper x="327.5" y="6" lock="no" other=""/>
<figitdropper x="203.5" y="6" lock="no" other=""/>
<figitbox x="292.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="221" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="346.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="539" y="550.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="183" y="548" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="462" y="549" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="46" y="548.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="105.5" y="549.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="560" y="554.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="33158" status="new" type="open" setting="main" title="My room" fg="blank" bg="bg/1.swf" author="monkey24j">
	<figitdropper x="280.5" y="6" lock="no" other=""/>
<figitbox x="270.2" y="556" lock="no" other="par=r/0/100"/></room>
		<room roomID="33150" status="new" type="open" setting="main" title="ROBOT" fg="blank" bg="bg/2.swf" author="robotcesar">
	<figitdropper x="407.5" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="438.5" y="485.5" lock="no" other="par=s/0/186"/>
<figitbox x="518.5" y="484.5" lock="no" other="par=r/0/1"/>
<rubberblock x="393.5" y="458.75" lock="no" other="rotation=0.887 mat=conc"/>
<fixedblock x="407.5" y="558.5" lock="no" other="rotation=0"/>
<figitdivider x="387.5" y="180.5" lock="no" other=""/></room>
		<room roomID="33146" status="new" type="open" setting="wind" title="easy" fg="blank" bg="bg/2.swf" author="cheleah">
	<figitdropper x="121.5" y="6" lock="no" other=""/>
<figitdropper x="323.5" y="6" lock="no" other=""/>
<figitdropper x="480.5" y="6" lock="no" other=""/>
<figitbox x="123.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="275.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="472.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="262.5" y="86.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="443.5" y="85.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="442.5" y="113.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="421.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="427.5" y="548.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="423.5" y="520.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="235.5" y="574" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="241.5" y="540.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="237.5" y="510.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="91.5" y="575.75" lock="no" other="rotation=0 mat=rubber"/>
<pvcpipe x="537.5" y="155.5" lock="no" other="rotation=-1.601"/>
<pvcpipe x="357.5" y="127.5" lock="no" other="rotation=-1.562"/>
<pvcpipe x="159.5" y="128.5" lock="no" other="rotation=-1.615"/></room>
		<room roomID="32885" status="new" type="open" setting="moon" title="$omia's Place!" fg="blank" bg="bg/1.swf" author="simbarooni">
	<figitdropper x="263.5" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitdropper x="39.5" y="6" lock="no" other=""/>
<rubberblock x="560" y="335.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="333.5" y="408.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="78.5" y="521.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="196.5" y="353.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="549.5" y="574.75" lock="no" other="rotation=0 mat=rubber"/></room>
		<room roomID="32771" status="new" type="open" setting="main" title="Pipe Problem" fg="blank" bg="bg/1.swf" author="tigerfish1">
	<figitdropper x="440.5" y="6" lock="no" other=""/>
<figitbox x="434.5" y="555.5" lock="no" other="par=l/3/50"/>
<figitbox x="219.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="14.5" y="556" lock="no" other="par=r/0/1"/>
<fixedblock x="506.5" y="75.5" lock="no" other="rotation=0"/>
<fixedblock x="436.5" y="79.5" lock="no" other="rotation=0"/>
<fixedblock x="512.5" y="52.5" lock="no" other="rotation=0"/>
<fixedblock x="511.5" y="26.5" lock="no" other="rotation=0"/>
<fixedblock x="432.5" y="57.5" lock="no" other="rotation=0"/>
<fixedblock x="428.5" y="27.5" lock="no" other="rotation=0"/>
<pvcpipe x="240.5" y="409.5" lock="no" other="rotation=0.53"/>
<pvcpipe x="148.5" y="258.5" lock="no" other="rotation=-0.714"/>
<pvcpipe x="222.5" y="192.5" lock="no" other="rotation=-0.688"/>
<pvcpipe x="329.5" y="459.5" lock="no" other="rotation=0.502"/>
<pvcpipe x="158.5" y="353.5" lock="no" other="rotation=0.541"/>
<pvcpipe x="298.5" y="125.5" lock="no" other="rotation=-0.697"/>
<pvcpipe x="477.5" y="407.5" lock="no" other="rotation=-0.403"/>
<figitcombiner x="424.5" y="127.5" lock="no" other=""/>
<figitcombiner x="336" y="127" lock="no" other=""/>
<figitcombiner x="498" y="126.5" lock="no" other=""/>
<figitpainter x="442" y="73.5" lock="no" other="color=3"/>
<spring x="402.5" y="533.5" lock="no" other="dir=left"/>
<spring x="512.5" y="526.5" lock="no" other="dir=left"/>
<spring x="553.5" y="501.5" lock="no" other="dir=left"/>
<spring x="362.5" y="507.5" lock="no" other="dir=right"/></room>
		<room roomID="31547" status="new" type="open" setting="main" title="fuck bitch!! " fg="blank" bg="bg/6.swf" author="goldenchild512">
	<figitdropper x="281.35" y="6" lock="no" other=""/>
<figitbox x="287.85" y="556" lock="no" other="par=l/0/80"/>
<rubberblock x="78.2" y="267.85" lock="no" other="rotation=0.285 mat=rubber"/>
<figitcombiner x="266.3" y="285.1" lock="no" other=""/></room>
		<room roomID="31178" status="new" type="open" setting="wind" title="halo4" fg="blank" bg="bg/6.swf" author="HALO4">
	<figitdropper x="489.5" y="6" lock="no" other=""/>
<figitdropper x="320.5" y="6" lock="no" other=""/>
<figitdropper x="139.5" y="6" lock="no" other=""/>
<figitbox x="522" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="429.25" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="328.2" y="556" lock="no" other="par=r/0/1"/></room>
		<room roomID="29980" status="new" type="open" setting="main" title="pop" fg="blank" bg="bg/6.swf" author="ISIAHSTAKER">
	<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="6" y="556" lock="no" other="par=r/0/700"/>
<rubberblock x="560" y="307.75" lock="no" other="rotation=-0.336 mat=rubber"/></room>
		<room roomID="28749" status="new" type="open" setting="main" title="!@#$%^&*()" fg="blank" bg="bg/14.swf" author="lolo678">
	<figitdropper x="266.1" y="6" lock="no" other=""/>
<figitbox x="280" y="490.55" lock="no" other="par=r/0/10"/>
<rubberblock x="375.3" y="485.25" lock="no" other="rotation=-1.557 mat=conc"/>
<rubberblock x="263.5" y="482.2" lock="no" other="rotation=1.589 mat=conc"/>
<rubberblock x="242.25" y="83.75" lock="no" other="rotation=0.787 mat=conc"/>
<rubberblock x="355.05" y="85.75" lock="no" other="rotation=-0.697 mat=conc"/></room>
		<room roomID="28607" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/13.swf" author="tuck12">
	<figitdropper x="311.5" y="6" lock="no" other=""/>
<figitbox x="384.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="301.5" y="555" lock="no" other="par=r/0/1"/>
<figitbox x="472.5" y="544.5" lock="no" other="par=r/0/1"/>
<rubberblock x="344.5" y="294.75" lock="no" other="rotation=0.397 mat=conc"/>
<rubberblock x="560" y="377.75" lock="no" other="rotation=-1.049 mat=conc"/>
<pvcpipe x="349.5" y="135.5" lock="no" other="rotation=1.473"/>
<pvcpipe x="444.5" y="292.5" lock="no" other="rotation=0.235"/></room>
		<room roomID="28593" status="new" type="open" setting="moon" title="mi room bby" fg="blank" bg="bg/5.swf" author="dedebby">
	</room>
		<room roomID="28543" status="new" type="open" setting="main" title="multi room" fg="blank" bg="bg/4.swf" author="coolforever">
	<figitdropper x="371.5" y="6" lock="no" other=""/>
<figitdropper x="140.5" y="6" lock="no" other=""/>
<figitbox x="458.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="44.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="139.5" y="552" lock="no" other="rotation=-1.545 mat=conc"/>
<rubberblock x="439.5" y="553" lock="no" other="rotation=1.556 mat=conc"/>
<rubberblock x="29" y="552" lock="no" other="rotation=1.569 mat=conc"/>
<rubberblock x="554" y="552" lock="no" other="rotation=1.572 mat=conc"/></room>
		<room roomID="28524" status="new" type="open" setting="main" title="SUPER  SLIDE" fg="blank" bg="bg/3.swf" author="maryd">
	<figitdropper x="163.5" y="6" lock="no" other=""/>
<figitbox x="416.5" y="404" lock="no" other="par=r/0/1"/>
<rubberblock x="131.5" y="261.75" lock="no" other="rotation=0.549 mat=rubber"/>
<rubberblock x="52" y="210.75" lock="no" other="rotation=0.625 mat=rubber"/>
<rubberblock x="207.5" y="309.75" lock="no" other="rotation=0.499 mat=rubber"/>
<rubberblock x="289.5" y="351.75" lock="no" other="rotation=0.425 mat=rubber"/>
<rubberblock x="374.5" y="392.75" lock="no" other="rotation=0.451 mat=rubber"/>
<rubberblock x="219.5" y="116.75" lock="no" other="rotation=-0.463 mat=rubber"/>
<rubberblock x="150.5" y="156.75" lock="no" other="rotation=-0.646 mat=rubber"/>
<rubberblock x="526.5" y="382.75" lock="no" other="rotation=-0.474 mat=rubber"/>
<fixedblock x="584.5" y="351.5" lock="no" other="rotation=-0.611"/>
<fixedblock x="30" y="181.45" lock="no" other="rotation=0.643"/></room>
		<room roomID="28118" status="new" type="open" setting="moon" title="HIIIIIIIIIIIIII" fg="blank" bg="bg/1.swf" author="AMBRIZV1">
	<figitdropper x="508.5" y="6" lock="no" other=""/>
<figitdropper x="402.5" y="6" lock="no" other=""/>
<figitdropper x="302.5" y="6" lock="no" other=""/>
<figitbox x="309.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="413.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="517.5" y="549.5" lock="no" other="par=r/0/1"/></room>
		<room roomID="27990" status="new" type="open" setting="main" title="FREIN" fg="blank" bg="bg/2.swf" author="dancar1222">
	<figitdropper x="287.5" y="6" lock="no" other=""/>
<figitdropper x="494.5" y="6" lock="no" other=""/>
<figitbox x="489.5" y="168.5" lock="no" other="par=r/0/1"/>
<figitbox x="288.5" y="172.5" lock="no" other="par=r/0/1"/>
<rubberblock x="284.5" y="113.75" lock="no" other="rotation=0.906 mat=rubber"/>
<rubberblock x="393.5" y="161.75" lock="no" other="rotation=-0.642 mat=rubber"/>
<fixedblock x="421.5" y="87.5" lock="no" other="rotation=0"/></room>
		<room roomID="27893" status="new" type="open" setting="main" title="rainbow" fg="blank" bg="bg/1.swf" author="bathroom">
	<figitdropper x="13.5" y="6" lock="no" other=""/>
<figitdropper x="532.5" y="6" lock="no" other=""/>
<figitbox x="522" y="553.5" lock="no" other="par=r/6/20"/>
<figitbox x="14.5" y="556" lock="no" other="par=r/6/20"/>
<figitpainter x="540" y="86.5" lock="no" other="color=2"/>
<figitpainter x="539" y="173.5" lock="no" other="color=3"/>
<figitpainter x="536" y="251.5" lock="no" other="color=4"/>
<figitpainter x="539" y="331.5" lock="no" other="color=5"/>
<figitpainter x="535" y="422.5" lock="no" other="color=6"/>
<figitpainter x="16.5" y="84.5" lock="no" other="color=2"/>
<figitpainter x="21" y="176.5" lock="no" other="color=3"/>
<figitpainter x="25.5" y="266.5" lock="no" other="color=4"/>
<figitpainter x="25.5" y="353.5" lock="no" other="color=5"/>
<figitpainter x="24.5" y="445.5" lock="no" other="color=6"/></room>
		<room roomID="27722" status="" type="open" setting="" title="" fg="" bg="" author="bsmall01">
	</room>
		<room roomID="27537" status="new" type="open" setting="main" title="dwyane wade" fg="blank" bg="bg/2.swf" author="abnike123">
	<figitdropper x="111.5" y="6" lock="no" other=""/>
<figitbox x="453.5" y="556" lock="no" other="par=r/0/1"/>
<rubberblock x="119.5" y="270.75" lock="no" other="rotation=0.539 mat=rubber"/>
<rubberblock x="560" y="386.75" lock="no" other="rotation=-0.764 mat=rubber"/>
<rubberblock x="50.5" y="475.75" lock="no" other="rotation=0.638 mat=rubber"/>
<fixedblock x="180.5" y="386.5" lock="no" other="rotation=0"/>
<fixedblock x="557.5" y="478.5" lock="no" other="rotation=0"/>
<fixedblock x="559.5" y="509.5" lock="no" other="rotation=0"/>
<pvcpipe x="244.5" y="342.5" lock="no" other="rotation=0"/></room>
		<room roomID="26263" status="new" type="open" setting="main" title="jail Room" fg="blank" bg="bg/8.swf" author="jesseb">
	<figitdropper x="6" y="6" lock="no" other=""/>
<figitbox x="52.5" y="555.5" lock="no" other="par=r/0/1"/>
<figitbox x="443.5" y="556" lock="no" other="par=r/0/1"/>
<figitbox x="260.5" y="432.5" lock="no" other="par=r/0/1"/>
<rubberblock x="46" y="316.75" lock="no" other="rotation=0.402 mat=rubber"/>
<rubberblock x="115.5" y="350.75" lock="no" other="rotation=0.374 mat=rubber"/>
<rubberblock x="185.5" y="383.75" lock="no" other="rotation=0.49 mat=rubber"/></room>
		<room roomID="25852" status="new" type="open" setting="main" title="My New Room" fg="blank" bg="bg/1.swf" author="49661">
	<figitdropper x="297.5" y="6" lock="no" other=""/>
<figitbox x="444.5" y="494.5" lock="no" other="par=l/0/1"/>
<figitbox x="36.5" y="500.5" lock="no" other="par=l/0/1"/>
<rubberblock x="342.5" y="183.75" lock="no" other="rotation=-0.455 mat=conc"/>
<figitcombiner x="17.5" y="336.5" lock="no" other=""/></room>
		<room roomID="25354" status="new" type="open" setting="wind" title="howeasyisthis" fg="blank" bg="bg/1.swf" author="Smithn8">
	<figitdropper x="6.5" y="6" lock="no" other=""/>
<figitbox x="52.5" y="401.5" lock="no" other="par=r/0/1"/>
<pendulum x="6" y="71.5" lock="no" other="swing_x=573 swing_y=2"/>
<pendulum x="6.5" y="88.5" lock="no" other="swing_x=572 swing_y=-34"/>
<pendulum x="6.5" y="51.5" lock="no" other="swing_x=572 swing_y=107"/>
<pendulum x="6.5" y="131.5" lock="no" other="swing_x=202 swing_y=-125"/>
<pendulum x="19.5" y="387.5" lock="no" other="swing_x=131 swing_y=-1"/></room>
		<room roomID="25283" status="new" type="open" setting="moon" title="men i hate you" fg="blank" bg="bg/11.swf" author="wawahaha">
	<figitdropper x="328.5" y="6" lock="no" other=""/>
<pvcpipe x="352.5" y="325.5" lock="no" other="rotation=-1.576"/>
<pvcpipe x="443.5" y="284.5" lock="no" other="rotation=0.41"/>
<pvcpipe x="269.5" y="278.5" lock="no" other="rotation=-0.497"/>
<pvcpipe x="303.5" y="430.5" lock="no" other="rotation=-0.751"/>
<pvcpipe x="408.5" y="416.5" lock="no" other="rotation=0.419"/>
<figitdivider x="314.5" y="185.5" lock="no" other=""/>
<pendulum x="489.5" y="301.5" lock="no" other="swing_x=89 swing_y=-295"/>
<pendulum x="190.5" y="280.5" lock="no" other="swing_x=-184 swing_y=-274"/>
<pendulum x="265.5" y="123.5" lock="no" other="swing_x=313 swing_y=-117"/>
<pendulum x="578.55" y="572" lock="no" other="swing_x=-572 swing_y=-566"/>
<pendulum x="6.5" y="574" lock="no" other="swing_x=572 swing_y=-568"/></room>
		<room roomID="25266" status="new" type="open" setting="main" title="for velendtim" fg="blank" bg="bg/13.swf" author="calvin33">
	<figitdropper x="255.5" y="6" lock="no" other=""/>
<figitbox x="299.5" y="555.5" lock="no" other="par=l/0/1"/>
<rubberblock x="308.5" y="227.75" lock="no" other="rotation=-0.917 mat=rubber"/>
<rubberblock x="263.5" y="293" lock="no" other="rotation=2.134 mat=rubber"/>
<rubberblock x="149.5" y="414.75" lock="no" other="rotation=1.115 mat=rubber"/>
<rubberblock x="170.5" y="238.75" lock="no" other="rotation=-1.05 mat=conc"/>
<rubberblock x="136.5" y="294.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="137.5" y="330.75" lock="no" other="rotation=0 mat=rubber"/>
<fixedblock x="227.5" y="192.5" lock="no" other="rotation=-0.961"/>
<fixedblock x="181.5" y="432.5" lock="no" other="rotation=-2.598"/>
<pvcpipe x="284.5" y="130.5" lock="no" other="rotation=1.626"/>
<pvcpipe x="249" y="435.5" lock="no" other="rotation=0.6"/>
<figitcombiner x="277.5" y="481.5" lock="no" other=""/>
<figitdivider x="152.5" y="321.5" lock="no" other=""/></room>
		<room roomID="25265" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/5.swf" author="calvin33">
	<figitdropper x="103.5" y="6" lock="no" other=""/>
<figitbox x="363.5" y="508.5" lock="no" other="par=s/0/10"/>
<rubberblock x="114.5" y="212.75" lock="no" other="rotation=0.777 mat=rubber"/>
<rubberblock x="399.5" y="267.75" lock="no" other="rotation=0.854 mat=rubber"/>
<rubberblock x="293.5" y="335.75" lock="no" other="rotation=0.92 mat=rubber"/>
<rubberblock x="173.5" y="250.75" lock="no" other="rotation=0.289 mat=rubber"/>
<rubberblock x="201.5" y="156.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="280.5" y="175.75" lock="no" other="rotation=0.417 mat=rubber"/>
<rubberblock x="345.5" y="215.75" lock="no" other="rotation=0.739 mat=rubber"/>
<rubberblock x="239.5" y="285.75" lock="no" other="rotation=0.781 mat=rubber"/>
<fixedblock x="509.5" y="554.5" lock="no" other="rotation=0"/>
<fixedblock x="509.5" y="524.5" lock="no" other="rotation=0"/>
<fixedblock x="288.5" y="550.5" lock="no" other="rotation=0"/>
<fixedblock x="288.5" y="519.5" lock="no" other="rotation=0"/>
<fixedblock x="463.5" y="363.5" lock="no" other="rotation=0"/>
<fixedblock x="465.5" y="395.5" lock="no" other="rotation=0"/>
<fixedblock x="466.5" y="424.5" lock="no" other="rotation=0"/>
<fixedblock x="466.5" y="445.5" lock="no" other="rotation=0"/>
<fixedblock x="331.5" y="392.5" lock="no" other="rotation=0"/>
<fixedblock x="353.5" y="434.5" lock="no" other="rotation=0"/>
<fixedblock x="468.5" y="283.5" lock="no" other="rotation=0"/>
<pvcpipe x="475" y="478.5" lock="no" other="rotation=0"/>
<pvcpipe x="324.5" y="473.5" lock="no" other="rotation=0"/>
<pvcpipe x="135.5" y="125.5" lock="no" other="rotation=1.626"/>
<figitdivider x="367.5" y="388.5" lock="no" other=""/></room>
		<room roomID="25219" status="new" type="open" setting="moon" title="My New Room" fg="blank" bg="bg/5.swf" author="brian060602">
	<figitdropper x="103.5" y="6" lock="no" other=""/>
<figitbox x="363.5" y="508.5" lock="no" other="par=s/0/10"/>
<rubberblock x="114.5" y="212.75" lock="no" other="rotation=0.777 mat=rubber"/>
<rubberblock x="399.5" y="267.75" lock="no" other="rotation=0.854 mat=rubber"/>
<rubberblock x="293.5" y="335.75" lock="no" other="rotation=0.92 mat=rubber"/>
<rubberblock x="173.5" y="250.75" lock="no" other="rotation=0.289 mat=rubber"/>
<rubberblock x="201.5" y="156.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="280.5" y="175.75" lock="no" other="rotation=0.417 mat=rubber"/>
<rubberblock x="345.5" y="215.75" lock="no" other="rotation=0.739 mat=rubber"/>
<rubberblock x="239.5" y="285.75" lock="no" other="rotation=0.781 mat=rubber"/>
<fixedblock x="509.5" y="554.5" lock="no" other="rotation=0"/>
<fixedblock x="509.5" y="524.5" lock="no" other="rotation=0"/>
<fixedblock x="288.5" y="550.5" lock="no" other="rotation=0"/>
<fixedblock x="288.5" y="519.5" lock="no" other="rotation=0"/>
<fixedblock x="463.5" y="363.5" lock="no" other="rotation=0"/>
<fixedblock x="465.5" y="395.5" lock="no" other="rotation=0"/>
<fixedblock x="466.5" y="424.5" lock="no" other="rotation=0"/>
<fixedblock x="466.5" y="445.5" lock="no" other="rotation=0"/>
<fixedblock x="331.5" y="392.5" lock="no" other="rotation=0"/>
<fixedblock x="353.5" y="434.5" lock="no" other="rotation=0"/>
<fixedblock x="468.5" y="283.5" lock="no" other="rotation=0"/>
<pvcpipe x="475" y="478.5" lock="no" other="rotation=0"/>
<pvcpipe x="324.5" y="473.5" lock="no" other="rotation=0"/>
<pvcpipe x="135.5" y="125.5" lock="no" other="rotation=1.626"/>
<figitdivider x="367.5" y="388.5" lock="no" other=""/></room>
		<room roomID="25213" status="new" type="open" setting="main" title="600" fg="blank" bg="bg/1.swf" author="3545056">
	<figitdropper x="255.5" y="6" lock="no" other=""/>
<figitbox x="241.5" y="554" lock="no" other="par=r/0/1"/>
<rubberblock x="348.5" y="158.75" lock="no" other="rotation=0 mat=rubber"/>
<rubberblock x="229.5" y="159.75" lock="no" other="rotation=0 mat=rubber"/></room>
	</friend>
	<basic>		<room roomID="1" status="new" type="challenge" setting="main" title="Easy Bounce"  desc="Use the rubber blocks to bounce the Fidgits to their goal!" fg="blank" bg="bg/1.swf" results="" Fcount="0">
	<dropper x="84.5" y="6" lock="yes" other="drop=5 time=1"/>
  <figitbox x="481" y="556" lock="yes" other="par=r/0/3"/>
  <rubberblock x="111.5" y="257.75" lock="no" other="rotation=0.271 mat=rubber"/>
  <rubberblock x="288.5" y="448.75" lock="no" other="rotation=0 mat=rubber"/>
  <rubberblock x="123.5" y="390.75" lock="no" other="rotation=0 mat=rubber"/>
  <fixedblock x="452.5" y="64.5" lock="no" other="rotation=0"/>
  <fixedblock x="553.5" y="151.5" lock="no" other="rotation=0"/></room>
		<room roomID="2" status="new" type="challenge" setting="main" title="Easy Painter"  desc="Time to paint your Fidgits!" fg="blank" bg="bg/1.swf" results="" Fcount="0">
	<dropper x="49.5" y="6" lock="yes" other="drop=4 time=1"/>
  <figitbox x="272" y="556" lock="yes" other="par=r/1/4"/>
  <rubberblock x="70.5" y="194.75" lock="no" other="rotation=0.835"/>
  <rubberblock x="210.5" y="281.75" lock="no" other="rotation=0"/>
  <fixedblock x="429.5" y="478.5" lock="no" other="rotation=-0.916"/>
  <fixedblock x="0" y="0" lock="no" other="rotation=-0.916"/>
  <fixedblock x="0" y="0" lock="no" other="rotation=-0.916"/>
  <fixedblock x="0" y="0" lock="no" other="rotation=-0.916"/>
  <figitpainter x="392.5" y="254.5" lock="yes" other="color=1"/></room>
		<room roomID="3" status="new" type="challenge" setting="main" title="Easy Combiner"  desc="What happens when you combine two Fidgits?" fg="blank" bg="bg/1.swf" results="" Fcount="0">
	<dropper x="43" y="6" lock="yes" other="drop=1 time=1"/>
  <dropper x="487.5" y="6" lock="yes" other="drop=1 time=1"/>
  <figitbox x="392" y="556" lock="yes" other="par=l/0/1"/>
  <rubberblock x="531" y="218.75" lock="no" other="rotation=-0.429"/>
  <rubberblock x="65.5" y="209.75" lock="no" other="rotation=0.492"/>
  <rubberblock x="301.5" y="498.75" lock="no" other="rotation=0.205"/>
  <rubberblock x="0" y="0" lock="no" other="rotation=0.205"/>
  <rubberblock x="0" y="0" lock="no" other="rotation=0.205"/>
  <figitcombiner x="251.5" y="304.5" lock="yes" other=""/></room>
		<room roomID="4" status="new" type="challenge" setting="main" title="Easy Pendulum"  desc="Swing the Fidgits with the pendulum!" fg="blank" bg="bg/1.swf" results="" Fcount="0">
	<dropper x="256.5" y="6" lock="yes" other="drop=1 time=1"/>
  <figitbox x="522" y="556" lock="yes" other="par=r/0/1"/>
  <fixedblock x="293.5" y="291.5" lock="yes" other="rotation=0"/>
  <pendulum x="220.5" y="107.5" lock="no" other="swing_x=-126 swing_y=-26"/></room>
		<room roomID="5" status="new" type="challenge" setting="main" title="Easy Divider"  desc="Can you make the Fidgits smaller?" fg="blank" bg="bg/1.swf" results="" Fcount="0">
	<dropper x="275.5" y="6" lock="yes" other="drop=4 time=1"/>
  <figitbox x="272" y="556" lock="yes" other="par=s/0/8"/>
  <rubberblock x="326.5" y="190.75" lock="no" other="rotation=-0.432"/>
  <fixedblock x="130.5" y="208.5" lock="no" other="rotation=0"/>
  <pvcpipe x="205.5" y="343.5" lock="no" other="rotation=1.039"/>
  <figitdivider x="138.5" y="224.5" lock="yes" other=""/>
  <figitdivider x="394.5" y="227.5" lock="yes" other=""/></room>
	</basic>
	<challenge>		<room roomID="1" status="success" type="challenge" setting="" title="Lots of Blocks" desc="Get the Fidgits through the field of blocks!" fg="blank" bg="bg/6.swf" results="r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0,r/0/0," Fcount="0">
	<dropper x="98.5" y="6" lock="yes" other="drop=10 time=1"/>
<dropper x="271.5" y="6" lock="yes" other="drop=10 time=1"/>
<dropper x="435.5" y="6" lock="yes" other="drop=10 time=1"/>
<figitbox x="398.5" y="556" lock="yes" other="par=r/0/20"/>
<fixedblock x="122.5" y="151.5" lock="yes" other="rotation=0.659"/>
<fixedblock x="215.5" y="195.5" lock="yes" other="rotation=-0.698"/>
<fixedblock x="123.5" y="259.5" lock="yes" other="rotation=0.494"/>
<fixedblock x="302.5" y="217.5" lock="yes" other="rotation=-0.241"/>
<fixedblock x="205.5" y="299.5" lock="yes" other="rotation=-0.734"/>
<fixedblock x="382.5" y="334.5" lock="yes" other="rotation=-0.523"/>
<fixedblock x="248.5" y="457.5" lock="yes" other="rotation=-0.743"/>
<fixedblock x="73.5" y="455.5" lock="yes" other="rotation=0.485"/>
<fixedblock x="171.5" y="396.5" lock="yes" other="rotation=0"/>
<fixedblock x="350.5" y="134.5" lock="yes" other="rotation=-0.871"/>
<fixedblock x="538.5" y="345.5" lock="yes" other="rotation=0.562"/>
<fixedblock x="50.5" y="335.5" lock="yes" other="rotation=-0.579"/>
<fixedblock x="474.5" y="194.5" lock="yes" other="rotation=-0.665"/>
<fixedblock x="378.5" y="443.5" lock="yes" other="rotation=0"/>
<fixedblock x="293.5" y="364.5" lock="yes" other="rotation=0"/>
<fixedblock x="398.5" y="234.5" lock="yes" other="rotation=-0.352"/>
<fixedblock x="474.5" y="400.5" lock="yes" other="rotation=0"/>
<fixedblock x="521.5" y="271.5" lock="yes" other="rotation=0"/>
<rubberblock x="517.5" y="555.75" lock="no" other="rotation=-0.515 mat=conc"/>
<rubberblock x="212.5" y="432.75" lock="no" other="rotation=0.59 mat=conc"/>
<rubberblock x="280.5" y="478.75" lock="no" other="rotation=0.636 mat=conc"/%3Proxy-Connection: keep-alive
Cache-Control: max-age=0

0A<rubberblock x="350.5" y="526.75" lock="no" other="rotation=0.62 mat=wood"/>
<rubberblock x="-99" y="-99" lock="no" other=""/>
<rubberblock x="-99" y="-99" lock="no" other=""/>
<fixedblock x="122.5" y="437.5" lock="no" other="rotation=0"/>
<fixedblock x="566.5" y="501.5" lock="no" other="rotation=0"/>
<fixedblock x="570.5" y="464.5" lock="no" other="rotation=0"/></room>
		<room roomID="2" status="new" type="challenge" setting="main" title="Double Trouble" desc="Two Fidgits, two colors, two boxes!" fg="blank" bg="bg/5.swf" results="" Fcount="0">
	<dropper x="266.5" y="6" lock="yes" other="drop=2 time=1"/>
  <figitbox x="126" y="454" lock="yes" other="par=r/2/1"/>
  <figitbox x="405.5" y="454" lock="yes" other="par=r/3/1"/>
  <rubberblock x="243.5" y="390.75" lock="no" other="rotation=-0.412"/>
  <rubberblock x="349.5" y="393.75" lock="no" other="rotation=0.531"/>
  <pvcpipe x="444" y="543" lock="yes" other="rotation=1.572"/>
  <pvcpipe x="164.5" y="543" lock="yes" other="rotation=-1.566"/>
  <figitcombiner x="301.5" y="170.5" lock="no" other=""/>
  <figitcombiner x="199.5" y="170.5" lock="no" other=""/>
  <figitdivider x="261.5" y="74.5" lock="yes" other=""/>
  <figitpainter x="218.5" y="248.5" lock="no" other="color=1"/>
  <figitpainter x="322.5" y="248.5" lock="no" other="color=1"/></room>
		<room roomID="3" status="new" type="challenge" setting="main" title="A Little Paint" desc="Paint a lot of little fidgets!" fg="blank" bg="bg/11.swf" results="" Fcount="0">
	<dropper x="495.5" y="6" lock="yes" other="drop=5 time=1"/>
  <dropper x="39.5" y="6" lock="yes" other="drop=5 time=1"/>
  <figitbox x="164.5" y="556" lock="yes" other="par=s/10/8"/>
  <figitbox x="379.5" y="556" lock="yes" other="par=s/6/8"/>
  <rubberblock x="560" y="369.75" lock="yes" other="rotation=-0.67 mat=rubber"/>
  <rubberblock x="484.5" y="394.75" lock="no" other="rotation=0 mat=wood"/>
  <rubberblock x="275.5" y="386.75" lock="yes" other="rotation=-0.836 mat=wood"/>
  <rubberblock x="132.5" y="392.75" lock="no" other="rotation=0 mat=wood"/>
  <rubberblock x="53" y="365.75" lock="yes" other="rotation=0.617 mat=rubber"/>
  <rubberblock x="350.5" y="383.75" lock="no" other="rotation=0.744 mat=wood"/>
  <fixedblock x="311.5" y="343.5" lock="yes" other="rotation=0.724"/>
  <figitdivider x="31.5" y="98.5" lock="yes" other=""/>
  <figitdivider x="489.5" y="96.5" lock="yes" other=""/>
  <figitpainter x="386.5" y="399.5" lock="no" other="color=6"/>
  <figitpainter x="178.5" y="401.5" lock="no" other="color=10"/></room>
		<room roomID="4" status="new" type="challenge" setting="main" title="Spring Time" desc="See what the spring can do!" fg="blank" bg="bg/8.swf" results="" Fcount="0">
	<dropper x="470.5" y="6" lock="yes" other="drop=5 time=3"/>
  <figitbox x="269.5" y="284.5" lock="yes" other="par=r/0/3"/>
  <rubberblock x="494.5" y="524.75" lock="no" other="rotation=-0.569 mat=rubber"/>
  <rubberblock x="174.5" y="556" lock="yes" other="rotation=-0.46 mat=conc"/>
  <rubberblock x="52" y="545" lock="yes" other="rotation=-2.433 mat=conc"/>
  <rubberblock x="552.5" y="551" lock="no" other="rotation=-0.666 mat=rubber"/>
  <fixedblock x="272.5" y="338.5" lock="yes" other="rotation=0"/>
  <fixedblock x="303.5" y="338.5" lock="yes" other="rotation=0"/>
  <fixedblock x="334.5" y="338.5" lock="yes" other="rotation=0"/>
  <fixedblock x="365.5" y="338.5" lock="yes" other="rotation=0"/>
  <fixedblock x="396.5" y="338.5" lock="yes" other="rotation=0"/>
  <fixedblock x="242.5" y="338.5" lock="yes" other="rotation=0"/>
  <fixedblock x="211.5" y="338.5" lock="yes" other="rotation=0"/>
  <fixedblock x="30.5" y="22.5" lock="no" other="rotation=0"/>
  <fixedblock x="63.5" y="22.5" lock="no" other="rotation=0"/>
  <pvcpipe x="243.5" y="235.5" lock="no" other="rotation=0.626"/>
  <pendulum x="392.5" y="6.5" lock="yes" other="swing_x=13 swing_y=291"/>
  <spring x="89.5" y="561.5" lock="yes" other="dir=right"/></room>
		<room roomID="5" status="new" type="challenge" setting="main" title="Rainbow Room" desc="There are so many colors to choose from! Which Fidgits go where?" fg="blank" bg="bg/7.swf" results="" Fcount="0">
	<dropper x="271.5" y="6" lock="yes" other="drop=5 time=1"/>
  <dropper x="387.5" y="6" lock="yes" other="drop=5 time=1"/>
  <dropper x="149.5" y="6" lock="yes" other="drop=5 time=1"/>
  <figitbox x="125.5" y="556" lock="yes" other="par=r/8/3"/>
  <figitbox x="400.5" y="556" lock="yes" other="par=r/6/3"/>
  <figitbox x="262.5" y="556" lock="yes" other="par=r/9/3"/>
  <fixedblock x="235.5" y="494.5" lock="no" other="rotation=0.006"/>
  <fixedblock x="40.5" y="495.5" lock="no" other="rotation=0.585"/>
  <fixedblock x="529.5" y="499.5" lock="no" other="rotation=-1.026"/>
  <pvcpipe x="140.5" y="149.5" lock="no" other="rotation=-0.615"/>
  <pvcpipe x="446.5" y="147.5" lock="no" other="rotation=1.025"/>
  <pvcpipe x="280.5" y="151.5" lock="no" other="rotation=-1.086"/>
  <figitpainter x="16" y="326.5" lock="yes" other="color=8"/>
  <figitpainter x="78.5" y="261.5" lock="yes" other="color=4"/>
  <figitpainter x="140.5" y="324.5" lock="yes" other="color=2"/>
  <figitpainter x="204.5" y="262.5" lock="yes" other="color=9"/>
  <figitpainter x="460.5" y="261.5" lock="yes" other="color=6"/>
  <figitpainter x="330.5" y="259.5" lock="yes" other="color=3"/>
  <figitpainter x="396.5" y="321.5" lock="yes" other="color=5"/>
  <figitpainter x="269.5" y="324.5" lock="yes" other="color=1"/>
  <figitpainter x="524.5" y="317.5" lock="yes" other="color=7"/></room>
		<room roomID="6" status="new" type="challenge" setting="main" title="Tight Squeeze" desc="Can you squeeze the Fidgits into their box?" fg="blank" bg="bg/5.swf" results="" Fcount="0">
	<dropper x="105.5" y="6" lock="yes" other="drop=6 time=1"/>
  <figitbox x="426" y="556" lock="yes" other="par=s/0/10"/>
  <rubberblock x="122.5" y="219.75" lock="no" other="rotation=0.861"/>
  <rubberblock x="347.5" y="372.75" lock="no" other="rotation=0"/>
  <rubberblock x="422.5" y="418.75" lock="no" other="rotation=1.293"/>
  <rubberblock x="510.5" y="419.75" lock="no" other="rotation=-1.288"/>
  <fixedblock x="559.5" y="550.5" lock="yes" other="rotation=0"/>
  <fixedblock x="371.5" y="550.5" lock="yes" other="rotation=0"/>
  <fixedblock x="559.5" y="579" lock="yes" other="rotation=0"/>
  <fixedblock x="371.5" y="579" lock="yes" other="rotation=0"/>
  <fixedblock x="525.5" y="279.5" lock="no" other="rotation=0"/>
  <pvcpipe x="524.5" y="505.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="406.5" y="505.5" lock="yes" other="rotation=0"/>
  <figitdivider x="426.5" y="321.5" lock="no" other=""/></room>
		<room roomID="7" status="new" type="challenge" setting="main" title="Pipeline Panic" desc="Patch the holes in this pipeline so the Fidgits can get to their box!" fg="blank" bg="bg/15.swf" results="" Fcount="0">
	<dropper x="36.5" y="6" lock="yes" other="drop=10 time=1"/>
  <figitbox x="521" y="555" lock="yes" other="par=l/1/5"/>
  <rubberblock x="52" y="118.75" lock="yes" other="rotation=0.633"/>
  <rubberblock x="324.5" y="207.75" lock="no" other="rotation=0"/>
  <rubberblock x="552" y="323.75" lock="no" other="rotation=-0.801"/>
  <rubberblock x="372.5" y="376.75" lock="no" other="rotation=0"/>
  <rubberblock x="161" y="501.75" lock="no" other="rotation=0.71"/>
  <rubberblock x="368.5" y="533.75" lock="no" other="rotation=0"/>
  <fixedblock x="584" y="203.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="146.5" y="100.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="255.5" y="135.5" lock="yes" other="rotation=0.624"/>
  <pvcpipe x="457.5" y="325.5" lock="no" other="rotation=-0.213"/>
  <pvcpipe x="413.5" y="171.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="280.5" y="338.5" lock="no" other="rotation=0"/>
  <pvcpipe x="278.5" y="487.5" lock="no" other="rotation=0"/>
  <pvcpipe x="463.5" y="508.5" lock="no" other="rotation=0.344"/>
  <figitcombiner x="125.5" y="367.5" lock="yes" other=""/>
  <figitpainter x="509.5" y="214.5" lock="yes" other="color=1"/></room>
		<room roomID="8" status="new" type="challenge" setting="main" title="Way Up High" desc="The box is way up high. How can you get up there?" fg="blank" bg="bg/4.swf" results="" Fcount="0">
	<dropper x="29.5" y="6" lock="yes" other="drop=5 time=1"/>
  <figitbox x="522" y="283.5" lock="yes" other="par=r/0/5"/>
  <spring x="486.5" y="328.5" lock="no" other="dir=left"/>
  <rubberblock x="52" y="551" lock="yes" other="rotation=0.652 mat=conc"/>
  <rubberblock x="390.5" y="185" lock="no" other="rotation=2.126 mat=rubber"/>
  <rubberblock x="282.5" y="460.75" lock="yes" other="rotation=-1.574 mat=conc"/>
  <rubberblock x="282.5" y="380.75" lock="yes" other="rotation=-1.561 mat=conc"/>
  <rubberblock x="283.5" y="300.75" lock="yes" other="rotation=-1.557 mat=conc"/>
  <rubberblock x="284.5" y="220.75" lock="yes" other="rotation=-1.568 mat=conc"/>
  <rubberblock x="453.5" y="128.75" lock="no" other="rotation=-0.482 mat=rubber"/>
  <rubberblock x="284.5" y="140.75" lock="no" other="rotation=-1.573 mat=conc"/>
  <rubberblock x="284.5" y="61" lock="no" other="rotation=-1.573 mat=conc"/>
  <fixedblock x="553.5" y="337.5" lock="yes" other="rotation=0"/>
  <fixedblock x="584.5" y="337.5" lock="yes" other="rotation=0"/>
  <fixedblock x="522.5" y="337.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="146.5" y="533.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="247.5" y="533.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="349.5" y="533.5" lock="yes" other="rotation=0"/></room>
		<room roomID="9" status="new" type="challenge" setting="main" title="Over the Wall" desc="Bounce them over the wall!" fg="blank" bg="bg/8.swf" results="" Fcount="0">
	 <dropper x="447.5" y="6" lock="yes" other="drop=3 time=1"/>  <figitbox x="145" y="556" lock="yes" other="par=r/0/3"/>  <rubberblock x="492.5" y="423.75" lock="no" other="rotation=-0.466 mat=rubber"/>  <rubberblock x="47.5" y="535" lock="no" other="rotation=0 mat=wood"/>  <rubberblock x="49.5" y="494.75" lock="no" other="rotation=0 mat=wood"/>  <rubberblock x="98.5" y="575" lock="no" other="rotation=0 mat=wood"/>  <fixedblock x="238.5" y="548.5" lock="yes" other="rotation=0"/>  <fixedblock x="238.5" y="517.5" lock="yes" other="rotation=0"/>  <fixedblock x="238.5" y="487.5" lock="yes" other="rotation=0"/>  <fixedblock x="238.5" y="457.5" lock="yes" other="rotation=0"/>  <fixedblock x="238.5" y="579" lock="yes" other="rotation=0"/></room>
		<room roomID="10" status="new" type="challenge" setting="main" title="Four Fidgits Falling" desc="Keep dividing up those Fidgits..." fg="blank" bg="bg/5.swf" results="" Fcount="0">
	<dropper x="263.5" y="6" lock="yes" other="drop=1 time=1"/>
  <figitbox x="266" y="556" lock="yes" other="par=s/6/4"/>
  <rubberblock x="51" y="474.75" lock="no" other="rotation=0.737"/>
  <rubberblock x="560" y="473.75" lock="no" other="rotation=-0.77"/>
  <rubberblock x="223.5" y="554" lock="yes" other="rotation=0.524"/>
  <rubberblock x="383.5" y="551" lock="yes" other="rotation=-0.592"/>
  <fixedblock x="299.5" y="162.5" lock="yes" other="rotation=0.785"/>
  <fixedblock x="194.5" y="441.5" lock="yes" other="rotation=0"/>
  <fixedblock x="224.5" y="441.5" lock="yes" other="rotation=0"/>
  <fixedblock x="254.5" y="441.5" lock="yes" other="rotation=0"/>
  <fixedblock x="284.5" y="441.5" lock="yes" other="rotation=0"/>
  <fixedblock x="344.5" y="441.5" lock="yes" other="rotation=0"/>
  <fixedblock x="374.5" y="441.5" lock="yes" other="rotation=0"/>
  <fixedblock x="404.5" y="441.5" lock="yes" other="rotation=0"/>
  <fixedblock x="314.5" y="441.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="383.5" y="195.5" lock="no" other="rotation=-2.744"/>
  <pvcpipe x="213.5" y="196.5" lock="no" other="rotation=2.684"/>
  <pvcpipe x="479.5" y="237.5" lock="no" other="rotation=0.414"/>
  <pvcpipe x="119.5" y="242.5" lock="no" other="rotation=-0.475"/>
  <pvcpipe x="145.5" y="478.5" lock="no" other="rotation=0.271"/>
  <pvcpipe x="466.5" y="478.5" lock="no" other="rotation=-0.274"/>
  <figitdivider x="258.5" y="75.5" lock="no" other=""/>
  <figitdivider x="518.5" y="354.5" lock="no" other=""/>
  <figitdivider x="9.5" y="359.5" lock="yes" other=""/>
  <figitpainter x="529" y="287.5" lock="yes" other="color=6"/>
  <figitpainter x="18.5" y="295.5" lock="yes" other="color=6"/></room>
		<room roomID="11" status="new" type="challenge" setting="main" title="Over and Through" desc="Get them over the dip, and through the gap." fg="blank" bg="bg/3.swf" results="" Fcount="0">
	<dropper x="514.5" y="6" lock="yes" other="drop=10 time=1"/>
  <figitbox x="520.5" y="555.5" lock="yes" other="par=r/0/1"/>
  <rubberblock x="56" y="456.75" lock="no" other="rotation=0.541 mat=rubber"/>
  <rubberblock x="553" y="216.75" lock="yes" other="rotation=-0.497 mat=rubber"/>
  <rubberblock x="127.5" y="270.75" lock="yes" other="rotation=0 mat=conc"/>
  <rubberblock x="206.5" y="270.75" lock="yes" other="rotation=0 mat=conc"/>
  <rubberblock x="283.5" y="302.75" lock="yes" other="rotation=0 mat=conc"/>
  <rubberblock x="363.5" y="302.75" lock="yes" other="rotation=0 mat=conc"/>
  <rubberblock x="439.5" y="271.75" lock="yes" other="rotation=0 mat=conc"/>
  <rubberblock x="519.5" y="271.75" lock="yes" other="rotation=0 mat=conc"/>
  <rubberblock x="327.5" y="473.75" lock="yes" other="rotation=1.576 mat=conc"/>
  <rubberblock x="327.5" y="553" lock="no" other="rotation=1.565 mat=conc"/>
  <fixedblock x="579" y="270.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="398.5" y="153.5" lock="no" other="rotation=0"/>
  <pvcpipe x="141.5" y="185" lock="no" other="rotation=0"/>
  <pvcpipe x="261.5" y="167.5" lock="no" other="rotation=0"/>
  <pvcpipe x="59" y="282.5" lock="yes" other="rotation=-1.572"/></room>
		<room roomID="12" status="new" type="challenge" setting="main" title="Two Up High" desc="You need to get two Fidgits way up high. How can you do that?" fg="blank" bg="bg/9.swf" results="" Fcount="0">
	<dropper x="275.5" y="6" lock="yes" other="drop=1 time=1"/>
  <figitbox x="521" y="206.5" lock="yes" other="par=s/7/1"/>
  <figitbox x="8.5" y="206.5" lock="yes" other="par=s/9/1"/>
  <rubberblock x="408.5" y="416.75" lock="no" other="rotation=0.659 mat=conc"/>
  <rubberblock x="206.5" y="412.75" lock="no" other="rotation=-0.672 mat=conc"/>
  <fixedblock x="359.5" y="90.5" lock="yes" other="rotation=0"/>
  <fixedblock x="359.5" y="121.5" lock="yes" other="rotation=0"/>
  <fixedblock x="260.5" y="88.5" lock="yes" other="rotation=0"/>
  <fixedblock x="260.5" y="119.5" lock="yes" other="rotation=0"/>
  <figitdivider x="269.5" y="134.5" lock="yes" other=""/>
  <figitpainter x="531.5" y="98.5" lock="no" other="color=7"/>
  <figitpainter x="17.5" y="104.5" lock="no" other="color=9"/>
  <spring x="262.5" y="563.5" lock="yes" other="dir=left"/>
  <spring x="312.5" y="563.5" lock="yes" other="dir=right"/>
  <spring x="120.5" y="426.5" lock="yes" other="dir=left"/>
  <spring x="450.5" y="426.5" lock="yes" other="dir=right"/></room>
		<room roomID="13" status="new" type="challenge" setting="main" title="Two Big" desc="Get two big ones in the box!" fg="blank" bg="bg/14.swf" results="" Fcount="0">
	<dropper x="465.5" y="6" lock="yes" other="drop=2 time=1"/>  <dropper x="81.5" y="6" lock="yes" other="drop=2 time=1"/>  <figitbox x="274.5" y="556" lock="yes" other="par=l/0/2"/>  <rubberblock x="103.5" y="461.75" lock="no" other="rotation=0.821 mat=rubber"/>  <rubberblock x="507.5" y="464.75" lock="no" other="rotation=-0.707 mat=rubber"/>  <fixedblock x="258.5" y="543.5" lock="no" other="rotation=0"/>  <fixedblock x="368.5" y="542.5" lock="no" other="rotation=0"/>  <fixedblock x="567.5" y="347.5" lock="no" other="rotation=0"/>  <fixedblock x="59.5" y="360.5" lock="no" other="rotation=0"/>  <pvcpipe x="461.5" y="541.5" lock="no" other="rotation=0"/>  <pvcpipe x="176.5" y="549.5" lock="no" other="rotation=0"/>  <figitcombiner x="446.5" y="221.5" lock="yes" other=""/>  <figitcombiner x="66.5" y="221.5" lock="yes" other=""/></room>
		<room roomID="14" status="new" type="challenge" setting="main" title="Kicked!" desc="The pendulum has got quite a kick!" fg="blank" bg="bg/13.swf" results="" Fcount="0">
	<dropper x="183.5" y="6" lock="yes" other="drop=1 time=1"/>
  <figitbox x="173.5" y="556" lock="yes" other="par=r/0/1"/>
  <rubberblock x="508" y="420.75" lock="yes" other="rotation=-0.623 mat=conc"/>
  <rubberblock x="93.5" y="455.75" lock="no" other="rotation=0 mat=rubber"/>
  <rubberblock x="91.5" y="411.75" lock="no" other="rotation=0 mat=rubber"/>
  <rubberblock x="95.5" y="362.75" lock="no" other="rotation=0 mat=rubber"/>
  <rubberblock x="548" y="350.75" lock="yes" other="rotation=-1.56 mat=conc"/>
  <fixedblock x="217.5" y="260.5" lock="no" other="rotation=0"/>
  <pvcpipe x="409.5" y="437.5" lock="no" other="rotation=-0.591"/>
  <pvcpipe x="324.5" y="482.5" lock="no" other="rotation=-0.332"/>
  <pendulum x="168" y="119.5" lock="yes" other="swing_x=-30 swing_y=-110"/></room>
		<room roomID="15" status="new" type="challenge" setting="main" title="Tube Towers" desc="Move the Fidgits through the towers of tubes." fg="blank" bg="bg/13.swf" results="" Fcount="0">
	<dropper x="53.5" y="6" lock="yes" other="drop=8 time=1"/>
  <figitbox x="480.5" y="497" lock="yes" other="par=r/0/4"/>
  <rubberblock x="70.5" y="336.75" lock="no" other="rotation=0.637 mat=wood"/>
  <rubberblock x="430.5" y="514.75" lock="no" other="rotation=0 mat=rubber"/>
  <rubberblock x="243.5" y="426.75" lock="no" other="rotation=0.601 mat=conc"/>
  <fixedblock x="298.5" y="326.5" lock="no" other="rotation=0"/>
  <fixedblock x="578.5" y="479.5" lock="no" other="rotation=0"/>
  <pvcpipe x="340.5" y="486" lock="yes" other="rotation=-1.576"/>
  <pvcpipe x="340.5" y="408.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="343.5" y="256.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="341.5" y="333.5" lock="yes" other="rotation=-1.561"/>
  <pvcpipe x="176.5" y="543" lock="yes" other="rotation=-1.565"/>
  <pvcpipe x="176.5" y="465.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="176.5" y="388.5" lock="yes" other="rotation=-1.564"/>
  <pvcpipe x="173.5" y="311.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="519" y="564" lock="yes" other="rotation=0"/>
  <pvcpipe x="174.5" y="233.5" lock="yes" other="rotation=-1.575"/>
  <pvcpipe x="172.5" y="158.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="340.5" y="563" lock="yes" other="rotation=0"/>
  <spring x="241.5" y="567" lock="no" other="dir=right"/></room>
		<room roomID="16" status="new" type="challenge" setting="main" title="Conveyer Belts" desc="Conveyer belts move those Fidgits along!" fg="blank" bg="bg/7.swf" results="" Fcount="0">
	<dropper x="467.5" y="6" lock="yes" other="drop=10 time=1"/>
  <figitbox x="40.5" y="555.5" lock="yes" other="par=s/2/20"/>
  <figitdivider x="39" y="189.5" lock="yes" other=""/>
  <figitpainter x="428.5" y="308.5" lock="no" other="color=2"/>
  <elbowpipe x="99" y="139" lock="yes" other="rotation=-1.559"/>
  <elbowpipe x="98.5" y="441" lock="no" other="rotation=-1.569"/>
  <conveyorbelt x="343.5" y="142.5" lock="yes" other="cv=lt_med"/>
  <conveyorbelt x="41.5" y="293.5" lock="yes" other="cv=rt_med"/>
  <conveyorbelt x="233.5" y="293.5" lock="yes" other="cv=rt_med"/>
  <conveyorbelt x="338" y="443.5" lock="no" other="cv=lt_med"/>
  <conveyorbelt x="151.5" y="141.5" lock="no" other="cv=lt_med"/>
  <conveyorbelt x="146.5" y="443.5" lock="yes" other="cv=lt_med"/></room>
		<room roomID="17" status="new" type="challenge" setting="main" title="Fidgit Cannon" desc="Use the Fidgit Cannon to make them fly!" fg="blank" bg="bg/11.swf" results="" Fcount="0">
	<dropper x="42.5" y="6" lock="yes" other="drop=3 time=1"/>
  <fidgitfood x="189.5" y="241.5" lock="yes" other=""/>
  <fidgitfood x="91.5" y="347.5" lock="yes" other=""/>
  <fidgitfood x="287.5" y="351.5" lock="yes" other=""/>
  <figitbox x="162.5" y="556" lock="yes" other="par=r/0/1"/>
  <rubberblock x="425.5" y="192.75" lock="yes" other="rotation=0 mat=wood"/>
  <rubberblock x="187.5" y="192.75" lock="yes" other="rotation=0 mat=wood"/>
  <rubberblock x="267.5" y="192.75" lock="yes" other="rotation=0 mat=wood"/>
  <rubberblock x="345.5" y="192.75" lock="yes" other="rotation=0 mat=wood"/>
  <rubberblock x="277.5" y="537.75" lock="yes" other="rotation=-0.853 mat=conc"/>
  <rubberblock x="123.5" y="536" lock="yes" other="rotation=0.888 mat=conc"/>
  <elbowpipe x="95.5" y="127" lock="yes" other="rotation=3.131"/>
  <fidgitcannon x="500.5" y="224.5" lock="no" other="chute=1"/></room>
		<room roomID="18" status="new" type="challenge" setting="main" title="Hole in the Wall" desc="Can you get the Fidgits through the gap?" fg="blank" bg="bg/13.swf" results="" Fcount="0">
	<dropper x="47.5" y="6" lock="yes" other="drop=6 time=1"/>
  <fidgitfood x="301.5" y="283.5" lock="yes" other=""/>
  <figitbox x="515.5" y="192.5" lock="yes" other="par=r/0/5"/>
  <rubberblock x="314.5" y="46" lock="yes" other="rotation=1.566 mat=conc"/>
  <rubberblock x="315.5" y="126.75" lock="yes" other="rotation=1.573 mat=conc"/>
  <rubberblock x="315.5" y="204.75" lock="yes" other="rotation=1.576 mat=conc"/>
  <rubberblock x="315.5" y="393.75" lock="yes" other="rotation=1.572 mat=conc"/>
  <rubberblock x="315.5" y="472.75" lock="yes" other="rotation=1.567 mat=conc"/>
  <rubberblock x="315.5" y="552" lock="yes" other="rotation=1.566 mat=conc"/>
  <fixedblock x="315.5" y="339.5" lock="yes" other="rotation=0"/>
  <fixedblock x="315.5" y="258.5" lock="yes" other="rotation=0"/>
  <fixedblock x="522.5" y="246.5" lock="yes" other="rotation=0"/>
  <fixedblock x="552.5" y="246.5" lock="yes" other="rotation=0"/>
  <fixedblock x="583" y="246.5" lock="yes" other="rotation=0"/>
  <fixedblock x="315.5" y="437.5" lock="yes" other="rotation=0"/>
  <fixedblock x="315.5" y="517.5" lock="yes" other="rotation=0"/>
  <fixedblock x="315.5" y="84.5" lock="yes" other="rotation=0"/>
  <fixedblock x="315.5" y="165.5" lock="yes" other="rotation=0"/>
  <fixedblock x="401.5" y="460.5" lock="no" other="rotation=0"/>
  <fixedblock x="401.5" y="428.5" lock="no" other="rotation=0"/>
  <fixedblock x="482.5" y="490.5" lock="no" other="rotation=0"/>
  <fixedblock x="514.5" y="490.5" lock="no" other="rotation=0"/>
  <spring x="420.5" y="475" lock="no" other="dir=right"/>
  <fidgitcannon x="47.5" y="252.5" lock="no" other="chute=1"/></room>
		<room roomID="19" status="new" type="challenge" setting="main" title="So Many Tubes!" desc="Can you get them through the tube maze?" fg="blank" bg="bg/2.swf" results="" Fcount="0">
	<dropper x="276.5" y="6" lock="yes" other="drop=6 time=1"/>
  <fidgitfood x="260.5" y="444.5" lock="yes" other=""/>
  <figitbox x="20.5" y="556" lock="yes" other="par=s/9/5"/>
  <figitbox x="511" y="556" lock="yes" other="par=r/5/3"/>
  <rubberblock x="138.5" y="259.75" lock="no" other="rotation=1.57 mat=wood"/>
  <pvcpipe x="457.5" y="254.5" lock="yes" other="rotation=0"/>
  <pvcpipe x="156" y="361.5" lock="no" other="rotation=-0.006"/>
  <pvcpipe x="446.5" y="419.5" lock="yes" other="rotation=0"/>
  <figitcombiner x="308.5" y="450.5" lock="no" other=""/>
  <figitdivider x="270.5" y="79.5" lock="yes" other=""/>
  <figitpainter x="7" y="221.5" lock="yes" other="color=9"/>
  <figitpainter x="536.5" y="283.5" lock="no" other="color=5"/>
  <spring x="158.5" y="284.5" lock="yes" other="dir=left"/>
  <elbowpipe x="356.5" y="235" lock="yes" other="rotation=3.137"/>
  <elbowpipe x="262.5" y="234" lock="yes" other="rotation=1.565"/>
  <elbowpipe x="158.5" y="168" lock="yes" other="rotation=0"/>
  <elbowpipe x="58" y="169" lock="yes" other="rotation=-1.568"/>
  <elbowpipe x="56" y="342" lock="yes" other="rotation=3.135"/>
  <elbowpipe x="255.5" y="381" lock="yes" other="rotation=0"/>
  <elbowpipe x="549" y="399" lock="yes" other="rotation=1.559"/>
  <conveyorbelt x="109.5" y="491.5" lock="no" other="cv=lt_med"/>
  <conveyorbelt x="319.5" y="554.5" lock="no" other="cv=rt_med"/></room>
		<room roomID="20" status="new" type="challenge" setting="main" title="Quick Shot" desc="Bounce them to the goal way up high." fg="blank" bg="bg/15.swf" results="" Fcount="0">
	<dropper x="263.5" y="6" lock="yes" other="drop=3 time=1"/>
  <figitbox x="379.5" y="64.5" lock="yes" other="par=r/0/3"/>
  <rubberblock x="178.5" y="575" lock="no" other="rotation=0 mat=rubber"/>
  <rubberblock x="444.5" y="575" lock="no" other="rotation=0 mat=rubber"/>
  <fixedblock x="390.5" y="115.5" lock="yes" other="rotation=0"/>
  <fixedblock x="420.5" y="115.5" lock="yes" other="rotation=0"/>
  <fixedblock x="450.5" y="116.5" lock="yes" other="rotation=0"/>
  <fixedblock x="360.5" y="23.5" lock="yes" other="rotation=0"/>
  <fixedblock x="359.5" y="54.5" lock="yes" other="rotation=0"/>
  <fixedblock x="359.5" y="85.5" lock="yes" other="rotation=0"/>
  <fixedblock x="359.5" y="114.5" lock="yes" other="rotation=0"/>
  <fidgitcannon x="259.5" y="158.5" lock="no" other="chute=1"/>
  <fidgitcannon x="40.5" y="392.5" lock="no" other="chute=1"/></room>
	</challenge>
</rooms>